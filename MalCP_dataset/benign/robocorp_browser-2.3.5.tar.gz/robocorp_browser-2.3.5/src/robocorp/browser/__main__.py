if __name__ == "__main__":
    from robocorp.browser.cli import main

    main()
