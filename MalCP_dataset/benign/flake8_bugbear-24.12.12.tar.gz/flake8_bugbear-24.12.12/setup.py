# Copyright (C) 2016-2021 Łukasz Langa

from setuptools import setup

setup()
