from collections import defaultdict

a = defaultdict(int)
b = defaultdict(float)
c = defaultdict(bool)
d = defaultdict(str)
e = defaultdict()
f = defaultdict(int)
