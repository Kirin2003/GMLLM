"""
Should emit:
B029 - on lines 8 and 13
"""

try:
    pass
except* ():
    pass

try:
    pass
except* () as e:
    pass
