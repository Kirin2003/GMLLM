``glom`` Tutorial
=================

*Learn to use glom in no time!*

Basic use of glom requires only a glance, not a whole tutorial. The
case studies below takes a wider look at day-to-day data and object
manipulation, helping you develop an eye for writing robust,
declarative data transformations.

Go beyond basic with 10 minutes or less, and even further if you
can spare a half hour.

.. contents:: Contents
   :local:

.. automodule:: glom.tutorial
