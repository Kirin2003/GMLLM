# import 'compress' and 'decompress' from lilcom_interface
from .lilcom_interface import compress, decompress, get_shape
