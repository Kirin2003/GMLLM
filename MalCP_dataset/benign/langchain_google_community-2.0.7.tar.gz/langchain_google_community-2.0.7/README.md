# langchain-google-community

This package contains the LangChain integrations for Google products that are not part of `langchain-google-vertexai` or `langchain-google-genai` packages.

## Installation

```bash
pip install -U langchain-google-community
```
