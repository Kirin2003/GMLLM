# Release History

## 0.1.1 (2021-11-11)

* This package is no longer maintained. Please use https://pypi.org/project/azure-monitor-query/

## 0.1.0 (2018-07-11)

* Initial Release
