---
name: Question
about: Please use the Discussion Forum to ask questions
title: "[question] "
labels: question
assignees: ''

---

Please use the [Discussion Forum](https://github.com/openwisp/django-swappable-models/discussions) to ask questions.

We will take care of moving the discussion to a more relevant repository if needed.
