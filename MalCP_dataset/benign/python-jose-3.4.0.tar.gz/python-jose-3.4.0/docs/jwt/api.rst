
JWT API
^^^^^^^

.. automodule:: jose.jwt
   :members: