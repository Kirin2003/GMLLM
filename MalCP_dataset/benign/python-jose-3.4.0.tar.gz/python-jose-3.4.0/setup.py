#!/usr/bin/env python
from setuptools import setup

setup()
