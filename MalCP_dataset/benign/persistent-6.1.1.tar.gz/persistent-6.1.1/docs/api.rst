:mod:`persistent` API documentation
===================================

.. toctree::
   :maxdepth: 2

   api/interfaces
   api/collections
   api/attributes
   api/pickling
   api/cache
