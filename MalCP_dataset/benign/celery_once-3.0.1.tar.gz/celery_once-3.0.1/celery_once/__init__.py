# -*- coding: utf-8 -*-

__author__ = 'Cameron Maske'
__email__ = 'cameronmaske@gmail.com'
__version__ = '3.0.1'


from .tasks import QueueOnce, AlreadyQueued
