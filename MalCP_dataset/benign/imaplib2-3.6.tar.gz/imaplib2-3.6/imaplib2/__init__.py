from __future__ import absolute_import

from .imaplib2 import *
from .imaplib2 import __version__, __doc__
