colcon-package-information
==========================

An extension for `colcon-core <https://github.com/colcon/colcon-core>`_ to provide information about the packages.
