"""
Copyright (c) 2015, 2020 Red Hat, Inc
All rights reserved.

This software may be modified and distributed under the terms
of the BSD license. See the LICENSE file for details.
"""

#
# This file is generated from template: rel-eng/version_init.template
# DO NOT MODIFY THIS FILE
# If changes are necessary, edit ./rel-eng/version_init.template
#

from __future__ import absolute_import
from .parser import DockerfileParser  # noqa: F401

__version__ = "2.0.1"
