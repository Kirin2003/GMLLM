# -*- coding: utf-8 -*-
__version__ = "1.0.2"

from .sseclient import SSEClient

__all__ = [
    "SSEClient",
]
