#!/usr/bin/env python

# Copyright (c) IPython Development Team.
# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

from setuptools import setup
if __name__ == '__main__':
    setup()
