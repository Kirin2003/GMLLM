.. include:: ../src/zope/viewlet/communicating-viewlets.rst
