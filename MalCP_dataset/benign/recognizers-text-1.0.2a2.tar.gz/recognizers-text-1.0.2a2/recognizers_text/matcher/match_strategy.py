from enum import Enum


class MatchStrategy(Enum):

    AcAutomaton = 0

    TrieTree = 1
