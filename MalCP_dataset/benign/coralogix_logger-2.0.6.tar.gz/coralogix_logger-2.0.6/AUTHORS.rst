Coralogix Python SDK is written by Coralogix Ltd. and maintained by Coralogix Ltd.

Contributors
````````````

- Coralogix Ltd. <info@coralogix.com> `@coralogix <https://github.com/coralogix>`_
- Amnon Shahar <amnon@coralogix.com> `@amnons77 <https://github.com/amnons77>`_
- Eldar Aliiev <eldar@coralogix.com> `@EldarAliiev <https://github.com/EldarAliiev>`_
- Lior Redlus <lior@coralogix.com> `@redlus <https://github.com/redlus>`_
