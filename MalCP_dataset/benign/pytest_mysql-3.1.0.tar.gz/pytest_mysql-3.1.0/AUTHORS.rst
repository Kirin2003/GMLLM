Authors
=======

This file contains the list of people involved in the development
of pytest-mysql along its history.

* Grzegorz Śliwiński
* Jakub Klinkovský
* Karolina Blümke
* Paweł Wilczyński
* Tomasz Święcicki
* Tomasz Karbownicki
* Michał Masłowski
* Damian Skrzypczak