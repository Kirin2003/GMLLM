from django_cryptography.utils.version import get_version

VERSION = (1, 0, 0, 'final', 0)

__version__ = get_version(VERSION)
