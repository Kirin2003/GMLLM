Installation
============

Requirements
------------

* Python_ (3.5, 3.6, 3.7, 3.8)
* Cryptography_ (2.0+)
* Django_ (1.11, 2.2, 3.0)

.. code-block:: console

   pip install django-cryptography

.. _Cryptography: https://cryptography.io/
.. _Django: https://www.djangoproject.com/
.. _Python: https://www.python.org/
