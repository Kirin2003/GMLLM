=======
History
=======

1.0.0 (2018-05-07)
------------------

* First release based on Python 3.7b4.
