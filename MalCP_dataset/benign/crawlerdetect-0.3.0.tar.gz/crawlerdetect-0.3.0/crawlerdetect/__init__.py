from crawlerdetect import providers
from crawlerdetect.crawlerdetect import CrawlerDetect

__all__ = ("CrawlerDetect", "providers", "__version__")

__version__ = "0.3.0"
