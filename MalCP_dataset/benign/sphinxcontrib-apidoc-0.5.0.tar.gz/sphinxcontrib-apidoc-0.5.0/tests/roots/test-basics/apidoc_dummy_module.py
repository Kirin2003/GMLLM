from os import *  # noqa


class Foo:
    def __init__(self):
        pass

    def bar(self):
        pass
