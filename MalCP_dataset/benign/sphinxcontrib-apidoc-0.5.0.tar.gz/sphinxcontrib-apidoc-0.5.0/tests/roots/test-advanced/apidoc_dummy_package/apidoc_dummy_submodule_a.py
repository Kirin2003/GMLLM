from __future__ import print_function


class Bar(object):
    def foo(self):
        print('Hello, world')
