def bogus():
    return 'bogus'
