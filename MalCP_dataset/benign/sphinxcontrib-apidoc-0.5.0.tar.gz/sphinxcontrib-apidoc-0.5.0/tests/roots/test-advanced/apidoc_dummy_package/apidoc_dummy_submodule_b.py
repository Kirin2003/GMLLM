class Baz(object):
    def inga(self):
        return 1 + 3
