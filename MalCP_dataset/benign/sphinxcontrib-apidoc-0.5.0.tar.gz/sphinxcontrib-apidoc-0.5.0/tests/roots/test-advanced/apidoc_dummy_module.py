from os import *  # noqa

from apidoc_dummy_package import apidoc_dummy_submodule_a as a  # noqa
from apidoc_dummy_package import apidoc_dummy_submodule_b as b  # noqa


class Foo:
    def __init__(self):
        pass

    def bar(self):
        pass
