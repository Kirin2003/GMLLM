==============
 Contributing
==============

If you would like to contribute to this project, or any project in the
`sphinx-contrib`_ namespace, you should refer to the guidelines found in the
`Sphinx documentation`_.

.. _sphinx-contrib: https://github.com/sphinx-contrib
.. _Sphinx documentation: http://www.sphinx-doc.org/en/stable/contrib/
