#!/usr/bin/env python

import setuptools


setuptools.setup(
    setup_requires=['pbr>=4.0'],
    pbr=True,
)
