========================
Using oslo.serialization
========================

.. toctree::
   :maxdepth: 2

.. Add more contents here

.. history contains a lot of sections, toctree with maxdepth 1 is used.
.. toctree::
   :maxdepth: 1

   Release Notes <history>
