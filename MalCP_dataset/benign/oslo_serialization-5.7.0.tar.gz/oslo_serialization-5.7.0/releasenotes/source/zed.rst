========================
Zed Series Release Notes
========================

.. release-notes::
   :branch: unmaintained/zed
