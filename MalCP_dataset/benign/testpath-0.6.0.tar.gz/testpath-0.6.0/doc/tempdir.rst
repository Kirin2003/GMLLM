Utilities for temporary directories
===================================

.. module:: testpath.tempdir

The :mod:`testpath.tempdir` module contains a couple of utilities for working
with temporary directories:

.. autoclass:: NamedFileInTemporaryDirectory

.. autoclass:: TemporaryWorkingDirectory
