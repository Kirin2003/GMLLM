# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# 向后兼容
from pypinyin.style._tone_rule import right_mark_index  # noqa
