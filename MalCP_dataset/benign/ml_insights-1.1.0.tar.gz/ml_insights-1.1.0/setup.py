"""Setup for the ml_insights package."""

from setuptools import setup

setup(
     packages=[
        'ml_insights',
    ],

)
