# Microsoft Azure SDK for Python

This package is no longer being maintained. Use the [azure-ai-language-questionanswering](https://pypi.org/project/azure-ai-language-questionanswering/) package instead.

For migration instructions, see the [migration guide](https://aka.ms/azsdk/python/migrate/azure-ai-language-questionanswering).