requirementslib.models.markers module
=====================================

.. automodule:: requirementslib.models.markers
    :members:
    :undoc-members:
    :show-inheritance:
