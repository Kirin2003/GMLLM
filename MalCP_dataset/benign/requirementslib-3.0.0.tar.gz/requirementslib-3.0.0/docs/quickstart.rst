===================================================================
RequirementsLib: Requirement Management Library for Pip and Pipenv
===================================================================

.. include:: ../README.rst
