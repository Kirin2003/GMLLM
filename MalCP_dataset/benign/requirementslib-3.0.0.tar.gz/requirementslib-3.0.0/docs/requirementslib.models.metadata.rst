requirementslib.models.metadata module
======================================

.. automodule:: requirementslib.models.metadata
    :members:
    :undoc-members:
    :show-inheritance:
