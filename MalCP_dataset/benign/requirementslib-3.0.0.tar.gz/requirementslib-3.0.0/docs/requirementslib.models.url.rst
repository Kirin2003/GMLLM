requirementslib.models.url module
=================================

.. automodule:: requirementslib.models.url
    :members:
    :undoc-members:
    :show-inheritance:
