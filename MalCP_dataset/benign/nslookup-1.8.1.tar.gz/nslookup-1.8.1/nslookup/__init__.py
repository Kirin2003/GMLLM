#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .nslookup import DNSresponse, Nslookup

__author__ = 'wesinator'
__version__ = '1.8.1'
