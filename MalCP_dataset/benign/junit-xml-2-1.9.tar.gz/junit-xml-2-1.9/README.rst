python-junit-xml
================
Fork of https://github.com/kyrus/python-junit-xml to publish on pypi as tarball so
https://github.com/Homebrew/homebrew-core/blob/master/Formula/semgrep.rb can rely on this as a pypi package