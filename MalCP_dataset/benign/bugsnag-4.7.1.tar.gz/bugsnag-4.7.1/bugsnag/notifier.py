_NOTIFIER_INFORMATION = {
    'name': 'Python Bugsnag Notifier',
    'url': 'https://github.com/bugsnag/bugsnag-python',
    'version': '4.7.1'
}
