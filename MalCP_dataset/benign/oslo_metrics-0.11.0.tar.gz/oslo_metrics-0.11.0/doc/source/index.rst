============
oslo.metrics
============

This Oslo metrics API supports collecting metrics data from other Oslo
libraries and exposing the metrics data to monitoring system.

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   reference/api/modules
   user/index


Release Notes
=============

Read also the `oslo.metrics Release Notes
<https://docs.openstack.org/releasenotes/oslo.metrics/>`_.


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

