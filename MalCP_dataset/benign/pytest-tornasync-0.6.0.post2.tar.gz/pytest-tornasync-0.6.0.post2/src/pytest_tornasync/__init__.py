"""
A pytest plugin for testing Tornado apps using plain (undecorated) coroutine tests.
"""

__version_info__ = (0, 6, 0, 'post2')
__version__ = '.'.join(map(str, __version_info__))
