Examples:

    - See issues :issue:`12,13`

    - See other issues :issue:`sloria/konch#45,46`.

    - See PR :pr:`58`, thanks :user:`kound`
