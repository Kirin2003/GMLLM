from matplotlib_venn.layout.venn2.exact import LayoutAlgorithm as DefaultLayoutAlgorithm

__all__ = ["DefaultLayoutAlgorithm"]
