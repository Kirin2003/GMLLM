"""``celery`` integration for ``django_structlog``."""
