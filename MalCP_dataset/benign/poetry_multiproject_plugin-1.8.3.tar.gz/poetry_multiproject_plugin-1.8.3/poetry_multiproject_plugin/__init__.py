from poetry_multiproject_plugin.plugin import MultiProjectPlugin

__version__ = "1.0.4"

__all__ = ["MultiProjectPlugin"]
