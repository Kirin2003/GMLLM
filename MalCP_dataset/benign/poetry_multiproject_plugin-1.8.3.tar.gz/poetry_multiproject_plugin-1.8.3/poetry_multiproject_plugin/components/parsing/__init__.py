from poetry_multiproject_plugin.components.parsing.rewrite import rewrite_module

__all__ = ["rewrite_module"]
