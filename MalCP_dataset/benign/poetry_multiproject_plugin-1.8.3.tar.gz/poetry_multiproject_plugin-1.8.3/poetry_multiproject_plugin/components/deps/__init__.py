from poetry_multiproject_plugin.components.deps.installer import install_deps

__all__ = ["install_deps"]
