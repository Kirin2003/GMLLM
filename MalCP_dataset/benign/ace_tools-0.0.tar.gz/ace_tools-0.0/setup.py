from setuptools import setup, find_packages

setup(
    name='ace_tools',
    version='0.0',
    packages=find_packages(),
    install_requires=[
    ],
    author='Paul McMillan',
    author_email='paul@mcmillan.ws',
    description='A placeholder empty package',
    url='',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
