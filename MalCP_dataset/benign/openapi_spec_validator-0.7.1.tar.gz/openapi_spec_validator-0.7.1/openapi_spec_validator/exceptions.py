class OpenAPIError(Exception):
    pass


class OpenAPISpecValidatorError(OpenAPIError):
    pass
