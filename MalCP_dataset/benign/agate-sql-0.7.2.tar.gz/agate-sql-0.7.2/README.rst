.. image:: https://github.com/wireservice/agate-sql/workflows/CI/badge.svg
    :target: https://github.com/wireservice/agate-sql/actions
    :alt: Build status

.. image:: https://coveralls.io/repos/wireservice/agate-sql/badge.svg?branch=master
    :target: https://coveralls.io/r/wireservice/agate-sql
    :alt: Coverage status

.. image:: https://img.shields.io/pypi/dm/agate-sql.svg
    :target: https://pypi.python.org/pypi/agate-sql
    :alt: PyPI downloads

.. image:: https://img.shields.io/pypi/v/agate-sql.svg
    :target: https://pypi.python.org/pypi/agate-sql
    :alt: Version

.. image:: https://img.shields.io/pypi/l/agate-sql.svg
    :target: https://pypi.python.org/pypi/agate-sql
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/agate-sql.svg
    :target: https://pypi.python.org/pypi/agate-sql
    :alt: Support Python versions

agate-sql adds SQL read/write support to `agate <https://github.com/wireservice/agate>`_.

Important links:

* agate             https://agate.rtfd.org
* Documentation:    https://agate-sql.rtfd.org
* Repository:       https://github.com/wireservice/agate-sql
* Issues:           https://github.com/wireservice/agate-sql/issues
