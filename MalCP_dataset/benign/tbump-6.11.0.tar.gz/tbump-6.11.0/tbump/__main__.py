from tbump.cli import main

main()
