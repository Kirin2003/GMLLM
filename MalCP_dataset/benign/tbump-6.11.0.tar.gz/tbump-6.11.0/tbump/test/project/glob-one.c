static const char* version_one = "1.2.41-alpha-1";

int main() {
    puts(version);
    return 0;
}