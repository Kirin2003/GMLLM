=======
Credits
=======

Development Lead
----------------

* `Laser <https://github.com/LaserPhaser>`_, arseny.antonov@gmail.com

Contributors
------------

* `repsejnworb <https://github.com/repsejnworb>`_
* `lithammer <https://github.com/lithammer>`_
* `mstevens <https://github.com/mstevens>`_
* `AWegnerGitHub <https://github.com/AWegnerGitHub>`_
