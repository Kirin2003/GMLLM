.. include:: ../AUTHORS.rst

