=====
Usage
=====

To use Pytest Messenger in a project::

    import pytest_messenger
