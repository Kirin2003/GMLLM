from cloud_tpu_diagnostics.src.diagnose import diagnose
