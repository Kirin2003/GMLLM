#-*- coding: utf-8 -*-
"""
@author:Bengali.AI
"""
from __future__ import print_function
from .normalizer import Normalizer
from .indic import IndicNormalizer
from .base import BaseNormalizer