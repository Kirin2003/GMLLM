# History

## v0.1.0 (2020-06-02)

- First release on PyPI.

## v0.2.0 (2020-06-02)

- Added full macro implementation. Thanks Fabrice Etanchaud

## v0.4.3 (2021-06-28)

- Last stable release of [dbt-oracle](https://github.com/techindicium/dbt-oracle) by Techindicium

## v1.0.0 (2022-05-04)

- First release of vendor-built adapter by Oracle. 
- This version supports Python 3.6, 3.7, 3.8 and 3.9
