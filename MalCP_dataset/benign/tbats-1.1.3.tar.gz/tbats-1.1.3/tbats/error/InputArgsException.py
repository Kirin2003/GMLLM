from . import BatsException


class InputArgsException(BatsException):
    pass
