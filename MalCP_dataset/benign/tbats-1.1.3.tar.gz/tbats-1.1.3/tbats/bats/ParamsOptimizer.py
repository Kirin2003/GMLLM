from ..abstract import ParamsOptimizer as AbstractParamsOptimizer


class ParamsOptimizer(AbstractParamsOptimizer):
    """See parent class for documentation"""
    pass
