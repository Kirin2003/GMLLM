default_config = {
    'templates_dir': 'templates',
}
