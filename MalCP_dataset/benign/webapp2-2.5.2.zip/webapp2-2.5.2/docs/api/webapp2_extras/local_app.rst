.. _api.webapp2_extras.local_app:

Local App
=========
.. module:: webapp2_extras.local_app

.. warning::
   This module is deprecated. The :class:`webapp2.WSGIApplication` class is now
   thread-safe by default when :mod:`webapp2_extras.local` is available.

.. autoclass:: WSGIApplication
   :members: set_globals
