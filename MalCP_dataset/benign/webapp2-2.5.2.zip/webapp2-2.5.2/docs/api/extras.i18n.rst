i18n
====
This page moved to :ref:`api.webapp2_extras.i18n`.
