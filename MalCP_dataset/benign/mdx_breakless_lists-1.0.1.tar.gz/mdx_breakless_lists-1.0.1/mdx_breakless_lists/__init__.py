from .mdx_breakless_lists import makeExtension

assert makeExtension
