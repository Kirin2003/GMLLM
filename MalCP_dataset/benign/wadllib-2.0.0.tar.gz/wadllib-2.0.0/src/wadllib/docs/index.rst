.. include:: main.rst


.. toctree::
   :glob:

   self
   Contributing <CONTRIBUTING>
   News <NEWS>
