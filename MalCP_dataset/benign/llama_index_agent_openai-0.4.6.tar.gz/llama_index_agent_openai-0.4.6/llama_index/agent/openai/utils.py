"""Utils for OpenAI agent."""

from llama_index.llms.openai.utils import resolve_tool_choice

__all__ = ["resolve_tool_choice"]
