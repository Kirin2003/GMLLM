Django-pandas is written and maintained by Christopher Clarke and
various contributors:

Development Lead
````````````````

- Christopher Clarke <cclarke@chrisdev.com>

Contributions
``````````````

- `Christopher Clarke <https://github.com/chrisdev>`_
- `Bertrand Bordage <https://github.com/BertrandBordage>`_
- `Guillaume Thomas <https://github.com/gtnx>`_
- `Hélio Meira Lins <https://github.com/meiralins>`_
- `Parbhat Puri  <https://parbhatpuri.com/>`_
- `Fredrik Burman (coachHIPPO) <https://www.coachhippo.com>`_
- `Safe Hammad <http://safehammad.com>`_
- `Jeff Sternber <https://www.linkedin.com/in/jeffsternberg>`_
- `@MiddleFork <https://github.com/MiddleFork>`_
- `Daniel Andrlik <https://github.com/andrlik>`_
- `Kevin Abbot <https://github.com/kgabbott>`_
- `Yousuf Jawwad <https://github.com/ysfjwd>`_
- `@henhuy <https://github.com/henhuy>`_
- `Hélio Meira Lins <https://github.com/meiralins>`_
- `@utpyngo <https://github.com/utpyngo>`_
- `Anthony Monthe <https://github.com/ZuluPro>`_
- `Vincent Toupet <https://github.com/vtoupet>`_
- `Anton Ian Sipos <https://github.com/aisipos>`_
- `Chuan-Jhe Hwong <https://github.com/CJHwong>`_
- `Thomas Grainger <https://github.com/graingert/>`_
- `Ryan Smith <https://github.com/bixbyr/>`_
