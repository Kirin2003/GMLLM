.. include:: ../README.rst
   :end-before: end-here

