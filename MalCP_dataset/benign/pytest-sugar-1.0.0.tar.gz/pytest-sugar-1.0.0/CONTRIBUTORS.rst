The following people have contributed to pytest-sugar:

* Janne Vanhala
* Teemu
* Marc Abramowitz
* `Justin Mayer <https://justinmayer.com>`_
* Yizhe Tang
* Mahdi Yusuf
* dscerri
* Mounier Florian
* Balthazar Rouberol
* Michael Howitz
