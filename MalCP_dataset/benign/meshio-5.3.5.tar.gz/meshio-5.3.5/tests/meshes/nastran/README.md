`cylinder.fem` is a HyperMesh-generated Optistruct (Nastran-like) mesh file. It contains the same mesh information as that in `../med/cylinder.med`.
