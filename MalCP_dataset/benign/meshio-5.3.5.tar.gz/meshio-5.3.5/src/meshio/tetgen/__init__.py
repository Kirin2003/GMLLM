from ._tetgen import read, write

__all__ = ["read", "write"]
