=====
Usage
=====

To use uuid7 in a project::

    import uuid7
