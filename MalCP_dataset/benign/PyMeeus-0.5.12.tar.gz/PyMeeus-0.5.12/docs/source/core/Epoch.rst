Epoch
*****

.. automodule:: pymeeus


Class to handle time.

.. automodule:: pymeeus.Epoch
   :members:
   :special-members:

