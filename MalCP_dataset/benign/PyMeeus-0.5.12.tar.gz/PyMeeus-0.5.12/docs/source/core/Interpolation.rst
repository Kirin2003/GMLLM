Interpolation
*************

.. automodule:: pymeeus


Class to find intermediate values from those given in a table.

.. automodule:: pymeeus.Interpolation
   :members:
   :special-members:

