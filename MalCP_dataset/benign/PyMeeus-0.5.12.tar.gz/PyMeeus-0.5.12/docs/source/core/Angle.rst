Angle
*****

.. automodule:: pymeeus


Class to handle angles.

.. automodule:: pymeeus.Angle
   :members:
   :special-members:

