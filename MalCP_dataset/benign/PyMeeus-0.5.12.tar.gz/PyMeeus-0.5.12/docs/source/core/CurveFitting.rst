Curveffiting
************

.. automodule:: pymeeus


Class to get the best fit of a curve to a set of (x, y) points.

.. automodule:: pymeeus.CurveFitting
   :members:
   :special-members:

