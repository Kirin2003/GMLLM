Base
****

.. automodule:: pymeeus


Basic, general functions and constants.

.. automodule:: pymeeus.base
   :members:
   :special-members:

