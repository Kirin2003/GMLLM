Jupiter
*******

.. automodule:: pymeeus


Class to model Jupiter planet.

.. automodule:: pymeeus.Jupiter
   :members:
   :special-members:

