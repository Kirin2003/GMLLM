Mercury
*******

.. automodule:: pymeeus


Class to model Mercury planet.

.. automodule:: pymeeus.Mercury
   :members:
   :special-members:

