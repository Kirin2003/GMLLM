Minor
*****

.. automodule:: pymeeus


Class to model minor celestial objetcs.

.. automodule:: pymeeus.Minor
   :members:
   :special-members:

