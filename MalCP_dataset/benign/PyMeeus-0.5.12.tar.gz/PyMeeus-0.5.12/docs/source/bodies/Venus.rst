Venus
*****

.. automodule:: pymeeus


Class to model Venus planet.

.. automodule:: pymeeus.Venus
   :members:
   :special-members:

