Earth
*****

.. automodule:: pymeeus


Class to model Earth's globe.

.. automodule:: pymeeus.Earth
   :members:
   :special-members:

