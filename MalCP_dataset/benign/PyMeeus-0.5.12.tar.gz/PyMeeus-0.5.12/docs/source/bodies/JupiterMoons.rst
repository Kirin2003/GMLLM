JupiterMoons
**************

Class to model JupiterMoons.

.. automodule:: pymeeus.JupiterMoons
   :members:
   :special-members:

