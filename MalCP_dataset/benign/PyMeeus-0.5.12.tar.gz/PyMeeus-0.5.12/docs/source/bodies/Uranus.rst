Uranus
******

.. automodule:: pymeeus


Class to model Uranus planet.

.. automodule:: pymeeus.Uranus
   :members:
   :special-members:

