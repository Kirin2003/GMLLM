Saturn
******

.. automodule:: pymeeus


Class to model Saturn planet.

.. automodule:: pymeeus.Saturn
   :members:
   :special-members:

