Mars
****

.. automodule:: pymeeus


Class to model Mars planet.

.. automodule:: pymeeus.Mars
   :members:
   :special-members:

