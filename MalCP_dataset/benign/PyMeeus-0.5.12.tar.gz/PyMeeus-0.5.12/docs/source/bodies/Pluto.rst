Pluto
*****

.. automodule:: pymeeus


Class to model Pluto planet.

.. automodule:: pymeeus.Pluto
   :members:
   :special-members:

