Neptune
*******

.. automodule:: pymeeus


Class to model Neptune planet.

.. automodule:: pymeeus.Neptune
   :members:
   :special-members:

