class NRRDError(Exception):
    """Exceptions for NRRD class."""
    pass
