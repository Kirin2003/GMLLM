# SPDX-License-Identifier: Apache-2.0

# ONNXMLTools common code has been refactored into onnxconverter-common.
