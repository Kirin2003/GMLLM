# SPDX-License-Identifier: Apache-2.0

# To register shape calculators for lightgbm operators, import associated modules here.
from . import Classifier
from . import Regressor
