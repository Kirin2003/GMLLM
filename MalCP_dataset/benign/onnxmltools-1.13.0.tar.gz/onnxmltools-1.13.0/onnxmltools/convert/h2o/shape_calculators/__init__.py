# SPDX-License-Identifier: Apache-2.0

# To register shape calculators for lightgbm operators, import associated modules here.
from . import h2otreemojo
