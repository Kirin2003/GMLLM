# -*- coding: utf-8 -*-
# Much of the code here was forked from https://github.com/codelucas/newspaper
# Copyright (c) Lucas Ou-Yang (codelucas)

"""
To change the version of entire package, just edit this one location.
"""
# version 0.9.3.1
version_info = (0, 9, 3, 1)
__version__ = ".".join(map(str, version_info))
