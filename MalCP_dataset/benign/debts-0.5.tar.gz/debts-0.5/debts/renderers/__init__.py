from . import html
from . import simple_text

RENDERERS = {"html": html, "simple_text": simple_text}
