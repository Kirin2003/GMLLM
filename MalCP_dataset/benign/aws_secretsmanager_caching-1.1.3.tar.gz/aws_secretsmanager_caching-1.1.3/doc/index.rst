AWS Secrets Manager Python Caching Client
=========================================

This package provides a client-side caching implementation for AWS Secrets Manager

Modules
_______

.. autosummary::
    :toctree: _autosummary

    .. Add/replace module names you want documented here
    aws_secretsmanager_caching



Indices and tables
__________________

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
