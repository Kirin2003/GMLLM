# Credits

The `flask-redis` project is written and maintained
by [Bence Nagy (underyx)](https://underyx.me).

The project was originally created by [Rhys Elsmore](https://rhys.io/),
who maintained it until the 0.0.6 release in 2014.
His work was licensed under the Apache 2 license.
The project has gone through a full rewrite since,
but his work was essential as inspiration.
Thanks, Rhys!

A full list of contributors can be found on [GitHub's Contributors page](https://github.com/underyx/flask-redis/graphs/contributors)
or you can obtain it on your own by running `git shortlog -sn`.
