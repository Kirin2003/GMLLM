This package has changed names.

Please use [sqlalchemy-cockroachdb](https://pypi.org/project/sqlalchemy-cockroachdb/).
