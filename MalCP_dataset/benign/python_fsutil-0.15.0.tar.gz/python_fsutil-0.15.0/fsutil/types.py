from __future__ import annotations

import pathlib
from typing import Union

PathIn = Union[str, pathlib.Path]
