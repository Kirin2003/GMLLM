"""Support migrations for Peewee ORM."""
from __future__ import annotations

from .router import Migrator, Router

__all__ = "Migrator", "Router"
