from __future__ import annotations

from peewee_migrate.cli import cli

cli()
