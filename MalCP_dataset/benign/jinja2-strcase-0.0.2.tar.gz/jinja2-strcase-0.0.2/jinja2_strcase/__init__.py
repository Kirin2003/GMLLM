  
# -*- coding: utf-8 -*-

from .jinja2_strcase import StrcaseExtension

__author__ = 'Marek Chmiel'
__version__ = '0.0.2'

__all__ = ['StrcaseExtension']
