"""Protobuf definitions for testing."""
