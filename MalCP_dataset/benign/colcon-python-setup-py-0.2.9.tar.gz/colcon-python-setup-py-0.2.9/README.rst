colcon-python-setup-py
======================

An extension for `colcon-core <https://github.com/colcon/colcon-core>`_ to identify packages with a ``setup.py`` file by introspecting the arguments to the ``setup()`` function call of  `setuptools <https://setuptools.readthedocs.io/en/latest/>`_.
