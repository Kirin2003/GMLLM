class CurrentlyNotSupported(Exception):
    pass
