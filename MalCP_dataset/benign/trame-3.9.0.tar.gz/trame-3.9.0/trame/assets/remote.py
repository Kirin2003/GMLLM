from trame_common.assets.remote import AbstractRemoteFile, GoogleDriveFile, HttpFile

__all__ = [
    "AbstractRemoteFile",
    "GoogleDriveFile",
    "HttpFile",
]
