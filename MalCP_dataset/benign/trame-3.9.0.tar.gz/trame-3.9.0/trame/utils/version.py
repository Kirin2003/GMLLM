from trame_common.utils.version import get_version

__all__ = [
    "get_version",
]
