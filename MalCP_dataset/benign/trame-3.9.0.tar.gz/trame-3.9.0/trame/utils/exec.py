from trame_common.exec.throttle import Throttle

__all__ = [
    "Throttle",
]
