from trame_common.obj.widget import create_class

__all__ = [
    "create_class",
]
