"""
Moved to trame.assets.mimetypes
"""
