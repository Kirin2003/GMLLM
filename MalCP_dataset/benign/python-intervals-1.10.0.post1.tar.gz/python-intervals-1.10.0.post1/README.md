# Python data structure and operations for intervals

This library provides data structure and operations for intervals in Python 2.7+ and Python 3.4+.

**`python-intervals` has been renamed to `portion`:**

 - On PyPI: [https://pypi.org/project/portion](https://pypi.org/project/portion)
 - On GitHub: [https://github.com/AlexandreDecan/portion](https://github.com/AlexandreDecan/portion)

Please consult these pages for more information!

You can still use `python-intervals` but it won't be updated.
The documentation of its latest release is available on [https://github.com/AlexandreDecan/portion/blob/1.10.0/README.md](https://github.com/AlexandreDecan/portion/blob/1.10.0/README.md).
