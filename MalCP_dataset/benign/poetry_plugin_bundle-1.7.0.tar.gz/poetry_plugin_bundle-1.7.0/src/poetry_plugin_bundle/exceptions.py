from __future__ import annotations


class BundlerManagerError(Exception):
    pass
