VERSION = (1, 3, 0)


def get_version():
    return ".".join(str(i) for i in VERSION)
