Internal HTTP Client Reference
----------------------

### `encoding`

```eval_rst
.. automodule:: ipfshttpclient.encoding
    :members:
    :show-inheritance:

```

### `http`

```eval_rst
.. automodule:: ipfshttpclient.http
    :members:
    :show-inheritance:

```

### `multipart`

```eval_rst
.. automodule:: ipfshttpclient.multipart
    :members:
    :show-inheritance:

```

### `utils`

```eval_rst
.. automodule:: ipfshttpclient.utils
    :members:
    :show-inheritance:

```
