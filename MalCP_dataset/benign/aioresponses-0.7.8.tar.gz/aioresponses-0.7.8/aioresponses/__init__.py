# -*- coding: utf-8 -*-
from .core import CallbackResult, aioresponses

__version__ = '0.7.8'

__all__ = [
    'CallbackResult',
    'aioresponses',
]
