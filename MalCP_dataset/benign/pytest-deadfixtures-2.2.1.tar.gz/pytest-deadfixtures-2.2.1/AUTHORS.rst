=======
Credits
=======

Maintainers
----------------

* João Luiz Lorencetti - `@jllorencetti`_

Contributors
------------

* Jair Henrique - `@jairhenrique`_
* Tawonga - `@tawonga`_

.. _`@jllorencetti`: https://github.com/jllorencetti
.. _`@jairhenrique`: https://github.com/jairhenrique
.. _`@tawonga`: https://github.com/tawonga
.. _`@MatheusBrochi`: https://github.com/MatheusBrochi
