.. include:: ../README.rst

.. toctree::
   :maxdepth: 2

   migration
   api
   helpers
   changelog



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
