.. Changelog transcluded from the changelog at the repo root

=========
Changelog
=========

.. include:: ../CHANGELOG.rst
