Version 0.1.0 (2020-06-16)
==========================

This is the first release of ``pytz-deprecation-shim``.


Post-releases:
--------------

- ``0.1.0.post0`` (2020-06-17): Fixes the ``project_urls`` metadata to point to
  the correct bug tracker and documentation.
