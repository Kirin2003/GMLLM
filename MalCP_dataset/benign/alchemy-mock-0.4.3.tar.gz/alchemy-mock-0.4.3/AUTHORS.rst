Credits
-------

Development Lead
~~~~~~~~~~~~~~~~

* Miroslav Shubernetskiy  - https://github.com/miki725

Contributors
~~~~~~~~~~~~

* Serkan Hoscai - https://github.com/shosca
