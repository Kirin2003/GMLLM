# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals


__version__ = "0.4.3"
__description__ = "SQLAlchemy mock helpers."
__author__ = "Miroslav Shubernetskiy"
