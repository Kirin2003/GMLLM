from flask_executor.executor import Executor


__all__ = ('Executor',)
__version__ = '1.0.0'
