from flask.views import MethodView as MethodView
from flask.views import View as View
