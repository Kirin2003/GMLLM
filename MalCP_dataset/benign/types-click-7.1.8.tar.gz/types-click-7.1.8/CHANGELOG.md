## 7.1.8 (2021-11-23)

Reduce use of deprecated `typing` aliases (#6358)

## 7.1.7 (2021-10-15)

Use lowercase tuple where possible (#6170)

## 7.1.6 (2021-10-12)

Add star to all non-0.1 versions (#6146)

