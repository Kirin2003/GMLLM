__author__ = "Fabio Caccamo"
__copyright__ = "Copyright (c) 2016-present Fabio Caccamo"
__description__ = (
    "django's default admin interface with superpowers - "
    "customizable themes, popup windows replaced by modals and many other features."
)
__email__ = "fabio.caccamo@gmail.com"
__license__ = "MIT"
__title__ = "django-admin-interface"
__version__ = "0.30.0"
