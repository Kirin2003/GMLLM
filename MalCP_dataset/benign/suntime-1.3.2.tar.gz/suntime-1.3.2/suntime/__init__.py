from .suntime import Sun, SunTimeException

__version__ = '1.3.2'
__author__ = 'Krzysztof Stopa'
__license__ = 'LGPLv3'
