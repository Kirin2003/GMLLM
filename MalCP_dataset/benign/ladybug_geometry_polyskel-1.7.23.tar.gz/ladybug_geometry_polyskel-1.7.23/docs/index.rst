Welcome to Ladybug Geometry Polyskel's documentation!
===================================

.. image:: http://www.ladybug.tools/assets/img/ladybug.png

A library with straight skeleton methods using ladybug-geometry.

Installation
============

``pip install -U ladybug-geometry-polyskel``

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. include:: modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
