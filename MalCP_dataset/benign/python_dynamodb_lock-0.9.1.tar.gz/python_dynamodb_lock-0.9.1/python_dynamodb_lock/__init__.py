# -*- coding: utf-8 -*-

"""The package contains a single module - with the same name i.e. python_dynamodb_lock"""

__author__ = """Mohan Kishore"""
__email__ = 'mohankishore@yahoo.com'
__version__ = '0.9.1'
__copyright__ = 'Copyright (C) 2018 Mohan Kishore'
