# -*- coding: utf-8 -*-

"""Unit test package for python_dynamodb_lock."""
