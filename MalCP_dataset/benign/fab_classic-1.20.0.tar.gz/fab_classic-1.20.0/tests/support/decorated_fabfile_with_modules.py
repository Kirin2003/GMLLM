from fabric.decorators import task
from support import module_fabtasks as tasks

@task
def foo():
    pass

def bar():
    pass
