class UnsupportedContent(Exception):
    pass


class UnsupportedParam(Exception):
    pass
