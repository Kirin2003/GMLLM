# All values must be strings and quoted with singlequote (').
__version__ = '1.0.5'
__author__ = 'Omar Bohsali'
__authoremail__ = 'me@omarish.com'
