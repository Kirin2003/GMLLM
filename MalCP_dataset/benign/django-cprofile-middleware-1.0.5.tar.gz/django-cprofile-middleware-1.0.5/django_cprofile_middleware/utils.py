# -*- coding: utf-8 -*-
"""This module contain utils class"""


class MiddlewareMixin(object):
    """A dummy class to support older version of django."""
    pass
