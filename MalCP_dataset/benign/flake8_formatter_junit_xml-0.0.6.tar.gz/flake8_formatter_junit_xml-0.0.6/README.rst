==========================
flake8-formatter-junit-xml
==========================
.. image:: https://img.shields.io/pypi/v/flake8-formatter-junit-xml.svg
    :target: https://pypi.python.org/pypi/flake8-formatter-junit-xml
.. image:: https://travis-ci.org/astj/flake8-formatter-junit-xml.svg
    :target: https://travis-ci.org/astj/flake8-formatter-junit-xml

JUnit XML Formatter for flake8.

Installation
============

.. code::

    pip install flake8_formatter_junit_xml

Usage
=====

.. code::

    flake8 --format junit-xml ...

License
=======

MIT
