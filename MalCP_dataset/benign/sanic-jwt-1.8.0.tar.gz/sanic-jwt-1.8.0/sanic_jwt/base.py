class BaseDerivative:
    def __init__(self, config, instance, *args, **kwargs):
        self.config = config
        self.instance = instance
