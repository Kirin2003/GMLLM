"""WebHelpers2 is wide variety of functions for web applications and other
applications.
"""

__version__ = "2.1"
