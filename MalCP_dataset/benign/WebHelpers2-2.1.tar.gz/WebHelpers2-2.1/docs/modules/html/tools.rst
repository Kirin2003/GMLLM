:mod:`webhelpers2.html.tools`
================================================

.. automodule:: webhelpers2.html.tools

.. currentmodule:: webhelpers2.html.tools

.. autofunction:: auto_link

.. autofunction:: button_to

.. autofunction:: highlight

.. autofunction:: html_to_text

.. autofunction:: js_obfuscate

.. autofunction:: mail_to

.. autofunction:: nl2br

.. autofunction:: sanitize

.. autofunction:: strip_links

.. autofunction:: strip_tags

.. autofunction:: text_to_html

.. autofunction:: update_params
