:mod:`webhelpers2.date`
================================================

.. automodule:: webhelpers2.date

.. currentmodule:: webhelpers2.date

.. autofunction:: distance_of_time_in_words
.. autofunction:: time_ago_in_words
