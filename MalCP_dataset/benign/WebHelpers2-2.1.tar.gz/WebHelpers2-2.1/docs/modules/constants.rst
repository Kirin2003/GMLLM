:mod:`webhelpers2.constants`
================================================

.. automodule:: webhelpers2.constants

.. currentmodule:: webhelpers2.constants

Countries
---------

.. autofunction:: country_codes

States & Provinces
------------------

.. autofunction:: us_states
.. autofunction:: us_territories
.. autofunction:: canada_provinces
.. autofunction:: uk_counties
