API Reference
=============

.. module:: tinyhtml5

.. autofunction:: parse
