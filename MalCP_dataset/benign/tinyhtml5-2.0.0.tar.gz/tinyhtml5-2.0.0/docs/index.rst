tinyhtml5
=========

.. currentmodule:: tinyhtml5

.. include:: ../README.rst

.. toctree::
   :caption: Documentation
   :maxdepth: 3

   first_steps
   common_use_cases
   api_reference
   going_further

.. toctree::
   :caption: Extra Information
   :maxdepth: 3

   changelog
   contribute
   support
