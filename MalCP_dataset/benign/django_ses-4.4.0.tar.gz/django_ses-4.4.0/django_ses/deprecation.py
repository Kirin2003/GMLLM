
class RemovedInDjangoSES20Warning(DeprecationWarning):
    pass
