#!/usr/bin/env python
from setuptools import setup

setup(
    name="WsgiDAV",  # GitHub dependants needs it here?
    # See setup.cfg
)
