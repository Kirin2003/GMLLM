.. WSGIProxy2 documentation master file, created by
   sphinx-quickstart on Sat Dec 22 15:44:24 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

======================================
Welcome to WSGIProxy2's documentation!
======================================

.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   proxies
   clients

.. include:: ../CHANGES.rst
