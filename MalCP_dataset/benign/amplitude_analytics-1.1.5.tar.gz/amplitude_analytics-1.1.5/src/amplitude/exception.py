class InvalidEventError(Exception):
    """Raise for track invalid event"""


class InvalidAPIKeyError(Exception):
    """Invalid API key"""
