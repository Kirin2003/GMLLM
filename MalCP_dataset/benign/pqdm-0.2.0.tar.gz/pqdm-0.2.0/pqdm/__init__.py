"""Top-level package for Parallel TQDM."""

__author__ = """Piotr Szymański"""
__email__ = 'niedakh@gmail.com'
__version__ = '0.2.0'
