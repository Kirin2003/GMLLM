=======
History
=======

0.2.0 (2022-02-14)
------------------

* Adds exception handling
* Allows using custom tqdm_class (like tqdm_discord)
* Minor fixes


0.1.0 (2020-03-07)
------------------

* Some updates in progress reporting and documentation.

0.0.1 (2020-03-05)
------------------

* First release on PyPI.
