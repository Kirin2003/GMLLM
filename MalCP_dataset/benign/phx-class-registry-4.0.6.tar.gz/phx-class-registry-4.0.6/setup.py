from setuptools import setup

if __name__ == '__main__':
    # :see: https://stackoverflow.com/a/62983901
    setup()
