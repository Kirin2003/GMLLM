## 0.6.1 (16 September 2017)

BUG FIXES:

* Dict Config fixes: ([#48](https://github.com/martinrusev/django-redis-sessions/issues/48))


## 0.6 (6 September 2017)


IMPROVEMENTS / BREAKING CHANGES:

 * Dict config: ([#18](https://github.com/martinrusev/django-redis-sessions/issues/18))


## 0.5.6 (9 June 2016)


IMPROVEMENTS:

 * Redis Sentinel support: ([#29](https://github.com/martinrusev/django-redis-sessions/pull/29))
