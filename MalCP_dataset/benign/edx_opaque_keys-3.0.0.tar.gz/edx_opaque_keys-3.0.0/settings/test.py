from .base import *

INSTALLED_APPS = INSTALLED_APPS + ('opaque_keys.edx.django.tests',)
