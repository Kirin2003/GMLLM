from flake8_django.checker import DjangoStyleChecker  # noqa: F401
