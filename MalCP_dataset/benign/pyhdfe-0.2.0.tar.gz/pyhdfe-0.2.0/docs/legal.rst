Legal
-----

.. include:: ../LICENSE.txt
