Contributing
============

Please use the `GitHub issue tracker <https://github.com/jeffgortmaker/pyhdfe/issues>`_ to report bugs or to request features. Contributions are welcome. Examples include:

- Code optimizations.
- Documentation improvements.
- Alternate algorithms that have been implemented in the literature but not in PyHDFE.
