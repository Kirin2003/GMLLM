Introduction
============

.. note::

   This package is in beta. In future versions, the API may change substantially. Please use the `GitHub issue tracker <https://github.com/jeffgortmaker/pyhdfe/issues>`_ to report bugs or to request features.

.. include:: ../README.rst
   :start-after: docs-start
