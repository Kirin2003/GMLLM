Version Notes
=============

These notes will only include major changes.


0.2
---

- Initial support for weights.


0.1
---

- Initial release.
