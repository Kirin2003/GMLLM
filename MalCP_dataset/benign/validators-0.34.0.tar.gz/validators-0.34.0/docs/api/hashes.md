# hashes

::: validators.hashes.md5
::: validators.hashes.sha1
::: validators.hashes.sha224
::: validators.hashes.sha256
::: validators.hashes.sha384
::: validators.hashes.sha512
