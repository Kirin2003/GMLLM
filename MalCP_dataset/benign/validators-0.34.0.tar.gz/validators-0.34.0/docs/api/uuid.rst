uuid
----

.. module:: validators.uuid
.. autofunction:: uuid
