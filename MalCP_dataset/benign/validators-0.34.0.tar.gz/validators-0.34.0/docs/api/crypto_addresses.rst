crypto_addresses
----------------

.. module:: validators.crypto_addresses
.. autofunction:: bsc_address
.. autofunction:: btc_address
.. autofunction:: eth_address
.. autofunction:: trx_address
