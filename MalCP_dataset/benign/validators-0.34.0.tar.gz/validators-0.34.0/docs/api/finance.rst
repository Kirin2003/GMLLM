finance
-------

.. module:: validators.finance
.. autofunction:: cusip
.. autofunction:: isin
.. autofunction:: sedol
