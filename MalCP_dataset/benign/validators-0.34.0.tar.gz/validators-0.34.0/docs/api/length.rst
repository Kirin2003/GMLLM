length
------

.. module:: validators.length
.. autofunction:: length
