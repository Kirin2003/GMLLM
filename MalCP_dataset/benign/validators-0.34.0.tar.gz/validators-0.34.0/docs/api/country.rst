country
-------

.. module:: validators.country
.. autofunction:: calling_code
.. autofunction:: country_code
.. autofunction:: currency
