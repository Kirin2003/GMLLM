slug
----

.. module:: validators.slug
.. autofunction:: slug
