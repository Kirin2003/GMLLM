# encoding

::: validators.encoding.base16
::: validators.encoding.base32
::: validators.encoding.base58
::: validators.encoding.base64
