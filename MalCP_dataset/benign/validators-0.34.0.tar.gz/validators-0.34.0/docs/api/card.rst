card
----

.. module:: validators.card
.. autofunction:: amex
.. autofunction:: card_number
.. autofunction:: diners
.. autofunction:: discover
.. autofunction:: jcb
.. autofunction:: mastercard
.. autofunction:: unionpay
.. autofunction:: visa
