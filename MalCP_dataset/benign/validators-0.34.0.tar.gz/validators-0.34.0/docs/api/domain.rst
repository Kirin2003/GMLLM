domain
------

.. module:: validators.domain
.. autofunction:: domain
