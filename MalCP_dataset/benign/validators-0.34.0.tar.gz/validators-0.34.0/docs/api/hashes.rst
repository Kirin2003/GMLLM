hashes
------

.. module:: validators.hashes
.. autofunction:: md5
.. autofunction:: sha1
.. autofunction:: sha224
.. autofunction:: sha256
.. autofunction:: sha384
.. autofunction:: sha512
