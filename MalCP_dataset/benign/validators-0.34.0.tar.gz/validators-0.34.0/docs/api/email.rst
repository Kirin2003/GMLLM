email
-----

.. module:: validators.email
.. autofunction:: email
