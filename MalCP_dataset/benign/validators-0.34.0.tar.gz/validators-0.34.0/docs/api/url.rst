url
---

.. module:: validators.url
.. autofunction:: url
