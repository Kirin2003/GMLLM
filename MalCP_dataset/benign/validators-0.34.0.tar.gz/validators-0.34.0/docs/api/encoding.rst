encoding
--------

.. module:: validators.encoding
.. autofunction:: base16
.. autofunction:: base32
.. autofunction:: base58
.. autofunction:: base64
