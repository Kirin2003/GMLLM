cron
----

.. module:: validators.cron
.. autofunction:: cron
