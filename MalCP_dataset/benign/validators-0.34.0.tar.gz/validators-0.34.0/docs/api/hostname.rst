hostname
--------

.. module:: validators.hostname
.. autofunction:: hostname
