utils
-----

.. module:: validators.utils
.. autofunction:: ValidationError
.. autofunction:: validator
