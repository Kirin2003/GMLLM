
class Tst:
    var1: int = 99

    class Nested:
        x: int = 4

    def method(self, fff: list):
        self.xyz :int = 100
        qwerty : dict = {}
        self.nested.x : int = 3
        self.nested.x : int

    @property
    def size():
        size: int = -1
        return size

