

def simp(x, y) -> int \
     :
    def q(x: int=4):
        z: list=[3]


