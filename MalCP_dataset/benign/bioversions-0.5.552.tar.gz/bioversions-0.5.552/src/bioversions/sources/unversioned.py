# -*- coding: utf-8 -*-

"""A collection of unversioned resources."""

# TODO
