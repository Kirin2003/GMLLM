# Errors

- failed to resolve DisGeNet
- failed to resolve Antibody Registry
- failed to resolve DrugBank