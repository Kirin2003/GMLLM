# marshmallow3-annotations

This is a fork of [marshmallow-annotations](https://github.com/justanr/marshmallow-annotations) which has been minimally
patched to be marshmallow 3.0.0+ compatible. All credit goes to the original author.

It is available on [PyPI](https://pypi.org/project/marshmallow3-annotations/).
