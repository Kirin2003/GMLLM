from blue import main

main()
