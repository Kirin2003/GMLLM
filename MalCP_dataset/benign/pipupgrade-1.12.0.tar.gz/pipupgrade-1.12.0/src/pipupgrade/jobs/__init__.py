jobs = [
    {
        "name": "build_dependency_tree"
    },
    {
        "name": "build_proxy_list"
    }
]