class PipupgradeError(Exception):
    pass

class DependencyNotFoundError(ImportError):
    pass