def test_imports():
    from pipupgrade import (
        __name__    as _,
        __version__ as _,
        __author__  as _,
        main        as _
    )