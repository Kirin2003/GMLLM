def test_registry():
    pass