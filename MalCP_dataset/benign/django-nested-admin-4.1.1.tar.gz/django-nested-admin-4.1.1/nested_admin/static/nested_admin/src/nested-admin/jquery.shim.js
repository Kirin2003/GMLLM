export default window.django.jQuery;
