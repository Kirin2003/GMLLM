from dbt.adapters.events.logging import AdapterLogger

logger = AdapterLogger('dbt_clickhouse')
