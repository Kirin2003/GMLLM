# Copyright 2017 - 2020 Avram Lubkin, All Rights Reserved

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

"""
Bad Module that will raise syntax error when imported
"""

# Bad syntax, left off  colon and didn't finish statement
for key in []  # noqa: E999
