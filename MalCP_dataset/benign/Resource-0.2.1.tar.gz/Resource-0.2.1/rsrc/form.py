#!/usr/bin/env python
# -*- coding: utf-8 -*-

from jsonform import JsonForm


class Form(JsonForm):
    schema = {}
