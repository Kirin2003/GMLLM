CUSTOM_CONFUSABLE_PATH = "assets/custom_confusables.txt"
CONFUSABLES_PATH = "assets/confusables.txt"
CONFUSABLE_MAPPING_PATH = "assets/confusable_mapping.json"
MAX_SIMILARITY_DEPTH = 2
NON_NORMAL_ASCII_CHARS = ['@']
