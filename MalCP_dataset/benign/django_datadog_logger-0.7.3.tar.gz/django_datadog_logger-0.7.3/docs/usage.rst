=====
Usage
=====

To use Django DataDog Logger in a project::

    import django_datadog_logger
