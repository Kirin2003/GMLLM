## 2.11.9 (2021-11-26)

Add mypy error codes to '# type: ignore' comments (#6379)

## 2.11.8 (2021-10-15)

Use lowercase tuple where possible (#6170)

## 2.11.7 (2021-10-12)

Add star to all non-0.1 versions (#6146)

