History
-------

1.0.3 (2020-10-26)
==================
* Add base36 and base36 upper encodings
* Fix issue with base16 encoding

1.0.0 (2018-10-19)
==================

* Re-implement encoding for base32 and base64, as the implementation was buggy
* Add extensive tests for all encodings

0.1.0 (2017-09-02)
==================

* First release on PyPI.
