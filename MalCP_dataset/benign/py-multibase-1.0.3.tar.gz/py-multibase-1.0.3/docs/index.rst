.. include:: ../README.rst


Table of contents
=================

.. toctree::
   :maxdepth: 2

   index
   installation
   api_reference
   contributing
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
