=======
History
=======

0.1.0 (2019-10-24)
------------------

* First release on PyPI.
