"""Test suite for the maison package."""
