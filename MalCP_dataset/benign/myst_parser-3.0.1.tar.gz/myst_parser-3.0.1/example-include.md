[Used in how-to](docs/faq/index.md)
![alt](docs/_static/logo-wide.svg)
