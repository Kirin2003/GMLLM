# Security Policy

I do not expect any security issues in this package.

## Supported Versions

Only the latest release is supported. I will not backport fixes.

## Reporting a Vulnerability

Contact me at tiposchi@tiscali.it

My PGP key is on this file, on git.
debian/upstream/signing-key.asc
