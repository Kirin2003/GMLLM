2.37
====
* Do not use new syntax in any place.
  It confuses tooling

2.36
====
* Drop support for EOL versions of python
* Support typing.ReadOnly
* Add support for typing.TypeAliasType (PEP 695)

2.35
====
* Add tests to make sure mypy validation works
* Fix mypy failure when loading a Literal directly
* Remove cloudflare tracking from html documentation once again -_-'
  Thanks mkdocs for this.
* Improve documentation
* Improve typechecks

2.34
====
* Support Required for TypedDict

2.33
====
* Make example more current
* Fix bug with dumping dataclasses with slots

2.32
====
* Improve performance for loading unions of objects [#12](https://codeberg.org/ltworf/typedload/pulls/12)
* Improve performance for dumping dataclasses [#13](https://codeberg.org/ltworf/typedload/pulls/13) [#14](https://codeberg.org/ltworf/typedload/pulls/14)
  More details on my blog

2.31
====
* Improve performance for loading various types
  More details on my blog
* Fix bug when loading attrs objects with missing attributes, the correct exception is raised [#9](https://codeberg.org/ltworf/typedload/pulls/9)
* Raise TypeError instead of ValueError when there is a problem with the arguments of the objects
  This is in line with what python does [#9](https://codeberg.org/ltworf/typedload/pulls/9)
* Fix bug for dumping object with a ForwardRef to itself [#8](https://codeberg.org/ltworf/typedload/pulls/8)

2.30
====
* Fix bug where dictionary load would fail if the type for the value wasn't
  cached already

2.29
====
* Move project to Codeberg

2.28
====
* Add support for uuid.UUID

2.27
====
* Add support for re.Patterns

2.26
====
* Update type hints file

2.25
====
* Improve performance for loading objects (attrs/dataclasses/NamedTuple)
* Improve performance for loading dictionary keys that are basic types
* Improve performance for loading dataclasses
* Switch performance tests to test against pydantic2

2.24
====
* Drop support to Python 3.7 (which has reached EOL)
* Make is_optional slightly faster
* Keep track of the index when loading iterables the first time
  It makes the normal case slightly slower, and gives massive performance
  improvements when exceptions are raised.

2.23
====
* When loading a string into datetime.date/time/datetime, ISO 8601 is used
* When dumping, setting `isodates=True` dumps an ISO 8601 string instead of a list of ints. The previous behaviour is now deprecated.
* Add support for datetime.timedelta. It is dumped as a float representing seconds
* Deprecate dump handlers without type hints
* Improve performance for dumping, by carrying type hints
* Remove `jsons` and `dataclasses-json` from benchmarks.
  They were too slow to be a useful comparison.

2.22
====
* Improve loading time for literals
* Support attrs converter

2.21
====
* Drop support to Python 3.5 and 3.6
* Improve performance for dumping
* Generate pure python wheel

2.20
====
* Switch to setuptools
  Since python decided to drop the only installation method available within the stdlib
* Add pyproject.toml

2.19
====
* Fix minor bug about exception raising from string constructed types
* Simplify type checking functions, defining only the one for the current python version
* Fix type definitions of some private functions for compatibility with cython
* Improved loading speed for dictionaries
* Improved loading speed for iterators
* Improved documentation
* Improved performance testing code

2.18
====
* Fix bug with loading generators that raise exceptions

2.17
====
* Support for NotRequired
* Document performance testing
* Improve performances when loading iterables
* Greatly improve performances when loading `Union` of objects that are `Literal` annotated

2.16
====
* Add is_optional function
* Support new style union (A | B)
* Experimental support for PEP563 `__future__.annotations`.
  **READ ABOUT DEFERRED EVALUATION IN THE DOCUMENTATION.**

2.15
====
* Union fails immediately when a non typedload exception is found
* New `make html` target to generate the website
* Updated CONTRIBUTING file, with details about new licenses from the FSF
* Handle typing.NewType

2.14
====
* Fix bug where AttributeError from name mangling caused an AssertionError

2.13
====
* Separate and simpler handlers for NamedTuple, dataclass, attrs, TypedDict
* Allow duck typing when loading attr (allow any dict-like class to be used)
* Minor performance improvements

2.12
====
* Add `uniondebugconflict` flag to detect unions with conflicts.

2.11
====
* Make newer mypy happy

2.10
====
* Fix setup.py referring to a non-existing file when installing with pip

2.9
===
* Use README on pypi.org
* Tiny speed improvement
* Expanded and improved documentation

2.8
===
* Better report errors for `Enum`
* Improve support for inheritance with mixed totality of `TypedDict` (requires Python 3.9)

2.7
===
* failonextra triggers failure when dropping fields in mangling
* Support for `total=False` in `TypedDict`
* Support `init=False` in `dataclass` field

2.6
===
* Handle `Any` types as passthrough
* Easy way to handle types loaded from and dumped to `str`
* Improve how exceptions are displayed

2.5
===
* Fix dump for attr classes with factory
* Let name mangling use arbitrary metadata fields rather than just `name`

2.4
===
* Support for `ipaddress.IPv4Address`, `ipaddress.IPv6Address`,
  `ipaddress.IPv4Network`, `ipaddress.IPv6Network`,
  `ipaddress.IPv4Interface`, `ipaddress.IPv6Interface`.

2.3
===
* Better type sorting in `Union`
  This helps when using `Union[dataclass, str]`

2.2
===
* Add Python3.9 to the supported versions
* Prevent loading dict as `List`, `Tuple`, `Set`
  This helps when using `Union[Dict, List]` to take the correct
  type.

2.1
===
* Written new usage example
* typechecks internals now pass with more mypy configurations
* Fix `import *`

2.0
===
* Breaking API change: handlers can only be modified before the first load
* Breaking API change: plugins removed (attr support is by default)
* Exceptions contain more information
* Greatly improve performances with iterables types
* Support for `pathlib.Path`

1.20
====
* Drop support for Python 3.5.2 (3.5 series is still supported)
* Support `TypedDict`
* More precise type annotation of `TypedloadException` and `Annotation` fields
* Deprecate the plugin to handle `attr.s` and make it always supported.
  This means that there will be no need for special code.
* Fix datetime loader raising exceptions with the wrong type

1.19
====
* Add support for `Literal`.

1.18
====
* Improved documentation
* Debian builds are now done source only

1.17
====
* Prefer the same type in union loading

1.16
====
* New `uniontypes()` function.
* Make list and dictionary loaders raise the correct exceptions
* Able to load from `argparse.Namespace`

1.15
====
* Add support for `FrozenSet[T]`.
* Define `__all__` for typechecks.
* Add name mangling support in dataclass, to match attrs.
* Add support for `datetime.date`, `datetime.time`, `datetime.datetime`

1.14
====
* Add support for `Tuple[t, ...]`

1.13
====
* Fix bug in loading attr classes and passing random crap.
  Now the proper exception is raised.
* New module to expose the internal type checks functions

1.12
====
* Support fields with factory for dataclass

1.11
====
* Fixed problem when printing sub-exceptions of failed unions
* Improve documentation

1.10
====
* Make mypy happy again

1.9
===
* Support `ForwardRef`
* Add a new Exception type with more details on the error (no breaking API changes)

1.8
===
* Make mypy happy again

1.7
===
* Make mypy happy again

1.6
===
* Run tests on older python as well
* Support for dataclass (Since python 3.7)
* Added methods to find the appropriate handlers

1.5
===
* Improve handling of unions
* Better continuous integration
* Support python 3.7

1.4
===
* Add support for name mangling in attr plugin
* Parameters can be passed as kwargs
* Improved exception message for `NamedTuple` loading

1.3
===
* Add support for Python < 3.5.3

1.2
===
* Ship the plugins in pypy

1.1
===
* Able to load and dump old style `NamedTuple`
* Support for Python 3.5
* Target to run mypy in makefile
* Refactor to support plugins. The API is still compatible.
* Plugin for the attr module, seems useful in Python 3.5

1.0
===
* Has a setting to hide default fields or not, in dumps
* Better error reporting
* Add file for PEP 561

0.9
===
* Initial release
