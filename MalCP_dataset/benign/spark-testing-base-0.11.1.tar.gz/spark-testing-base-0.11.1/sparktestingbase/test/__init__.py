"""
Simple tests using spark-testing-base.
"""
