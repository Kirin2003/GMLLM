from .send_invoice import SendInvoice


class Payments(SendInvoice):
    pass
