from typing_extensions import Final

#: marker/tag indicating that marked test is a Django's migration test
MIGRATION_TEST_MARKER: Final = 'migration_test'
