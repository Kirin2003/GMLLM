__version__ = "0.5.0"

from .fnv_impl import fnv1a_32

__all__ = ["fnv1a_32"]
