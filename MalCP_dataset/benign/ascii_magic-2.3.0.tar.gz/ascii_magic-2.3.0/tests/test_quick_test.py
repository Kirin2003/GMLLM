from ascii_magic import AsciiArt


def test_quick_test():
    AsciiArt.quick_test()
