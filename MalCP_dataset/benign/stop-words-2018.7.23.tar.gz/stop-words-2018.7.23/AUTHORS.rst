``python-stop-words`` was originally created in middle 2014 at home, the bedroom
division of the Alireza's place somewhere on planet earth maybe.

The PRIMARY AUTHORS are (and/or have been):

* Alireza Savand <alireza.savand@gmail.com>
* François‎

And here is an inevitably incomplete list of MUCH-APPRECIATED CONTRIBUTORS --
people who have submitted patches, reported bugs, added translations, helped
answer newbie questions, and generally made ``python-stop-words`` that much better:

* Alireza Savand <alireza.savand@gmail.com>
* Julien Fache <fantomas42@gmail.com>
* David Miró <lite.3engine@gmail.com>
* Taras Labiak <kissarat@gmail.com>


A big THANK YOU goes to:

* François‎ for convincing Alireza to start the project.
* Guido van Rossum for creating Python.
