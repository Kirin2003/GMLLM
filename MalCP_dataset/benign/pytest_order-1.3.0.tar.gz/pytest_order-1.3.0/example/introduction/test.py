"""Reference test without ordering from the quick start chapter.
See https://pytest-order.readthedocs.io/en/stable/intro.html#quickstart
"""


def test_foo():
    assert True


def test_bar():
    assert True
