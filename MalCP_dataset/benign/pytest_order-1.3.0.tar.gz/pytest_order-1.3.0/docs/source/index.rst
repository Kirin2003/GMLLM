pytest-order - a plugin to order test execution
===============================================

Content of the documentation
----------------------------

.. toctree::
   :maxdepth: 2

   intro
   usage
   configuration
   other_plugins
