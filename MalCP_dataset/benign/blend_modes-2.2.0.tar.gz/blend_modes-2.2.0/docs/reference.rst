Reference
=========

.. automodule:: blend_modes.blending_functions
    :members: