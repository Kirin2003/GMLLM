import logging

log = logging.getLogger(__name__)

# directory paths
DIR_DATA = "data"
DIR_CONFIG = "config"
