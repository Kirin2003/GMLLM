"""
Test initialisation
"""
