"""
Support for fitting objects to data, and testing whether an object is fitted.
"""

from ._fit import *
