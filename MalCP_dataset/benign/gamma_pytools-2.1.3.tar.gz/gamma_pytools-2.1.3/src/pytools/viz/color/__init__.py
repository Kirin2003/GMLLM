"""
Color definitions.
"""
from ._color import *
from ._rgb import *
