"""
Plotting distributions for exploratory data visualization.
"""

from ._distribution import *
