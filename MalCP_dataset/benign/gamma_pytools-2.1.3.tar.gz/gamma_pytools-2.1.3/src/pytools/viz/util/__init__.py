"""
Base and auxiliary classes for visualizations.
"""
from ._matplot import *
