"""
Plotting matrices for exploratory data visualization.
"""

from ._matrix import *
