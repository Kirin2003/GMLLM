"""
Base classes for dendrogram representations.
"""

from ._style import *
