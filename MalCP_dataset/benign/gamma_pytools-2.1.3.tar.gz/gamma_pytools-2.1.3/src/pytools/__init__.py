"""
A collection of Python extensions and tools used in BCG GAMMA's open-source libraries.
"""
__version__ = "2.1.3"
