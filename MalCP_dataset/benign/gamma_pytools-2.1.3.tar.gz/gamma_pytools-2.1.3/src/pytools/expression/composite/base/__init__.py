"""
Supporting classes for composite expressions.

Rarely used outside of module :mod:`pytools.expression.composite`.
"""
from ._base import *
