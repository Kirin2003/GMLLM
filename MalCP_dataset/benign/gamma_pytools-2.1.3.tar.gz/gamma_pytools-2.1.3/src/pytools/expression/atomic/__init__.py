"""
Atomic expressions.

Atomic expressions comprise identifiers, literal values, and the empty expression.
"""

from ._atomic import *
