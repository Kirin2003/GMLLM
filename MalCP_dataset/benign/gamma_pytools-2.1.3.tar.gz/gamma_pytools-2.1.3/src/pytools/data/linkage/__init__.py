"""
Supporting classes for linkage trees.
"""

from ._linkage import *
