from llama_index.embeddings.ollama.base import OllamaEmbedding

__all__ = ["OllamaEmbedding"]
