"""terrasnek test Base Module

This module provides all the unittests for the terrasnek endpoints.
"""

import unittest

if __name__ == '__main__':
    unittest.main()
