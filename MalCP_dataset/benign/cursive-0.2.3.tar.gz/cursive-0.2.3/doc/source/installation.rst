============
Installation
============

At the command line::

    $ pip install cursive

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv cursive
    $ pip install cursive
