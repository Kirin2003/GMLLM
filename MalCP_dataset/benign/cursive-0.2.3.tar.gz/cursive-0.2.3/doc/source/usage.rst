========
Usage
========

To use cursive in a project::

    import cursive
