"This package contains automated code tests for json_diff."
