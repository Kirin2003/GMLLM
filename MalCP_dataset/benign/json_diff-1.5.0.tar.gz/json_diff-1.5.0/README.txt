Compares two JSON files (http://json.org) and generates a new JSON file
with the result. Allows exclusion of some keys from the comparison, or
in other way to include only some keys.

The project’s website is at https://gitlab.com/mcepl/json_diff
Patches and pull requests are welcome, but please keep the script compatible
with python 2.4.

Released under MIT/X11 license.
