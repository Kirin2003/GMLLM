=======
History
=======

0.1.1 (2016-06-18)
------------------

* Update documentation

0.1.0 (2016-06-17)
------------------

* Minimum viable product

0.0.1 (2016-06-14)
------------------

* First release on PyPI.
