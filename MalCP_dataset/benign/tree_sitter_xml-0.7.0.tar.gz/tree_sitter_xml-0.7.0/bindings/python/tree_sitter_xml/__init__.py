"XML & DTD grammars for tree-sitter"

from ._binding import language_xml, language_dtd

__all__ = ["language_xml", "language_dtd"]
