# These are exceptions we retry
RETRY_EXCEPTIONS = (
    'ProvisionedThroughputExceededException',
    'ThrottlingException'
)
