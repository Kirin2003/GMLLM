
.. include:: ../../README.rst

Contents
--------

.. toctree::
   :maxdepth: 2

   gettingstarted
   api
   types
   functions
   protocols
   integrate
   document

   todo
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

