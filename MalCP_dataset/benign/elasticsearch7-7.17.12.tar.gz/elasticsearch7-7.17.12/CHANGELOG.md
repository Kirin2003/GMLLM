See: https://www.elastic.co/guide/en/elasticsearch/client/python-api/master/release-notes.html
