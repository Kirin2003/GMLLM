# dedupe-variable-datetime
DateTime variable for dedupe

Part of the [Dedupe.io](https://dedupe.io/) cloud service and open source toolset for de-duplicating and finding fuzzy matches in your data.
