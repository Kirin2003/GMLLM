=======
History
=======


0.4.1 (2021-04-21)
------------------

* Bugfix: Permissions (especially executable permissions) were not preserved on Unix


0.4.0 (2021-04-04)
------------------

* Added: options ``--exclude-vcs``, ``--exclude-git-ignores``, and ``--exclude-vcs``


0.3.0 (2020-01-19)
------------------

* Added: option ``--exclude``


0.2.0 (2020-01-17)
------------------

* Added: option ``--auto-root``


0.1.0 (2020-01-17)
------------------

* Initial release
