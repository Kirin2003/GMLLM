# integrationhelper

_A set of helpers for integrations._

## Install integrationhelper

```bash
python3 -m pip install -U integrationhelper
```
