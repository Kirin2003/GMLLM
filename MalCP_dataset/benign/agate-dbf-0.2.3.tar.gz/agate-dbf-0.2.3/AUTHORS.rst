The following individuals have contributed code to agate-excel:

* `Christopher Groskopf <https://github.com/onyxfish>`_
* `James McKinney <https://github.com/jpmckinney>`_
