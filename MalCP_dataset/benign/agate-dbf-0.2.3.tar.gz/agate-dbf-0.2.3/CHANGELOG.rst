0.2.3 - February 23, 2024
-------------------------

* Add Python 3.8, 3.9, 3.10, 3.11, 3.12 support.
* Drop support for Python 2.7 (EOL 2020-01-01), 3.4 (2019-03-18), 3.5 (2020-09-13), 3.6 (2021-12-23), 3.7 (2023-06-27).

0.2.2 - July 7, 2020
--------------------

* No longer lowercase column names.

0.2.1 - March 16, 2019
----------------------

* agate-dbf is now tested against Python 3.6 and 3.7.
* Drop support for Python 3.3 (EOL 2017-09-29).

0.2.0 - December 19, 2016
-------------------------

* Remove dependency on monkeypatching.
* Upgrade required agate to ``1.5.0``.

0.1.0 - February 5, 2016
------------------------

* Initial version.
