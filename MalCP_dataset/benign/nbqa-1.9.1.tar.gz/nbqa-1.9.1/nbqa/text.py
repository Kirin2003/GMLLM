"""Formatting options when printing user-facing text."""

RED = "\033[31m"
GREEN = "\033[32m"
BOLD = "\033[1m"
RESET = "\x1b[0m"
