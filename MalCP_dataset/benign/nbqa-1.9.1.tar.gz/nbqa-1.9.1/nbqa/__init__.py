"""Attributes used by docs / packaging."""

__version__ = "1.9.1"
