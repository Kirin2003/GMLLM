"""Toml Sort.

A library to easily sort toml files.
"""

from .tomlsort import TomlSort

__all__ = ["TomlSort"]
