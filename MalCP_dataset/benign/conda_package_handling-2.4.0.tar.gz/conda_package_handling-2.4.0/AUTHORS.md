All of the people who have made at least one contribution to conda-package-handling.
Authors are sorted alphabetically.

* Alan Du
* Cheng H. Lee
* Chris Burr
* Christopher Barber
* Conda Bot
* Daniel Bast
* Daniel Holth
* Eli Uriegas
* Jannis Leidel
* John Lee
* Jonathan J. Helmus
* Justin Wood (Callek)
* Ken Odegard
* Marius van Niekerk
* Matthew R. Becker
* Michael Sarahan
* Nehal J Wani
* Pure Software
* Ray Donnelly
* Tobias "Tobi" Koch
* Vadim Zayakin
* jaimergp
* pre-commit-ci[bot]
