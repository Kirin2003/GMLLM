# This is the Odoo core modules that import test files in their __init__.py

WHITELIST = {
    "10": ["odoo.addons.mail.tests.test_mail_model"],
    "11": ["odoo.addons.mail.tests.test_mail_model"],
    "12": ["odoo.addons.resource.tests.test_resource_model"],
    "13": ["odoo.addons.resource.tests.test_resource_model"],
    "14": ["odoo.addons.resource.tests.test_resource_model"],
    "15": ["odoo.addons.resource.tests.test_resource_model"],
}
