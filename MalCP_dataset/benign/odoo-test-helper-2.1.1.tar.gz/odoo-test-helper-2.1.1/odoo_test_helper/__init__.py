from .fake_model_loader import FakeModelLoader  # noqa
