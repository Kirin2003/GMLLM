# Copyright 2023 ACSONE SA/NV (http://www.acsone.eu).

{
    "name": "Test Helper Bis",
    "summary": "Fake module for testing. This module doesn't define any model,"
    " only test models.",
    "version": "0.0.0",
    "category": "Uncategorized",
    "author": " ACSONE SA/NV",
    "license": "LGPL-3",
    "application": False,
    "installable": True,
    "external_dependencies": {"python": [], "bin": []},
    "depends": ["base"],
    "data": [],
    "demo": [],
    "qweb": [],
}
