from . import test_registry
