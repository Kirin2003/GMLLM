# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).


{
    "name": "Test Helper Extended",
    "summary": "Another fake module extending fake module Test Helper for testing",
    "version": "0.0.0",
    "category": "Uncategorized",
    "website": "www.akretion.com",
    "author": " Akretion",
    "license": "LGPL-3",
    "application": False,
    "installable": True,
    "external_dependencies": {"python": [], "bin": []},
    "depends": ["test_helper"],
    "data": [],
    "demo": [],
    "qweb": [],
}
