=======
History
=======

0.1.0 (2019-10-25)
------------------

* First release on PyPI.
