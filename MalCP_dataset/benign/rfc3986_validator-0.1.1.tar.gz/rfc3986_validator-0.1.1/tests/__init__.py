# -*- coding: utf-8 -*-

"""Unit test package for rfc3986_validator."""
