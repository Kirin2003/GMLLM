# Changelog

## 1.1

- **NEW**: Add helper function that auto checks if Pep562 needs to be applied.

## 1.0

- **NEW**: Works in Python 3.7 as well and is the user's responsibility to provide conditionals to exclude it on Python
  3.7 if they want to use the default implementation.
- **NEW**: Rework the version info object.
- **NEW**: Now one file and easy to vendor.

## 1.0b1

- **NEW**: Prerelease of PEP 562 backport.
