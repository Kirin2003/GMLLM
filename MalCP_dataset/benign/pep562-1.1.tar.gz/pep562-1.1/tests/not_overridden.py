"""No overrides."""
from pep562 import Pep562

__version__ = (1, 0, 0)
__all__ = ("__version__")

Pep562(__name__)
