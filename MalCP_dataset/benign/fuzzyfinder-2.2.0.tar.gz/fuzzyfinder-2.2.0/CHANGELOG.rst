.. :changelog:

Changelog
---------

2.2.0 (2024-09-08)
---------------------

* Modernize the codebase.
* Add a parameter to enable/disable case insensitivity.


2.0.0 (2017-01-25)
---------------------

* Case insensitive matching. (Gokul Soumya)
* Add an accessor function for fuzzy find. (Amjith)
* Support integer inputs. (Matheus)

2.1.0 (2017-01-25)
---------------------

* Use lookahead regex to find shortest match. (Gokul Soumya)
