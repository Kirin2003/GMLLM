fuzzyfinder package
===================

Submodules
----------

fuzzyfinder.main module
-----------------------

.. automodule:: fuzzyfinder.main
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: fuzzyfinder
    :members:
    :undoc-members:
    :show-inheritance:
