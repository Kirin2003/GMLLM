Authors
=======

This file contains the list of people involved in the development of
mirakuru along its history.

* Mateusz Lenik
* Tomasz Święcicki
* Tomasz Krzyszczyk
* Grzegorz Śliwiński
* Paweł Wilczyński
* Daniel O'Connell
* Michał Pawłowski
* Grégoire Détrez
* Lars Gohr

Great thanks to `Mateusz Lenik <http://mlen.pl>`_ for original package!
