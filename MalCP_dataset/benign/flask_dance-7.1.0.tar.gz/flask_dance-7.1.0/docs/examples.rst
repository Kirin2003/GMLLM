Projects Using Flask-Dance
==========================

If you want to see how others use Flask-Dance, check out some of these
projects. To add a project to this list, first make sure that the project has
some documentation and the code is publicly visible. Then send a pull request
to the docs section of the GitHub repository!

openedx-webhooks
----------------
:source: `@edx/openedx-webhooks on GitHub <https://github.com/edx/openedx-webhooks>`_
:providers: GitHub, JIRA

The project that created Flask-Dance. This project uses Flask-Dance
to synchronize events between GitHub and JIRA.
