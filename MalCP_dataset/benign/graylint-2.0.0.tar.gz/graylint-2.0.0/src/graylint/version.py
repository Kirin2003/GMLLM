"""The version number for Graylint is governed by this file"""

__version__ = "2.0.0"
