"""Graylint – show only linter messages caused by new code modifications"""

__version__ = "0.0.1"
