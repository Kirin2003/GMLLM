from django.apps import AppConfig


class AdminPlusConfig(AppConfig):
    label = 'adminplus'
    name = 'adminplus'
    verbose_name = 'Administration'
