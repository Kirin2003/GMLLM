"""setuptools boilerplate, see setup.cfg."""

from setuptools import setup

setup()
