.. :changelog:

History
-------

0.1.0 (2015-07-22)
---------------------

* First release on PyPI.
