from onnxslim.cli._main import main, slim
