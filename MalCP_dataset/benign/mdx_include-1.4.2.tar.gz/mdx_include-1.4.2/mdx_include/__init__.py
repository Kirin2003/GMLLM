
name = "mdx_include"

from .mdx_include import makeExtension

assert makeExtension
