==========
oslo.cache
==========

Cache storage for OpenStack projects.

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   configuration/index
   user/index
   reference/index


Release Notes
=============

Read also the `oslo.cache Release Notes
<https://docs.openstack.org/releasenotes/oslo.cache/>`_.


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

