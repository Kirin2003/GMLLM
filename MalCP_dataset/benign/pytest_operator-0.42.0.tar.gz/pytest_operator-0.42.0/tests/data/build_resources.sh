#!/usr/bin/env bash

touch resource-file.tgz