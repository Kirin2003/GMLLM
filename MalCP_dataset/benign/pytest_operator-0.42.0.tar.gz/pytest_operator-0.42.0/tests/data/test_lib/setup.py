#!/usr/bin/env python

from setuptools import setup

setup(
    name="pytest-operator-test-lib",
    version="1.0.0",
    description="Pytest-operator test library.",
    author="tester",
    packages=[],
)
