#!/usr/bin/env bash

echo "This script intentionally fails"
exit -1