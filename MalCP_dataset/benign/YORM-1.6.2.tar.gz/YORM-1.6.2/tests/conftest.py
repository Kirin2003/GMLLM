"""Integration tests configuration file."""

from yorm.tests.conftest import pytest_configure  # pylint: disable=unused-import
