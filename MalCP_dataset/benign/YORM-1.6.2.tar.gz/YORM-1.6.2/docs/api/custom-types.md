This documentation is a work in progress. Please help expand it.

---

# Examples

| Class | Python Value | YAML Data |
| --- | --- | --- |
| Number | `42.0` | `42` |
| NullableNumber | `None` | `null` |
