# -*- coding: utf-8 -*-

# Global variables
_HEADER = {'Content-Type': 'application/json'}
_PAYLOAD = {'queryType': 'SQL', 'query': None}
_LOGIN = {'j_username': None, 'j_password': None}
_PROGRESS_LOG_N = 10_000

