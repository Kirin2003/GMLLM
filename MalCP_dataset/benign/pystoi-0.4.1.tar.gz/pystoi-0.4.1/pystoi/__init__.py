from .stoi import stoi

__version__ = '0.4.1'
