Authors
=======

This file contains the list of people involved in the development
of pytest-rabbitmq along its history.

* Paweł Wilczyński
* Tomasz Karbownicki
* Grzegorz Śliwiński
* Karolina Blümke
* Michał Masłowski
* Dwayne Litzenberger
* Damian Skrzypczak