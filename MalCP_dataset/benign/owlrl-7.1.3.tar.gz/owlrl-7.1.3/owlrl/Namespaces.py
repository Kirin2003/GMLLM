from rdflib import Namespace

ERRNS = Namespace("http://www.daml.org/2002/03/agents/agent-ont#")
T = Namespace("http://test.org/")
