from dbt.tests.adapter.concurrency.test_concurrency import TestConcurenncy


class TestConcurrencyDuckDB(TestConcurenncy):
    pass
