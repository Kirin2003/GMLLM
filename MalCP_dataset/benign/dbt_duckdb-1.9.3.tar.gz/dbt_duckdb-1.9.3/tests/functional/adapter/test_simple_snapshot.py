from dbt.tests.adapter.simple_snapshot.test_snapshot import (
    BaseSnapshotCheck,
    BaseSimpleSnapshot,
)


class TestSimpleSnapshotDuckDB(BaseSimpleSnapshot):
    pass


class TestSnapshotCheckDuckDB(BaseSnapshotCheck):
    pass
