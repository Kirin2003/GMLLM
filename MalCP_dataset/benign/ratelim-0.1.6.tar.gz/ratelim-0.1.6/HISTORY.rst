.. :changelog:

History
-------

0.1.5 (2014-01-28)
~~~~~~~~~~~~~~~~~~

- Corrected indendation issues for Py3.

0.1.3 (2014-12-28)
~~~~~~~~~~~~~~~~~~

- Fixed spacing issue on Py3.
- Added support for preserving docstrings and metadata.

0.1.0 (2014-12-21)
~~~~~~~~~~~~~~~~~~

Initial release.
