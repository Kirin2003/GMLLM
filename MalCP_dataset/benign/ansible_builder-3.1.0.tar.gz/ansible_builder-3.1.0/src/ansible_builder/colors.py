class MessageColors:
    HEADER = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[1m'
    OK = '\033[95m'
    ENDC = '\033[0m'
