from reformat_gherkin.cli import main

main()
