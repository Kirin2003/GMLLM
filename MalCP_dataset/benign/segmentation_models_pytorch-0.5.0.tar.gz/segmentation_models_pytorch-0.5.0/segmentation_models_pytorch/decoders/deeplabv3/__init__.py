from .model import DeepLabV3, DeepLabV3Plus

__all__ = ["DeepLabV3", "DeepLabV3Plus"]
