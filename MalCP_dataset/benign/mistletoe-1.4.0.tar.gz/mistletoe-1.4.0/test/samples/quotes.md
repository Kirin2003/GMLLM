## Quotes

> A single quote

A response to single quote.

> A quote spreading...
> 
> ... multiple paragraphs

Quote with a list inside:

> 1. first
> 2. second

Nested quotes:

>> Nested line quote
>
> Quoted paragraph.
>
>> Nested block quote.
>> 
>> Jira does not seem to support this though - maybe we cannot do anything about it?

Another paragraph.
