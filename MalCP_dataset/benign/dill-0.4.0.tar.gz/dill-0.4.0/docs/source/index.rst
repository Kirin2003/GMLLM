.. dill documentation master file

dill package documentation
==========================

.. toctree::
    :hidden:
    :maxdepth: 2

    self
    dill
    scripts

.. automodule:: dill
..  :exclude-members: +

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
