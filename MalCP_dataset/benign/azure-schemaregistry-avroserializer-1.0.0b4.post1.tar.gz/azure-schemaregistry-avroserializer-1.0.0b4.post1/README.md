## Microsoft Azure SDK for Python

This package is no longer being maintained. Use the [azure-schemaregistry-avroencoder](https://pypi.org/project/azure-schemaregistry-avroencoder/) package instead.

For migration instructions, see the [migration guide](https://aka.ms/azsdk/python/migrate/sr-avroserializer-to-avroencoder).
