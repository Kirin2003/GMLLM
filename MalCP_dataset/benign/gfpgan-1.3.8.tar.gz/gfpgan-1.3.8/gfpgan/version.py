# GENERATED VERSION FILE
# TIME: Fri Sep 16 11:35:59 2022
__version__ = '1.3.8'
__gitsha__ = '2eac203'
version_info = (1, 3, 8)
