"""Test suite for target-hotglue."""
