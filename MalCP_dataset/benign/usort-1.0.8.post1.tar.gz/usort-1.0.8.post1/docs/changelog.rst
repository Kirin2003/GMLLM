Changelog
=========

See the :ref:`Versioning Guide <versioning>` for details on µsort's version scheme
and recommendations on how to handle upgrades.

.. mdinclude:: ../CHANGELOG.md
