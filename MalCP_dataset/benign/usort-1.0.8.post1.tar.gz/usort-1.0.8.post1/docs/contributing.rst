Contributing
============

.. mdinclude:: ../CONTRIBUTING.md
    :start-line: 1
