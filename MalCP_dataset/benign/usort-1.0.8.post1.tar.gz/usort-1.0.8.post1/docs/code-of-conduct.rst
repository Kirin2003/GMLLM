Code of Conduct
===============

.. mdinclude:: ../CODE_OF_CONDUCT.md
    :start-line: 2
