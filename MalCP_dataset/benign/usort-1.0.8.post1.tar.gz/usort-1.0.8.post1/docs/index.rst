.. mdinclude:: ../README.md


.. toctree::
    :hidden:
    :maxdepth: 1

    why

.. toctree::
    :hidden:
    :maxdepth: 2

    guide
    api

.. toctree::
    :hidden:
    :maxdepth: 1

    versioning
    changelog
    contributing
    code-of-conduct
