# Authors

Authors in the chronological orders of contributions

- Raymond Hettiger
- OrderedSet was implemented by Elia Robyn Lake (maiden name: Robyn Speer).
- StableSet was implemented by Idan Miara, built upon the foundations of OrderedSet.
- Jon Crall contributed changes and tests to make it fit the Python set API.
- Roman Inflianskas added the original type annotations.
- Sep Dehpour added OrderlySet and SortedSet.
- Michał Górny cleaned up some small issues with mypy and deprecated use of 
