#ifndef TASKLIST_H
#define TASKLIST_H

#include "cmark-gfm-core-extensions.h"

cmark_syntax_extension *create_tasklist_extension(void);

#endif
