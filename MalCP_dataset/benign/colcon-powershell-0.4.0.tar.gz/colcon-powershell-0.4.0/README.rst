colcon-powershell
=================

An extension for `colcon-core <https://github.com/colcon/colcon-core>`_ to provide `PowerShell <https://github.com/PowerShell/PowerShell>`_ scripts.
