from bridgecrew.version import version

tool = "Bridgecrew"
banner = """

  _          _     _                                   
 | |__  _ __(_) __| | __ _  ___  ___ _ __ _____      __
 | '_ \| '__| |/ _` |/ _` |/ _ \/ __| '__/ _ \ \ /\ / /
 | |_) | |  | | (_| | (_| |  __/ (__| | |  __/\ V  V / 
 |_.__/|_|  |_|\__,_|\__, |\___|\___|_|  \___| \_/\_/  
                     |___/                             
                                      
version: {} """.format(version)
