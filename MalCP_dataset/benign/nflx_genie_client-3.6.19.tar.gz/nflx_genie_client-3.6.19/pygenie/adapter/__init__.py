from __future__ import absolute_import, division, print_function, unicode_literals

from .genie_2 import Genie2Adapter
from .genie_3 import Genie3Adapter
