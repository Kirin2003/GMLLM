# -*- coding: utf-8 -*-

SECRET_KEY = '123'
