from .storage import InMemoryStorage
