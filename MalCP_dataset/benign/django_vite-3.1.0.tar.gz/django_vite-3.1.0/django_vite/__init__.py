from .core.asset_loader import DjangoViteConfig


__all__ = ["DjangoViteConfig"]
