import logging

__version__ = "1.0.2"

logging.getLogger(__name__).addHandler(logging.NullHandler())
