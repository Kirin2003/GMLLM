Install Instructions
====================

Make sure scikit-learn_ is installed, then run

::

    pip install sklearn-crfsuite

sklearn-crfsuite requires Python 2.7+ or 3.3+.


.. _scikit-learn: http://scikit-learn.org/
