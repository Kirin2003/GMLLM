# Project Contributors

The following people have made contributions to this project either directly
or in the original `dask.config` module:

<!--- Use your GitHub account or any other personal reference URL --->
<!--- See https://gist.github.com/djhoese/52220272ec73b12eb8f4a29709be110d for auto-generating parts of this list --->

- [David Hoese (djhoese)](https://github.com/djhoese)
- [James Bourbeau (jrbourbeau)](https://github.com/jrbourbeau)
- [Jim Crist (jcrist)](https://github.com/jcrist)
- [Joe Hamman (jhamman)](https://github.com/jhamman)
- [Matt Rocklin (mrocklin)](https://github.com/mrocklin)
- [Simon Perkins (sjperkins)](https://github.com/sjperkins)
