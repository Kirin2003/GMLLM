from __future__ import annotations

from .config import Config

__all__ = ("Config",)
