def f():
  return "databricks_pypi_extras"

def g(arg):
  return str(arg)[::-1]

def version():
  return "0.1"
