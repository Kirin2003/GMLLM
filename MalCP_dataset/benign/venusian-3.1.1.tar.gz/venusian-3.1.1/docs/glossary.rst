.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   scan
      Walk a module or package executing callbacks defined by
      venusian-aware decorators along the way.

   Martian
      The package venusian was inspired by, part of the :term:`Grok`
      project.

   Grok
      A Zope-based `web framework <http://grok.zope.org>`.

