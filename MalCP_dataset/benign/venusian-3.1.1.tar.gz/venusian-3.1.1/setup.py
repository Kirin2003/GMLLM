"""
Necessary for pip install -e, and python setup.py check
"""

from setuptools import setup

setup()
