"""
AWS Lambda Builder Library
"""

# Changing version will trigger a new release!
# Please make the version change as the last step of your development.

__version__ = "1.54.0"
RPC_PROTOCOL_VERSION = "0.3"
