# thrift_sasl.py

Thrift SASL Python module that implements SASL transports for Thrift
(`TSaslClientTransport`).
