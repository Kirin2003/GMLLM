Proglog
=======

Proglog is a progress logging system for Python. It allows to build complex
libraries while giving the user control on the management of logs, callbacks and progress bars.


Infos
-----

**PIP installation:**

.. code:: bash

  pip install proglog

**Github Page:** `<https://github.com/Edinburgh-Genome-Foundry/Proglog>`_

**License:** MIT

Copyright 2017 Edinburgh Genome Foundry, University of Edinburgh
