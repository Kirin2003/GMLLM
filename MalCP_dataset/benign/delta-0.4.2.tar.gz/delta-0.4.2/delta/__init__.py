"""
deltas init module
"""
from delta.parse import parse
