.. _xgboost-titanic-tutorial:

.. note::

    This tutorial is intended to be run in an IPython notebook.
    It is also available as a notebook file here_.

.. _here: https://github.com/eli5-org/eli5/blob/master/notebooks/xboost-titanic.ipynb

.. include:: ../_notebooks/xgboost-titanic.rst
