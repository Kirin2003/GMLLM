.. _lime-tutorial:

.. note::

    This tutorial can be run as an IPython notebook_.

.. _notebook: https://github.com/eli5-org/eli5/blob/master/notebooks/TextExplainer.ipynb

.. include:: ../_notebooks/text-explainer.rst
