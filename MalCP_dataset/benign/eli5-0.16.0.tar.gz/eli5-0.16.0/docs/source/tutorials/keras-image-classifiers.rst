.. _keras-image-classifiers-tutorial:

.. note::

    This tutorial is intended to be run in an IPython notebook.
    It is also available as a notebook file here_.

.. _here: https://github.com/eli5-org/eli5/blob/master/notebooks/keras-image-classifiers.ipynb

.. include:: ../_notebooks/keras-image-classifiers.rst
