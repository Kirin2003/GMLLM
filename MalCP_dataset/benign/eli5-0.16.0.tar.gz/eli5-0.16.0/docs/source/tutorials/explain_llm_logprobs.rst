.. _explain-llm-logprobs-tutorial:

.. note::

    This tutorial can be run as an IPython notebook_.

.. _notebook: https://github.com/eli5-org/eli5/blob/master/notebooks/explain_llm_logprobs.ipynb

.. include:: ../_notebooks/explain_llm_logprobs.rst
