eli5.catboost
=============

eli5 has CatBoost_ support - :func:`eli5.explain_weights`
shows feature importances, 
The function works for CatBoost, CatBoostClassifier and CatBoostRegressor.

.. _CatBoost: https://github.com/catboost/catboost

.. automodule:: eli5.catboost
    :members:
