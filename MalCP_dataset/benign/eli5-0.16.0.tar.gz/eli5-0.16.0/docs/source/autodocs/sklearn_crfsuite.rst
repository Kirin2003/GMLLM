eli5.sklearn_crfsuite
=====================

.. automodule:: eli5.sklearn_crfsuite.explain_weights
    :members:
