eli5.llm
========

.. automodule:: eli5.llm.explain_prediction
    :members:
