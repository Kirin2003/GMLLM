eli5.base
=========

.. automodule:: eli5.base
    :members:
