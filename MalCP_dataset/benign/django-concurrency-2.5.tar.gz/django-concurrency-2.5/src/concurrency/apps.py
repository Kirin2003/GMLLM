from django.apps import AppConfig


class ConcurrencyConfig(AppConfig):
    name = 'concurrency'
    verbose = 'Django Concurrency'
