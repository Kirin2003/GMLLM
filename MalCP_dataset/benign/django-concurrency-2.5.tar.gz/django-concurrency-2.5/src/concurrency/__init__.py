__author__ = 'sax'

VERSION = __version__ = "2.5"
NAME = 'django-concurrency'
