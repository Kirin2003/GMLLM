.. include:: globals.txt

:tocdepth: 2

.. _changes:


Changelog
=========
This section lists the biggest changes done on each release.

.. contents::
   :local:

.. include:: ../CHANGES
