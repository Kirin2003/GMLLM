from django.apps import AppConfig


class ConcurrencyTestConfig(AppConfig):
    name = 'demo'
    label = 'demo'
    verbose_name = 'Concurrency Tests'
