""" Simulate Functional Mockup Units (FMUs) in Python """

import sys
import os
from ctypes import *
import _ctypes
import zipfile
from tempfile import mkdtemp

__version__ = '0.0.9'


# determine the platform
if sys.platform.startswith('win'):
    platform = 'win'
    sharedLibraryExtension = '.dll'
elif sys.platform.startswith('linux'):
    platform = 'linux'
    sharedLibraryExtension = '.so'
elif sys.platform.startswith('darwin'):
    platform = 'darwin'
    sharedLibraryExtension = '.dylib'
else:
    raise Exception("Unsupported platform: " + sys.platform)


# load the C library functions
if sys.platform.startswith('win'):
    calloc = cdll.msvcrt.calloc
    free = cdll.msvcrt.free
    freeLibrary = _ctypes.FreeLibrary
else:
    from ctypes.util import find_library
    libc = CDLL(find_library("c"))
    calloc = libc.calloc
    free = libc.free
    freeLibrary = _ctypes.dlclose


calloc.argtypes = [c_size_t, c_size_t]
calloc.restype = c_void_p

free.argtypes = [c_void_p]

if sys.maxsize > 2**32:
    platform += '64'
else:
    platform += '32'


def supported_platforms(filename):
    """ Get the platforms supported by the FMU without extracting it """

    import zipfile

    platforms = []

    # open the FMU
    with zipfile.ZipFile(filename, 'r') as zf:

        # get the supported platforms
        names = zf.namelist()

        # check for the C-sources
        for name in names:
            head, tail = os.path.split(name)
            if head == 'sources' and tail.endswith('.c'):
                platforms.append('c-code')
                break

        # check for *.dylib on Mac
        for name in names:
            head, tail = os.path.split(name)
            if head == 'binaries/darwin64' and tail.endswith('.dylib'):
                platforms.append('darwin64')
                break

        # check for *.so on Linux
        for platform in ['linux32', 'linux64']:
            for name in names:
                head, tail = os.path.split(name)
                if head == 'binaries/' + platform and tail.endswith('.so'):
                    platforms.append(platform)
                    break

        # check for *.dll on Windows
        for platform in ['win32', 'win64']:
            for name in names:
                head, tail = os.path.split(name)
                if head == 'binaries/' + platform and tail.endswith('.dll'):
                    platforms.append(platform)
                    break

    return platforms


def fmi_info(filename):
    """ Read the FMI version and supported FMI types from the FMU without extracting it """

    from lxml import etree
    import zipfile

    fmi_types = []

    # open the FMU
    with zipfile.ZipFile(filename, 'r') as zf:

        # read the model description
        md = zf.open('modelDescription.xml')
        tree = etree.parse(md)
        root = tree.getroot()
        fmi_version = root.get('fmiVersion')

        # get the supported FMI types
        if fmi_version == '1.0':

            if root.find('Implementation') is not None:
                fmi_types.append('CoSimulation')
            else:
                fmi_types.append('ModelExchange')

        elif fmi_version == '2.0':

            if root.find('ModelExchange') is not None:
                fmi_types.append('ModelExchange')

            if root.find('CoSimulation') is not None:
                fmi_types.append('CoSimulation')

        else:
            raise Exception("Unsupported FMI version %s" % fmi_version)

    return fmi_version, fmi_types


def extract(filename):
    """ Extract a ZIP file to a temporary directory """

    unzipdir = mkdtemp()

    # expand the 8.3 paths on windows
    if sys.platform.startswith('win'):
        import win32file
        unzipdir = win32file.GetLongPathName(unzipdir)

    with zipfile.ZipFile(filename, 'r') as fmufile:
        fmufile.extractall(unzipdir)

    return unzipdir


def download_test_file(fmi_version, fmi_type, tool_name, tool_version, model_name, filename):
    """ Download a file from the Test FMUs repository to the current directory """

    import requests

    # download the FMU and input file
    url = 'https://trac.fmi-standard.org/export/HEAD/branches/public/Test_FMUs/FMI_' + fmi_version
    url = '/'.join([url, fmi_type, platform, tool_name, tool_version, model_name, filename])

    print('Downloading ' + url)

    status_code = -1

    # try to download the file three times
    try:
        for _ in range(3):
            if status_code != 200:
                response = requests.get(url)
                status_code = response.status_code
    except:
        pass

    if status_code != 200:
        raise Exception("Failed to download %s (status code: %d)" % (url, status_code))

    # write the file
    with open(filename, 'wb') as f:
        f.write(response.content)


# make the functions available in the fmpy module
from .model_description import read_model_description
from .simulation import simulate_fmu
