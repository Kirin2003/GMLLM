#!/usr/bin/env python
"""Version info"""

short_version = '1.5'
version = '1.5.0'
