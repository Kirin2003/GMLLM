import logging

logger = logging.getLogger('sox')
logger.setLevel(logging.WARNING)
