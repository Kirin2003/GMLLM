.. _api:

.. module:: sox

Transformers
------------
.. automodule:: sox.transform
    :members:

Combiners
---------
.. automodule:: sox.combine
    :members:

File info
---------
.. automodule:: sox.file_info
    :members:

Core functionality
------------------
.. automodule:: sox.core
    :members: