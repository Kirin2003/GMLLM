
def before_scenario(context, scenario):
    context.progress_bar = False
