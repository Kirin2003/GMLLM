"""Utils & function for implementations."""
