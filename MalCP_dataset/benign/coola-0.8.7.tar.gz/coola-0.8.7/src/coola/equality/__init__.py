r"""Experimental package that contains code to check if two objects are
equal or not.

This package is in development and should not be used yet.
"""

from __future__ import annotations

__all__ = ["EqualityConfig"]

from coola.equality.config import EqualityConfig
