(
cd github.com/indigo-dc/udocker &&
    mdl --json .
)