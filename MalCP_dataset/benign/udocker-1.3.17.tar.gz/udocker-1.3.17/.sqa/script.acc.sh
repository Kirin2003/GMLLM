(
cd github.com/indigo-dc/udocker &&
    git rev-parse --is-inside-work-tree
)