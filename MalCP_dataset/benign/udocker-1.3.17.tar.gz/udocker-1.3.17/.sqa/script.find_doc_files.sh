(
cd github.com/indigo-dc/udocker &&
    find_doc_files.py --file_type all
)