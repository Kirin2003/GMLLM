(
cd github.com/indigo-dc/udocker &&
    nosetests -v --with-xcoverage --cover-package=udocker tests/unit/test*.py
)