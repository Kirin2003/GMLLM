(
cd github.com/indigo-dc/udocker &&
    jsonlint-cli "**/*.json"
)