(
cd github.com/indigo-dc/udocker &&
    flake8 --config .flake8 .
)