(
cd github.com/indigo-dc/udocker &&
    get_git_tags.py
)