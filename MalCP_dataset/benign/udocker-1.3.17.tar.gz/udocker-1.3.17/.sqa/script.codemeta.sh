(
cd github.com/indigo-dc/udocker &&
    cat codemeta.json
)