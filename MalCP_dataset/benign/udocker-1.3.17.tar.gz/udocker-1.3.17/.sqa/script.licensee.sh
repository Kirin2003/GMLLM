(
cd github.com/indigo-dc/udocker &&
    licensee detect . --json
)