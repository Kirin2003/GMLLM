# Citing

When citing udocker please use the following reference:

* Jorge Gomes, Emanuele Bagnaschi, Isabel Campos, Mario David, Luís Alves,
  João Martins, João Pina, Alvaro López-García, Pablo Orviz,
  Enabling rootless Linux Containers in multi-user environments: The udocker tool,
  Computer Physics Communications, Available online 6 June 2018,
  ISSN 0010-4655, <https://doi.org/10.1016/j.cpc.2018.05.021>
