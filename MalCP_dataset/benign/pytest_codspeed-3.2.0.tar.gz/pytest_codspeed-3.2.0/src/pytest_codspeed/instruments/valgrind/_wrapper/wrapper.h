void start_instrumentation();
void stop_instrumentation();
void dump_stats();
void dump_stats_at(char *s);
void zero_stats();
void toggle_collect();
