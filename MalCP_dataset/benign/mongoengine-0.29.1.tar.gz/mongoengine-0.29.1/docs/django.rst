==============
Django Support
==============

.. note:: Django support has been split from the main MongoEngine
    repository.
