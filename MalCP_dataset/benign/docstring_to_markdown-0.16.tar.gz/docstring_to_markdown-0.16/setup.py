import setuptools

setuptools.setup(
    name="docstring-to-markdown",  # to allow GitHub dependency tracking
)
