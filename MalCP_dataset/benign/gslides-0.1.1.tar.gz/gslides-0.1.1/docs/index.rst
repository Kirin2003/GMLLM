Welcome to gslides's documentation!
======================================

.. include:: ../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Bring Your Own Credentials <byoc>
   Basic Usage <basic>
   Chart <chart>
   Tables <table>
   Styling <styling>
   API Reference <modules>

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
