gslides package
===============

Submodules
----------

gslides.chart module
------------------------

.. automodule:: gslides.chart
   :members:
   :undoc-members:
   :show-inheritance:

gslides.colors module
----------------------

.. automodule:: gslides.colors
   :members:
   :undoc-members:
   :show-inheritance:

gslides.config module
---------------------

.. automodule:: gslides.config
   :members:
   :undoc-members:
   :show-inheritance:

gslides.utils module
--------------------------

.. automodule:: gslides.utils
   :members:
   :undoc-members:
   :show-inheritance:

gslides.frame module
-------------------------

.. automodule:: gslides.frame
   :members:
   :undoc-members:
   :show-inheritance:

gslides.presentation module
---------------------------

.. automodule:: gslides.presentation
   :members:
   :undoc-members:
   :show-inheritance:

gslides.table module
------------------------

.. automodule:: gslides.table
  :members:
  :undoc-members:
  :show-inheritance:

Module contents
---------------

.. automodule:: gslides
   :members:
   :undoc-members:
   :show-inheritance:
