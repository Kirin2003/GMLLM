v0.1.1
------------

- Update to manifest file to exclude tests from packaging

v0.1.0
------------

- First release of the package
