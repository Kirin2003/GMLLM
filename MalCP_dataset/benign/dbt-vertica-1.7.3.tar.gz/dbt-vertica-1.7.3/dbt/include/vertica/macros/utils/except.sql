{% macro vertica__except() %}

    except distinct

{% endmacro %}