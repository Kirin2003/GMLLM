{% macro vertica__intersect() %}

    intersect distinct

{% endmacro %}