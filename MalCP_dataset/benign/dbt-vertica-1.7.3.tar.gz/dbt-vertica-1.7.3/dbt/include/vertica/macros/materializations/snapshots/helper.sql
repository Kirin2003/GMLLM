{# 
  No need to implement create_columns(). Syntax supported by default. 
  No need to implement post_snapshot(). No-op. 
  No need to implement snapshot_staging_table(). Syntax supported by default. 
  No need to implement build_snapshot_table(). Syntax supported by default. 
#}