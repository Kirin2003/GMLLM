{# 
  No need to implement set_sql_header(). Syntax supported by default.
  No need to implement should_full_refresh(). Syntax supported by default.
  No need to implement should_store_failures(). Syntax supported by default. 
#}