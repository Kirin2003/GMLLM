{#
  No need to implement run_hooks(). Syntax supported by default.
  No need to implement make_hook_config(). Syntax supported by default.
  No need to implement before_begin(). Syntax supported by default.
  No need to implement in_transaction(). Syntax supported by default.
  No need to implement after_commit(). Syntax supported by default.
#}