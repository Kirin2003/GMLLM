"""Stub to keep older build tools happy.
"""
import setuptools  # noqa

setuptools.setup()
