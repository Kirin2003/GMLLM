=======
History
=======

------------------
0.2.0 (2020-09-13)
------------------

* Add API to get all acquired locks on given mysql db

------------------
0.1.0 (2020-09-13)
------------------

* Add background lock connection refresh

------------------
0.0.1 (2020-09-12)
------------------

* First release on PyPI.
