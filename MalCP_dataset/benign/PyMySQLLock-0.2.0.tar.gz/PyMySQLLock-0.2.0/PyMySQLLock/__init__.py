__author__ = """Sanket Patel"""
__email__ = 'sanketplus@gmail.com'
__version__ = '0.2.0'

from .locker import Locker  # noqa
