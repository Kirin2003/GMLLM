## Summary

<!-- Summarise your change here -->

## Tasks

<!-- Mark tasks as complete or not applicable using [x] -->

- [ ] Added unit tests
- [ ] Added documentation for new features (where applicable)
- [ ] Added release notes (using [`reno`](https://pypi.org/project/reno/))
- [ ] Ran test suite and style checks and built documentation (`tox`)

## Further details

<!-- Note any further details here, where applicable -->
