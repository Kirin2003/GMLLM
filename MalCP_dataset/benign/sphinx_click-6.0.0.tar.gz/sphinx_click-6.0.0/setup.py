#!/usr/bin/env python3

from setuptools import setup

setup(
    setup_requires=['pbr>=2.0'],
    pbr=True,
)
