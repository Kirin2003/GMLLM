from sphinx_click.ext import setup  # noqa
