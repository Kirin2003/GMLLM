python3 proj.py $args
