====
TODO
====


Build Tooling
=============

* **[MEDIUM]** Automate Apple Silicon as part of CI.

* **[LOW]** Release to PyPI from CI.


Docs
====

* **[MEDIUM]** Examples should be tested as part of the unit tests (as they
  are in the C client). This is to ensure they don't "bit rot" as the code
  changes.
