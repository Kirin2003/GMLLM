#include <iostream>
int main() {
        std::cout << "Ok";
}
