#[no_mangle]
pub extern "C" fn rust_function2() {
    println!("Hello from lib 2!");
}
