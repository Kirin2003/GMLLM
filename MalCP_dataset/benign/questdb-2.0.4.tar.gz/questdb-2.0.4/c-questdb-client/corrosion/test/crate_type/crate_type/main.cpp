extern "C" void rust_function1();
extern "C" void rust_function2();

int main() {
    rust_function1();
    rust_function2();
    return 0;
}
