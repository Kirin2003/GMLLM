// Build-scripts also need to be linked, so just add a dummy buildscript ensuring this works.
fn main() {
    println!("Build-script is running.")
}
