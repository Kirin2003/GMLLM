from __future__ import annotations

# Map for type stub packages that don't follow the naming convention
PACKAGES_MAP: dict[str, str] = {"pandas": "pandas-stubs"}
