# For backwards compatability
from pydantic_avro.to_avro.base import AvroBase
