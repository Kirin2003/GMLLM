import os.path


HERE = os.path.dirname(__file__)

INDICES_DIR = os.path.join(HERE, "indices")
NUMPY_INDEX = os.path.join(INDICES_DIR, "numpy_index.json")
