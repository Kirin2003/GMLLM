def get_provider_info():
    return {
        "package-name": "rudderstack-airflow-provider",
        "name": "rudderstack-airflow-provider",
        "description": "Apache airflow provider for managing Reverse ETL syncs and Profiles runs in RudderStack.",
    }
