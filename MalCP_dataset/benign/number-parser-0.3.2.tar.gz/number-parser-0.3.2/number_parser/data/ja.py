info = {
    "UNIT_NUMBERS": {
        "〇": 0,
        "零": 0,
        "一": 1,
        "元": 1,
        "壱": 1,
        "二": 2,
        "弐": 2,
        "三": 3,
        "参": 3,
        "四": 4,
        "五": 5,
        "伍": 5,
        "六": 6,
        "七": 7,
        "八": 8,
        "九": 9
    },
    "DIRECT_NUMBERS": {},
    "TENS": {},
    "HUNDREDS": {},
    "BIG_POWERS_OF_TEN": {},
    "SKIP_TOKENS": []
}
