info = {
    "UNIT_NUMBERS": {},
    "DIRECT_NUMBERS": {},
    "TENS": {},
    "HUNDREDS": {},
    "BIG_POWERS_OF_TEN": {},
    "SKIP_TOKENS": []
}
