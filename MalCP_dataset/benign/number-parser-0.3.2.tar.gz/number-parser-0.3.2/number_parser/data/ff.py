info = {
    "UNIT_NUMBERS": {
        "ɓolum": 0,
        "gooto": 1,
        "goʼo": 1,
        "ɗiɗi": 2,
        "ɗiɗo": 2,
        "tati": 3,
        "tato": 3,
        "nawi": 4,
        "nawo": 4,
        "jowi": 5,
        "njowo": 5,
        "jeegomo": 6,
        "jeegoʼo": 6,
        "jeeɗiɗi": 7,
        "jeeɗiɗo": 7,
        "jeetati": 8,
        "jeetato": 8,
        "jeenawi": 9,
        "jeenawo": 9
    },
    "DIRECT_NUMBERS": {},
    "TENS": {
        "noogas": 20
    },
    "HUNDREDS": {},
    "BIG_POWERS_OF_TEN": {},
    "SKIP_TOKENS": [],
    "USE_LONG_SCALE": False
}
