info = {
    "UNIT_NUMBERS": {
        "ɖekeo": 0,
        "ɖeka": 1
    },
    "DIRECT_NUMBERS": {},
    "TENS": {},
    "HUNDREDS": {},
    "BIG_POWERS_OF_TEN": {},
    "SKIP_TOKENS": [],
    "USE_LONG_SCALE": False
}
