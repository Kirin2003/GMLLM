info = {
    "UNIT_NUMBERS": {
        "သုည": 0,
        "တစ်": 1,
        "နှစ်": 2,
        "သုံး": 3,
        "လေး": 4,
        "ငါး": 5,
        "ခြောက်": 6,
        "ခုနှစ်": 7,
        "ရှစ်": 8,
        "ကိုး": 9
    },
    "DIRECT_NUMBERS": {
        "ဆယ်": 10
    },
    "TENS": {},
    "HUNDREDS": {},
    "BIG_POWERS_OF_TEN": {},
    "SKIP_TOKENS": [],
    "USE_LONG_SCALE": False
}
