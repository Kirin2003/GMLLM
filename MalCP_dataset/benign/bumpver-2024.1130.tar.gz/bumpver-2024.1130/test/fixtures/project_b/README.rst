[PyCalVer v201307.0456]

.. |badge| image:: https://img.shields.io/badge/PyCalVer-v201307.0456--beta-blue.svg

.. |badge| image:: https://img.shields.io/static/v1.svg?label=PyCalVer&message=v201307.0456-beta&color=blue
