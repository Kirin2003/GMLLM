=====
pyddq
=====

Python API of Drunken Data Quality.

https://github.com/FRosner/drunken-data-quality


Description
===========

DDQ is a small library for checking constraints on Spark data structures.
It can be used to assure a certain data quality, especially when continuous imports happen.


Note
====

This project has been set up using PyScaffold 2.5.6. For details and usage
information on PyScaffold see http://pyscaffold.readthedocs.org/.
