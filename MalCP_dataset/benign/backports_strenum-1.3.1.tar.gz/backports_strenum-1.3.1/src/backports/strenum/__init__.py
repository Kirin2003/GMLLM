from .strenum import StrEnum

__all__ = ["StrEnum"]
