from setuptools import setup

setup(
    name="imgkit",
    install_requires=[
        "six",
    ],
)
