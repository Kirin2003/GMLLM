class MissingRate(Exception):
    """
    Absence of some exchange rate.
    """
