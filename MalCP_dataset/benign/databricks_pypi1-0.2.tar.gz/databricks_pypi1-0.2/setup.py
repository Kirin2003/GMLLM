from setuptools import setup, find_packages
 
setup(
    name = "databricks_pypi1",
    version = "0.2",
    decription = 'databricks whl library',
    packages = find_packages())
