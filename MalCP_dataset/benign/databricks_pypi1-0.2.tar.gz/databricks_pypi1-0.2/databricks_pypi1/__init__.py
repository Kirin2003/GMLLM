def f():
  return "databricks_pypi1"

def g(arg):
  return str(arg)[::-1]

def version():
  return "0.2"
