=============
API Reference
=============

.. module:: parver

.. testsetup::

   from parver import Version

.. autoclass:: Version
   :members:

.. autoclass:: ParseError
