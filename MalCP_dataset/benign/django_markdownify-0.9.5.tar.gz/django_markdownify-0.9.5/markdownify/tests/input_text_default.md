[This](http://somelink.com "somelink") is **not** a real link. It *is* however an <acronym title="acronym">accr</acronym>.
Here, have piece of `code`. And two lists.

This is list one:
    
  - Item 1
  - Item 2

This is list two:
  
  1. Item 1
  2. Item 2
  
<p style="color: red; font-weight: 900; border: 1px solid blue;">This paragraph has some inline styling.</p>

In this paragraph, protocols are being tested. 
[http-link](http://httplink.com), 
[https-link](https://httpslink.com), 
[mailto-link](mailto:somebody@example.com), 
[ftp-link](ftp://ftpserver.com).

And last but not least, there are some <i>tags</i> to <b>test</b>.
>Like this blockquote.

This <a href="#" rel="nofollow" target="_blank">link</a> has a target.