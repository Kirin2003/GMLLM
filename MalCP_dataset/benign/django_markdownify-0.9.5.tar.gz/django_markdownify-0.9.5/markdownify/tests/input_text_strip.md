# Strip
This is a short paragraph with some *tags* that can be stripped.