# Linkify
http://somelink.com  
someone@somecompany.com  
[Website](http://somelink.com)  