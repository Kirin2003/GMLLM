Dead battery redistribution
===========================

Python is moving forward! Python finally started to remove dead batteries.
For more information, see `PEP 594 <https://peps.python.org/pep-0594/>`_.

If your project depends on a module that has been removed from the standard,
here is the redistribution of the dead batteries.
