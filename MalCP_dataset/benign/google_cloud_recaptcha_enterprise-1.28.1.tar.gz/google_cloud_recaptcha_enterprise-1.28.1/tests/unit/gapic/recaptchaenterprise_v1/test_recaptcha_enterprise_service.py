# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import os

# try/except added for compatibility with python < 3.8
try:
    from unittest import mock
    from unittest.mock import AsyncMock  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    import mock

import json
import math

from google.api_core import api_core_version
import grpc
from grpc.experimental import aio
from proto.marshal.rules import wrappers
from proto.marshal.rules.dates import DurationRule, TimestampRule
import pytest

try:
    from google.auth.aio import credentials as ga_credentials_async

    HAS_GOOGLE_AUTH_AIO = True
except ImportError:  # pragma: NO COVER
    HAS_GOOGLE_AUTH_AIO = False

from google.api_core import gapic_v1, grpc_helpers, grpc_helpers_async, path_template
from google.api_core import client_options
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
import google.auth
from google.auth import credentials as ga_credentials
from google.auth.exceptions import MutualTLSChannelError
from google.oauth2 import service_account
from google.protobuf import any_pb2  # type: ignore
from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore
from google.rpc import status_pb2  # type: ignore

from google.cloud.recaptchaenterprise_v1.services.recaptcha_enterprise_service import (
    RecaptchaEnterpriseServiceAsyncClient,
    RecaptchaEnterpriseServiceClient,
    pagers,
    transports,
)
from google.cloud.recaptchaenterprise_v1.types import recaptchaenterprise

CRED_INFO_JSON = {
    "credential_source": "/path/to/file",
    "credential_type": "service account credentials",
    "principal": "service-account@example.com",
}
CRED_INFO_STRING = json.dumps(CRED_INFO_JSON)


async def mock_async_gen(data, chunk_size=1):
    for i in range(0, len(data)):  # pragma: NO COVER
        chunk = data[i : i + chunk_size]
        yield chunk.encode("utf-8")


def client_cert_source_callback():
    return b"cert bytes", b"key bytes"


# TODO: use async auth anon credentials by default once the minimum version of google-auth is upgraded.
# See related issue: https://github.com/googleapis/gapic-generator-python/issues/2107.
def async_anonymous_credentials():
    if HAS_GOOGLE_AUTH_AIO:
        return ga_credentials_async.AnonymousCredentials()
    return ga_credentials.AnonymousCredentials()


# If default endpoint is localhost, then default mtls endpoint will be the same.
# This method modifies the default endpoint so the client can produce a different
# mtls endpoint for endpoint testing purposes.
def modify_default_endpoint(client):
    return (
        "foo.googleapis.com"
        if ("localhost" in client.DEFAULT_ENDPOINT)
        else client.DEFAULT_ENDPOINT
    )


# If default endpoint template is localhost, then default mtls endpoint will be the same.
# This method modifies the default endpoint template so the client can produce a different
# mtls endpoint for endpoint testing purposes.
def modify_default_endpoint_template(client):
    return (
        "test.{UNIVERSE_DOMAIN}"
        if ("localhost" in client._DEFAULT_ENDPOINT_TEMPLATE)
        else client._DEFAULT_ENDPOINT_TEMPLATE
    )


def test__get_default_mtls_endpoint():
    api_endpoint = "example.googleapis.com"
    api_mtls_endpoint = "example.mtls.googleapis.com"
    sandbox_endpoint = "example.sandbox.googleapis.com"
    sandbox_mtls_endpoint = "example.mtls.sandbox.googleapis.com"
    non_googleapi = "api.example.com"

    assert RecaptchaEnterpriseServiceClient._get_default_mtls_endpoint(None) is None
    assert (
        RecaptchaEnterpriseServiceClient._get_default_mtls_endpoint(api_endpoint)
        == api_mtls_endpoint
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_default_mtls_endpoint(api_mtls_endpoint)
        == api_mtls_endpoint
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_default_mtls_endpoint(sandbox_endpoint)
        == sandbox_mtls_endpoint
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_default_mtls_endpoint(
            sandbox_mtls_endpoint
        )
        == sandbox_mtls_endpoint
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_default_mtls_endpoint(non_googleapi)
        == non_googleapi
    )


def test__read_environment_variables():
    assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
        False,
        "auto",
        None,
    )

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
            True,
            "auto",
            None,
        )

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "false"}):
        assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
            False,
            "auto",
            None,
        )

    with mock.patch.dict(
        os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "Unsupported"}
    ):
        with pytest.raises(ValueError) as excinfo:
            RecaptchaEnterpriseServiceClient._read_environment_variables()
    assert (
        str(excinfo.value)
        == "Environment variable `GOOGLE_API_USE_CLIENT_CERTIFICATE` must be either `true` or `false`"
    )

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
            False,
            "never",
            None,
        )

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
            False,
            "always",
            None,
        )

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "auto"}):
        assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
            False,
            "auto",
            None,
        )

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "Unsupported"}):
        with pytest.raises(MutualTLSChannelError) as excinfo:
            RecaptchaEnterpriseServiceClient._read_environment_variables()
    assert (
        str(excinfo.value)
        == "Environment variable `GOOGLE_API_USE_MTLS_ENDPOINT` must be `never`, `auto` or `always`"
    )

    with mock.patch.dict(os.environ, {"GOOGLE_CLOUD_UNIVERSE_DOMAIN": "foo.com"}):
        assert RecaptchaEnterpriseServiceClient._read_environment_variables() == (
            False,
            "auto",
            "foo.com",
        )


def test__get_client_cert_source():
    mock_provided_cert_source = mock.Mock()
    mock_default_cert_source = mock.Mock()

    assert RecaptchaEnterpriseServiceClient._get_client_cert_source(None, False) is None
    assert (
        RecaptchaEnterpriseServiceClient._get_client_cert_source(
            mock_provided_cert_source, False
        )
        is None
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_client_cert_source(
            mock_provided_cert_source, True
        )
        == mock_provided_cert_source
    )

    with mock.patch(
        "google.auth.transport.mtls.has_default_client_cert_source", return_value=True
    ):
        with mock.patch(
            "google.auth.transport.mtls.default_client_cert_source",
            return_value=mock_default_cert_source,
        ):
            assert (
                RecaptchaEnterpriseServiceClient._get_client_cert_source(None, True)
                is mock_default_cert_source
            )
            assert (
                RecaptchaEnterpriseServiceClient._get_client_cert_source(
                    mock_provided_cert_source, "true"
                )
                is mock_provided_cert_source
            )


@mock.patch.object(
    RecaptchaEnterpriseServiceClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceClient),
)
@mock.patch.object(
    RecaptchaEnterpriseServiceAsyncClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceAsyncClient),
)
def test__get_api_endpoint():
    api_override = "foo.com"
    mock_client_cert_source = mock.Mock()
    default_universe = RecaptchaEnterpriseServiceClient._DEFAULT_UNIVERSE
    default_endpoint = (
        RecaptchaEnterpriseServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(
            UNIVERSE_DOMAIN=default_universe
        )
    )
    mock_universe = "bar.com"
    mock_endpoint = RecaptchaEnterpriseServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(
        UNIVERSE_DOMAIN=mock_universe
    )

    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            api_override, mock_client_cert_source, default_universe, "always"
        )
        == api_override
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, mock_client_cert_source, default_universe, "auto"
        )
        == RecaptchaEnterpriseServiceClient.DEFAULT_MTLS_ENDPOINT
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, None, default_universe, "auto"
        )
        == default_endpoint
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, None, default_universe, "always"
        )
        == RecaptchaEnterpriseServiceClient.DEFAULT_MTLS_ENDPOINT
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, mock_client_cert_source, default_universe, "always"
        )
        == RecaptchaEnterpriseServiceClient.DEFAULT_MTLS_ENDPOINT
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, None, mock_universe, "never"
        )
        == mock_endpoint
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, None, default_universe, "never"
        )
        == default_endpoint
    )

    with pytest.raises(MutualTLSChannelError) as excinfo:
        RecaptchaEnterpriseServiceClient._get_api_endpoint(
            None, mock_client_cert_source, mock_universe, "auto"
        )
    assert (
        str(excinfo.value)
        == "mTLS is not supported in any universe other than googleapis.com."
    )


def test__get_universe_domain():
    client_universe_domain = "foo.com"
    universe_domain_env = "bar.com"

    assert (
        RecaptchaEnterpriseServiceClient._get_universe_domain(
            client_universe_domain, universe_domain_env
        )
        == client_universe_domain
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_universe_domain(None, universe_domain_env)
        == universe_domain_env
    )
    assert (
        RecaptchaEnterpriseServiceClient._get_universe_domain(None, None)
        == RecaptchaEnterpriseServiceClient._DEFAULT_UNIVERSE
    )

    with pytest.raises(ValueError) as excinfo:
        RecaptchaEnterpriseServiceClient._get_universe_domain("", None)
    assert str(excinfo.value) == "Universe Domain cannot be an empty string."


@pytest.mark.parametrize(
    "error_code,cred_info_json,show_cred_info",
    [
        (401, CRED_INFO_JSON, True),
        (403, CRED_INFO_JSON, True),
        (404, CRED_INFO_JSON, True),
        (500, CRED_INFO_JSON, False),
        (401, None, False),
        (403, None, False),
        (404, None, False),
        (500, None, False),
    ],
)
def test__add_cred_info_for_auth_errors(error_code, cred_info_json, show_cred_info):
    cred = mock.Mock(["get_cred_info"])
    cred.get_cred_info = mock.Mock(return_value=cred_info_json)
    client = RecaptchaEnterpriseServiceClient(credentials=cred)
    client._transport._credentials = cred

    error = core_exceptions.GoogleAPICallError("message", details=["foo"])
    error.code = error_code

    client._add_cred_info_for_auth_errors(error)
    if show_cred_info:
        assert error.details == ["foo", CRED_INFO_STRING]
    else:
        assert error.details == ["foo"]


@pytest.mark.parametrize("error_code", [401, 403, 404, 500])
def test__add_cred_info_for_auth_errors_no_get_cred_info(error_code):
    cred = mock.Mock([])
    assert not hasattr(cred, "get_cred_info")
    client = RecaptchaEnterpriseServiceClient(credentials=cred)
    client._transport._credentials = cred

    error = core_exceptions.GoogleAPICallError("message", details=[])
    error.code = error_code

    client._add_cred_info_for_auth_errors(error)
    assert error.details == []


@pytest.mark.parametrize(
    "client_class,transport_name",
    [
        (RecaptchaEnterpriseServiceClient, "grpc"),
        (RecaptchaEnterpriseServiceAsyncClient, "grpc_asyncio"),
    ],
)
def test_recaptcha_enterprise_service_client_from_service_account_info(
    client_class, transport_name
):
    creds = ga_credentials.AnonymousCredentials()
    with mock.patch.object(
        service_account.Credentials, "from_service_account_info"
    ) as factory:
        factory.return_value = creds
        info = {"valid": True}
        client = client_class.from_service_account_info(info, transport=transport_name)
        assert client.transport._credentials == creds
        assert isinstance(client, client_class)

        assert client.transport._host == ("recaptchaenterprise.googleapis.com:443")


@pytest.mark.parametrize(
    "transport_class,transport_name",
    [
        (transports.RecaptchaEnterpriseServiceGrpcTransport, "grpc"),
        (transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport, "grpc_asyncio"),
    ],
)
def test_recaptcha_enterprise_service_client_service_account_always_use_jwt(
    transport_class, transport_name
):
    with mock.patch.object(
        service_account.Credentials, "with_always_use_jwt_access", create=True
    ) as use_jwt:
        creds = service_account.Credentials(None, None, None)
        transport = transport_class(credentials=creds, always_use_jwt_access=True)
        use_jwt.assert_called_once_with(True)

    with mock.patch.object(
        service_account.Credentials, "with_always_use_jwt_access", create=True
    ) as use_jwt:
        creds = service_account.Credentials(None, None, None)
        transport = transport_class(credentials=creds, always_use_jwt_access=False)
        use_jwt.assert_not_called()


@pytest.mark.parametrize(
    "client_class,transport_name",
    [
        (RecaptchaEnterpriseServiceClient, "grpc"),
        (RecaptchaEnterpriseServiceAsyncClient, "grpc_asyncio"),
    ],
)
def test_recaptcha_enterprise_service_client_from_service_account_file(
    client_class, transport_name
):
    creds = ga_credentials.AnonymousCredentials()
    with mock.patch.object(
        service_account.Credentials, "from_service_account_file"
    ) as factory:
        factory.return_value = creds
        client = client_class.from_service_account_file(
            "dummy/file/path.json", transport=transport_name
        )
        assert client.transport._credentials == creds
        assert isinstance(client, client_class)

        client = client_class.from_service_account_json(
            "dummy/file/path.json", transport=transport_name
        )
        assert client.transport._credentials == creds
        assert isinstance(client, client_class)

        assert client.transport._host == ("recaptchaenterprise.googleapis.com:443")


def test_recaptcha_enterprise_service_client_get_transport_class():
    transport = RecaptchaEnterpriseServiceClient.get_transport_class()
    available_transports = [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
    ]
    assert transport in available_transports

    transport = RecaptchaEnterpriseServiceClient.get_transport_class("grpc")
    assert transport == transports.RecaptchaEnterpriseServiceGrpcTransport


@pytest.mark.parametrize(
    "client_class,transport_class,transport_name",
    [
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
            "grpc",
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
            "grpc_asyncio",
        ),
    ],
)
@mock.patch.object(
    RecaptchaEnterpriseServiceClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceClient),
)
@mock.patch.object(
    RecaptchaEnterpriseServiceAsyncClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceAsyncClient),
)
def test_recaptcha_enterprise_service_client_client_options(
    client_class, transport_class, transport_name
):
    # Check that if channel is provided we won't create a new one.
    with mock.patch.object(
        RecaptchaEnterpriseServiceClient, "get_transport_class"
    ) as gtc:
        transport = transport_class(credentials=ga_credentials.AnonymousCredentials())
        client = client_class(transport=transport)
        gtc.assert_not_called()

    # Check that if channel is provided via str we will create a new one.
    with mock.patch.object(
        RecaptchaEnterpriseServiceClient, "get_transport_class"
    ) as gtc:
        client = client_class(transport=transport_name)
        gtc.assert_called()

    # Check the case api_endpoint is provided.
    options = client_options.ClientOptions(api_endpoint="squid.clam.whelk")
    with mock.patch.object(transport_class, "__init__") as patched:
        patched.return_value = None
        client = client_class(transport=transport_name, client_options=options)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host="squid.clam.whelk",
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT is
    # "never".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        with mock.patch.object(transport_class, "__init__") as patched:
            patched.return_value = None
            client = client_class(transport=transport_name)
            patched.assert_called_once_with(
                credentials=None,
                credentials_file=None,
                host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                    UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
                ),
                scopes=None,
                client_cert_source_for_mtls=None,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT is
    # "always".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        with mock.patch.object(transport_class, "__init__") as patched:
            patched.return_value = None
            client = client_class(transport=transport_name)
            patched.assert_called_once_with(
                credentials=None,
                credentials_file=None,
                host=client.DEFAULT_MTLS_ENDPOINT,
                scopes=None,
                client_cert_source_for_mtls=None,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT has
    # unsupported value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "Unsupported"}):
        with pytest.raises(MutualTLSChannelError) as excinfo:
            client = client_class(transport=transport_name)
    assert (
        str(excinfo.value)
        == "Environment variable `GOOGLE_API_USE_MTLS_ENDPOINT` must be `never`, `auto` or `always`"
    )

    # Check the case GOOGLE_API_USE_CLIENT_CERTIFICATE has unsupported value.
    with mock.patch.dict(
        os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "Unsupported"}
    ):
        with pytest.raises(ValueError) as excinfo:
            client = client_class(transport=transport_name)
    assert (
        str(excinfo.value)
        == "Environment variable `GOOGLE_API_USE_CLIENT_CERTIFICATE` must be either `true` or `false`"
    )

    # Check the case quota_project_id is provided
    options = client_options.ClientOptions(quota_project_id="octopus")
    with mock.patch.object(transport_class, "__init__") as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
            ),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id="octopus",
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )
    # Check the case api_endpoint is provided
    options = client_options.ClientOptions(
        api_audience="https://language.googleapis.com"
    )
    with mock.patch.object(transport_class, "__init__") as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
            ),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience="https://language.googleapis.com",
        )


@pytest.mark.parametrize(
    "client_class,transport_class,transport_name,use_client_cert_env",
    [
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
            "grpc",
            "true",
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
            "grpc_asyncio",
            "true",
        ),
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
            "grpc",
            "false",
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
            "grpc_asyncio",
            "false",
        ),
    ],
)
@mock.patch.object(
    RecaptchaEnterpriseServiceClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceClient),
)
@mock.patch.object(
    RecaptchaEnterpriseServiceAsyncClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceAsyncClient),
)
@mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "auto"})
def test_recaptcha_enterprise_service_client_mtls_env_auto(
    client_class, transport_class, transport_name, use_client_cert_env
):
    # This tests the endpoint autoswitch behavior. Endpoint is autoswitched to the default
    # mtls endpoint, if GOOGLE_API_USE_CLIENT_CERTIFICATE is "true" and client cert exists.

    # Check the case client_cert_source is provided. Whether client cert is used depends on
    # GOOGLE_API_USE_CLIENT_CERTIFICATE value.
    with mock.patch.dict(
        os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": use_client_cert_env}
    ):
        options = client_options.ClientOptions(
            client_cert_source=client_cert_source_callback
        )
        with mock.patch.object(transport_class, "__init__") as patched:
            patched.return_value = None
            client = client_class(client_options=options, transport=transport_name)

            if use_client_cert_env == "false":
                expected_client_cert_source = None
                expected_host = client._DEFAULT_ENDPOINT_TEMPLATE.format(
                    UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
                )
            else:
                expected_client_cert_source = client_cert_source_callback
                expected_host = client.DEFAULT_MTLS_ENDPOINT

            patched.assert_called_once_with(
                credentials=None,
                credentials_file=None,
                host=expected_host,
                scopes=None,
                client_cert_source_for_mtls=expected_client_cert_source,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )

    # Check the case ADC client cert is provided. Whether client cert is used depends on
    # GOOGLE_API_USE_CLIENT_CERTIFICATE value.
    with mock.patch.dict(
        os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": use_client_cert_env}
    ):
        with mock.patch.object(transport_class, "__init__") as patched:
            with mock.patch(
                "google.auth.transport.mtls.has_default_client_cert_source",
                return_value=True,
            ):
                with mock.patch(
                    "google.auth.transport.mtls.default_client_cert_source",
                    return_value=client_cert_source_callback,
                ):
                    if use_client_cert_env == "false":
                        expected_host = client._DEFAULT_ENDPOINT_TEMPLATE.format(
                            UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
                        )
                        expected_client_cert_source = None
                    else:
                        expected_host = client.DEFAULT_MTLS_ENDPOINT
                        expected_client_cert_source = client_cert_source_callback

                    patched.return_value = None
                    client = client_class(transport=transport_name)
                    patched.assert_called_once_with(
                        credentials=None,
                        credentials_file=None,
                        host=expected_host,
                        scopes=None,
                        client_cert_source_for_mtls=expected_client_cert_source,
                        quota_project_id=None,
                        client_info=transports.base.DEFAULT_CLIENT_INFO,
                        always_use_jwt_access=True,
                        api_audience=None,
                    )

    # Check the case client_cert_source and ADC client cert are not provided.
    with mock.patch.dict(
        os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": use_client_cert_env}
    ):
        with mock.patch.object(transport_class, "__init__") as patched:
            with mock.patch(
                "google.auth.transport.mtls.has_default_client_cert_source",
                return_value=False,
            ):
                patched.return_value = None
                client = client_class(transport=transport_name)
                patched.assert_called_once_with(
                    credentials=None,
                    credentials_file=None,
                    host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                        UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
                    ),
                    scopes=None,
                    client_cert_source_for_mtls=None,
                    quota_project_id=None,
                    client_info=transports.base.DEFAULT_CLIENT_INFO,
                    always_use_jwt_access=True,
                    api_audience=None,
                )


@pytest.mark.parametrize(
    "client_class",
    [RecaptchaEnterpriseServiceClient, RecaptchaEnterpriseServiceAsyncClient],
)
@mock.patch.object(
    RecaptchaEnterpriseServiceClient,
    "DEFAULT_ENDPOINT",
    modify_default_endpoint(RecaptchaEnterpriseServiceClient),
)
@mock.patch.object(
    RecaptchaEnterpriseServiceAsyncClient,
    "DEFAULT_ENDPOINT",
    modify_default_endpoint(RecaptchaEnterpriseServiceAsyncClient),
)
def test_recaptcha_enterprise_service_client_get_mtls_endpoint_and_cert_source(
    client_class,
):
    mock_client_cert_source = mock.Mock()

    # Test the case GOOGLE_API_USE_CLIENT_CERTIFICATE is "true".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        mock_api_endpoint = "foo"
        options = client_options.ClientOptions(
            client_cert_source=mock_client_cert_source, api_endpoint=mock_api_endpoint
        )
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source(
            options
        )
        assert api_endpoint == mock_api_endpoint
        assert cert_source == mock_client_cert_source

    # Test the case GOOGLE_API_USE_CLIENT_CERTIFICATE is "false".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "false"}):
        mock_client_cert_source = mock.Mock()
        mock_api_endpoint = "foo"
        options = client_options.ClientOptions(
            client_cert_source=mock_client_cert_source, api_endpoint=mock_api_endpoint
        )
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source(
            options
        )
        assert api_endpoint == mock_api_endpoint
        assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "never".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
        assert api_endpoint == client_class.DEFAULT_ENDPOINT
        assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "always".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
        assert api_endpoint == client_class.DEFAULT_MTLS_ENDPOINT
        assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "auto" and default cert doesn't exist.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        with mock.patch(
            "google.auth.transport.mtls.has_default_client_cert_source",
            return_value=False,
        ):
            api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
            assert api_endpoint == client_class.DEFAULT_ENDPOINT
            assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "auto" and default cert exists.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        with mock.patch(
            "google.auth.transport.mtls.has_default_client_cert_source",
            return_value=True,
        ):
            with mock.patch(
                "google.auth.transport.mtls.default_client_cert_source",
                return_value=mock_client_cert_source,
            ):
                (
                    api_endpoint,
                    cert_source,
                ) = client_class.get_mtls_endpoint_and_cert_source()
                assert api_endpoint == client_class.DEFAULT_MTLS_ENDPOINT
                assert cert_source == mock_client_cert_source

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT has
    # unsupported value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "Unsupported"}):
        with pytest.raises(MutualTLSChannelError) as excinfo:
            client_class.get_mtls_endpoint_and_cert_source()

        assert (
            str(excinfo.value)
            == "Environment variable `GOOGLE_API_USE_MTLS_ENDPOINT` must be `never`, `auto` or `always`"
        )

    # Check the case GOOGLE_API_USE_CLIENT_CERTIFICATE has unsupported value.
    with mock.patch.dict(
        os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "Unsupported"}
    ):
        with pytest.raises(ValueError) as excinfo:
            client_class.get_mtls_endpoint_and_cert_source()

        assert (
            str(excinfo.value)
            == "Environment variable `GOOGLE_API_USE_CLIENT_CERTIFICATE` must be either `true` or `false`"
        )


@pytest.mark.parametrize(
    "client_class",
    [RecaptchaEnterpriseServiceClient, RecaptchaEnterpriseServiceAsyncClient],
)
@mock.patch.object(
    RecaptchaEnterpriseServiceClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceClient),
)
@mock.patch.object(
    RecaptchaEnterpriseServiceAsyncClient,
    "_DEFAULT_ENDPOINT_TEMPLATE",
    modify_default_endpoint_template(RecaptchaEnterpriseServiceAsyncClient),
)
def test_recaptcha_enterprise_service_client_client_api_endpoint(client_class):
    mock_client_cert_source = client_cert_source_callback
    api_override = "foo.com"
    default_universe = RecaptchaEnterpriseServiceClient._DEFAULT_UNIVERSE
    default_endpoint = (
        RecaptchaEnterpriseServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(
            UNIVERSE_DOMAIN=default_universe
        )
    )
    mock_universe = "bar.com"
    mock_endpoint = RecaptchaEnterpriseServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(
        UNIVERSE_DOMAIN=mock_universe
    )

    # If ClientOptions.api_endpoint is set and GOOGLE_API_USE_CLIENT_CERTIFICATE="true",
    # use ClientOptions.api_endpoint as the api endpoint regardless.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        with mock.patch(
            "google.auth.transport.requests.AuthorizedSession.configure_mtls_channel"
        ):
            options = client_options.ClientOptions(
                client_cert_source=mock_client_cert_source, api_endpoint=api_override
            )
            client = client_class(
                client_options=options,
                credentials=ga_credentials.AnonymousCredentials(),
            )
            assert client.api_endpoint == api_override

    # If ClientOptions.api_endpoint is not set and GOOGLE_API_USE_MTLS_ENDPOINT="never",
    # use the _DEFAULT_ENDPOINT_TEMPLATE populated with GDU as the api endpoint.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        client = client_class(credentials=ga_credentials.AnonymousCredentials())
        assert client.api_endpoint == default_endpoint

    # If ClientOptions.api_endpoint is not set and GOOGLE_API_USE_MTLS_ENDPOINT="always",
    # use the DEFAULT_MTLS_ENDPOINT as the api endpoint.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        client = client_class(credentials=ga_credentials.AnonymousCredentials())
        assert client.api_endpoint == client_class.DEFAULT_MTLS_ENDPOINT

    # If ClientOptions.api_endpoint is not set, GOOGLE_API_USE_MTLS_ENDPOINT="auto" (default),
    # GOOGLE_API_USE_CLIENT_CERTIFICATE="false" (default), default cert source doesn't exist,
    # and ClientOptions.universe_domain="bar.com",
    # use the _DEFAULT_ENDPOINT_TEMPLATE populated with universe domain as the api endpoint.
    options = client_options.ClientOptions()
    universe_exists = hasattr(options, "universe_domain")
    if universe_exists:
        options = client_options.ClientOptions(universe_domain=mock_universe)
        client = client_class(
            client_options=options, credentials=ga_credentials.AnonymousCredentials()
        )
    else:
        client = client_class(
            client_options=options, credentials=ga_credentials.AnonymousCredentials()
        )
    assert client.api_endpoint == (
        mock_endpoint if universe_exists else default_endpoint
    )
    assert client.universe_domain == (
        mock_universe if universe_exists else default_universe
    )

    # If ClientOptions does not have a universe domain attribute and GOOGLE_API_USE_MTLS_ENDPOINT="never",
    # use the _DEFAULT_ENDPOINT_TEMPLATE populated with GDU as the api endpoint.
    options = client_options.ClientOptions()
    if hasattr(options, "universe_domain"):
        delattr(options, "universe_domain")
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        client = client_class(
            client_options=options, credentials=ga_credentials.AnonymousCredentials()
        )
        assert client.api_endpoint == default_endpoint


@pytest.mark.parametrize(
    "client_class,transport_class,transport_name",
    [
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
            "grpc",
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
            "grpc_asyncio",
        ),
    ],
)
def test_recaptcha_enterprise_service_client_client_options_scopes(
    client_class, transport_class, transport_name
):
    # Check the case scopes are provided.
    options = client_options.ClientOptions(
        scopes=["1", "2"],
    )
    with mock.patch.object(transport_class, "__init__") as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
            ),
            scopes=["1", "2"],
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )


@pytest.mark.parametrize(
    "client_class,transport_class,transport_name,grpc_helpers",
    [
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
            "grpc",
            grpc_helpers,
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
            "grpc_asyncio",
            grpc_helpers_async,
        ),
    ],
)
def test_recaptcha_enterprise_service_client_client_options_credentials_file(
    client_class, transport_class, transport_name, grpc_helpers
):
    # Check the case credentials file is provided.
    options = client_options.ClientOptions(credentials_file="credentials.json")

    with mock.patch.object(transport_class, "__init__") as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file="credentials.json",
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
            ),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )


def test_recaptcha_enterprise_service_client_client_options_from_dict():
    with mock.patch(
        "google.cloud.recaptchaenterprise_v1.services.recaptcha_enterprise_service.transports.RecaptchaEnterpriseServiceGrpcTransport.__init__"
    ) as grpc_transport:
        grpc_transport.return_value = None
        client = RecaptchaEnterpriseServiceClient(
            client_options={"api_endpoint": "squid.clam.whelk"}
        )
        grpc_transport.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host="squid.clam.whelk",
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )


@pytest.mark.parametrize(
    "client_class,transport_class,transport_name,grpc_helpers",
    [
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
            "grpc",
            grpc_helpers,
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
            "grpc_asyncio",
            grpc_helpers_async,
        ),
    ],
)
def test_recaptcha_enterprise_service_client_create_channel_credentials_file(
    client_class, transport_class, transport_name, grpc_helpers
):
    # Check the case credentials file is provided.
    options = client_options.ClientOptions(credentials_file="credentials.json")

    with mock.patch.object(transport_class, "__init__") as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file="credentials.json",
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
            ),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )

    # test that the credentials from file are saved and used as the credentials.
    with mock.patch.object(
        google.auth, "load_credentials_from_file", autospec=True
    ) as load_creds, mock.patch.object(
        google.auth, "default", autospec=True
    ) as adc, mock.patch.object(
        grpc_helpers, "create_channel"
    ) as create_channel:
        creds = ga_credentials.AnonymousCredentials()
        file_creds = ga_credentials.AnonymousCredentials()
        load_creds.return_value = (file_creds, None)
        adc.return_value = (creds, None)
        client = client_class(client_options=options, transport=transport_name)
        create_channel.assert_called_with(
            "recaptchaenterprise.googleapis.com:443",
            credentials=file_creds,
            credentials_file=None,
            quota_project_id=None,
            default_scopes=("https://www.googleapis.com/auth/cloud-platform",),
            scopes=None,
            default_host="recaptchaenterprise.googleapis.com",
            ssl_credentials=None,
            options=[
                ("grpc.max_send_message_length", -1),
                ("grpc.max_receive_message_length", -1),
            ],
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.CreateAssessmentRequest,
        dict,
    ],
)
def test_create_assessment(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Assessment(
            name="name_value",
        )
        response = client.create_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.CreateAssessmentRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Assessment)
    assert response.name == "name_value"


def test_create_assessment_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.CreateAssessmentRequest(
        parent="parent_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.create_assessment(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.CreateAssessmentRequest(
            parent="parent_value",
        )


def test_create_assessment_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.create_assessment in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.create_assessment
        ] = mock_rpc
        request = {}
        client.create_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.create_assessment(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_create_assessment_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.create_assessment
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.create_assessment
        ] = mock_rpc

        request = {}
        await client.create_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.create_assessment(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_create_assessment_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.CreateAssessmentRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Assessment(
                name="name_value",
            )
        )
        response = await client.create_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.CreateAssessmentRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Assessment)
    assert response.name == "name_value"


@pytest.mark.asyncio
async def test_create_assessment_async_from_dict():
    await test_create_assessment_async(request_type=dict)


def test_create_assessment_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.CreateAssessmentRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.Assessment()
        client.create_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_create_assessment_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.CreateAssessmentRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Assessment()
        )
        await client.create_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_create_assessment_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Assessment()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.create_assessment(
            parent="parent_value",
            assessment=recaptchaenterprise.Assessment(name="name_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].assessment
        mock_val = recaptchaenterprise.Assessment(name="name_value")
        assert arg == mock_val


def test_create_assessment_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_assessment(
            recaptchaenterprise.CreateAssessmentRequest(),
            parent="parent_value",
            assessment=recaptchaenterprise.Assessment(name="name_value"),
        )


@pytest.mark.asyncio
async def test_create_assessment_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Assessment()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Assessment()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.create_assessment(
            parent="parent_value",
            assessment=recaptchaenterprise.Assessment(name="name_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].assessment
        mock_val = recaptchaenterprise.Assessment(name="name_value")
        assert arg == mock_val


@pytest.mark.asyncio
async def test_create_assessment_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.create_assessment(
            recaptchaenterprise.CreateAssessmentRequest(),
            parent="parent_value",
            assessment=recaptchaenterprise.Assessment(name="name_value"),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.AnnotateAssessmentRequest,
        dict,
    ],
)
def test_annotate_assessment(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.AnnotateAssessmentResponse()
        response = client.annotate_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.AnnotateAssessmentRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.AnnotateAssessmentResponse)


def test_annotate_assessment_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.AnnotateAssessmentRequest(
        name="name_value",
        account_id="account_id_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.annotate_assessment(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.AnnotateAssessmentRequest(
            name="name_value",
            account_id="account_id_value",
        )


def test_annotate_assessment_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.annotate_assessment in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.annotate_assessment
        ] = mock_rpc
        request = {}
        client.annotate_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.annotate_assessment(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_annotate_assessment_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.annotate_assessment
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.annotate_assessment
        ] = mock_rpc

        request = {}
        await client.annotate_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.annotate_assessment(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_annotate_assessment_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.AnnotateAssessmentRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AnnotateAssessmentResponse()
        )
        response = await client.annotate_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.AnnotateAssessmentRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.AnnotateAssessmentResponse)


@pytest.mark.asyncio
async def test_annotate_assessment_async_from_dict():
    await test_annotate_assessment_async(request_type=dict)


def test_annotate_assessment_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.AnnotateAssessmentRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.AnnotateAssessmentResponse()
        client.annotate_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_annotate_assessment_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.AnnotateAssessmentRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AnnotateAssessmentResponse()
        )
        await client.annotate_assessment(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_annotate_assessment_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.AnnotateAssessmentResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.annotate_assessment(
            name="name_value",
            annotation=recaptchaenterprise.AnnotateAssessmentRequest.Annotation.LEGITIMATE,
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val
        arg = args[0].annotation
        mock_val = recaptchaenterprise.AnnotateAssessmentRequest.Annotation.LEGITIMATE
        assert arg == mock_val


def test_annotate_assessment_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.annotate_assessment(
            recaptchaenterprise.AnnotateAssessmentRequest(),
            name="name_value",
            annotation=recaptchaenterprise.AnnotateAssessmentRequest.Annotation.LEGITIMATE,
        )


@pytest.mark.asyncio
async def test_annotate_assessment_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.AnnotateAssessmentResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AnnotateAssessmentResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.annotate_assessment(
            name="name_value",
            annotation=recaptchaenterprise.AnnotateAssessmentRequest.Annotation.LEGITIMATE,
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val
        arg = args[0].annotation
        mock_val = recaptchaenterprise.AnnotateAssessmentRequest.Annotation.LEGITIMATE
        assert arg == mock_val


@pytest.mark.asyncio
async def test_annotate_assessment_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.annotate_assessment(
            recaptchaenterprise.AnnotateAssessmentRequest(),
            name="name_value",
            annotation=recaptchaenterprise.AnnotateAssessmentRequest.Annotation.LEGITIMATE,
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.CreateKeyRequest,
        dict,
    ],
)
def test_create_key(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key(
            name="name_value",
            display_name="display_name_value",
        )
        response = client.create_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.CreateKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


def test_create_key_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.CreateKeyRequest(
        parent="parent_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.create_key(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.CreateKeyRequest(
            parent="parent_value",
        )


def test_create_key_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.create_key in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.create_key] = mock_rpc
        request = {}
        client.create_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.create_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_create_key_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.create_key
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.create_key
        ] = mock_rpc

        request = {}
        await client.create_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.create_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_create_key_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.CreateKeyRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        response = await client.create_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.CreateKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


@pytest.mark.asyncio
async def test_create_key_async_from_dict():
    await test_create_key_async(request_type=dict)


def test_create_key_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.CreateKeyRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.create_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_create_key_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.CreateKeyRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        await client.create_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_create_key_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.create_key(
            parent="parent_value",
            key=recaptchaenterprise.Key(name="name_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].key
        mock_val = recaptchaenterprise.Key(name="name_value")
        assert arg == mock_val


def test_create_key_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_key(
            recaptchaenterprise.CreateKeyRequest(),
            parent="parent_value",
            key=recaptchaenterprise.Key(name="name_value"),
        )


@pytest.mark.asyncio
async def test_create_key_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.create_key(
            parent="parent_value",
            key=recaptchaenterprise.Key(name="name_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].key
        mock_val = recaptchaenterprise.Key(name="name_value")
        assert arg == mock_val


@pytest.mark.asyncio
async def test_create_key_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.create_key(
            recaptchaenterprise.CreateKeyRequest(),
            parent="parent_value",
            key=recaptchaenterprise.Key(name="name_value"),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.ListKeysRequest,
        dict,
    ],
)
def test_list_keys(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListKeysResponse(
            next_page_token="next_page_token_value",
        )
        response = client.list_keys(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListKeysRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListKeysPager)
    assert response.next_page_token == "next_page_token_value"


def test_list_keys_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.ListKeysRequest(
        parent="parent_value",
        page_token="page_token_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.list_keys(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.ListKeysRequest(
            parent="parent_value",
            page_token="page_token_value",
        )


def test_list_keys_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.list_keys in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.list_keys] = mock_rpc
        request = {}
        client.list_keys(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_keys(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_keys_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.list_keys
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.list_keys
        ] = mock_rpc

        request = {}
        await client.list_keys(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_keys(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_keys_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.ListKeysRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListKeysResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = await client.list_keys(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListKeysRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListKeysAsyncPager)
    assert response.next_page_token == "next_page_token_value"


@pytest.mark.asyncio
async def test_list_keys_async_from_dict():
    await test_list_keys_async(request_type=dict)


def test_list_keys_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListKeysRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        call.return_value = recaptchaenterprise.ListKeysResponse()
        client.list_keys(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_list_keys_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListKeysRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListKeysResponse()
        )
        await client.list_keys(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_list_keys_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListKeysResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_keys(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


def test_list_keys_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_keys(
            recaptchaenterprise.ListKeysRequest(),
            parent="parent_value",
        )


@pytest.mark.asyncio
async def test_list_keys_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListKeysResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListKeysResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_keys(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_list_keys_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_keys(
            recaptchaenterprise.ListKeysRequest(),
            parent="parent_value",
        )


def test_list_keys_pager(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((("parent", ""),)),
        )
        pager = client.list_keys(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, recaptchaenterprise.Key) for i in results)


def test_list_keys_pages(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_keys(request={}).pages)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.asyncio
async def test_list_keys_async_pager():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_keys), "__call__", new_callable=mock.AsyncMock
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_keys(
            request={},
        )
        assert async_pager.next_page_token == "abc"
        responses = []
        async for response in async_pager:  # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, recaptchaenterprise.Key) for i in responses)


@pytest.mark.asyncio
async def test_list_keys_async_pages():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_keys), "__call__", new_callable=mock.AsyncMock
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListKeysResponse(
                keys=[
                    recaptchaenterprise.Key(),
                    recaptchaenterprise.Key(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in (  # pragma: no branch
            await client.list_keys(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.RetrieveLegacySecretKeyRequest,
        dict,
    ],
)
def test_retrieve_legacy_secret_key(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.RetrieveLegacySecretKeyResponse(
            legacy_secret_key="legacy_secret_key_value",
        )
        response = client.retrieve_legacy_secret_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.RetrieveLegacySecretKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.RetrieveLegacySecretKeyResponse)
    assert response.legacy_secret_key == "legacy_secret_key_value"


def test_retrieve_legacy_secret_key_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.RetrieveLegacySecretKeyRequest(
        key="key_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.retrieve_legacy_secret_key(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.RetrieveLegacySecretKeyRequest(
            key="key_value",
        )


def test_retrieve_legacy_secret_key_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.retrieve_legacy_secret_key
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.retrieve_legacy_secret_key
        ] = mock_rpc
        request = {}
        client.retrieve_legacy_secret_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.retrieve_legacy_secret_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.retrieve_legacy_secret_key
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.retrieve_legacy_secret_key
        ] = mock_rpc

        request = {}
        await client.retrieve_legacy_secret_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.retrieve_legacy_secret_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.RetrieveLegacySecretKeyRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RetrieveLegacySecretKeyResponse(
                legacy_secret_key="legacy_secret_key_value",
            )
        )
        response = await client.retrieve_legacy_secret_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.RetrieveLegacySecretKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.RetrieveLegacySecretKeyResponse)
    assert response.legacy_secret_key == "legacy_secret_key_value"


@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_async_from_dict():
    await test_retrieve_legacy_secret_key_async(request_type=dict)


def test_retrieve_legacy_secret_key_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.RetrieveLegacySecretKeyRequest()

    request.key = "key_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.RetrieveLegacySecretKeyResponse()
        client.retrieve_legacy_secret_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "key=key_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.RetrieveLegacySecretKeyRequest()

    request.key = "key_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RetrieveLegacySecretKeyResponse()
        )
        await client.retrieve_legacy_secret_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "key=key_value",
    ) in kw["metadata"]


def test_retrieve_legacy_secret_key_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.RetrieveLegacySecretKeyResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.retrieve_legacy_secret_key(
            key="key_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].key
        mock_val = "key_value"
        assert arg == mock_val


def test_retrieve_legacy_secret_key_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.retrieve_legacy_secret_key(
            recaptchaenterprise.RetrieveLegacySecretKeyRequest(),
            key="key_value",
        )


@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.RetrieveLegacySecretKeyResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RetrieveLegacySecretKeyResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.retrieve_legacy_secret_key(
            key="key_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].key
        mock_val = "key_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.retrieve_legacy_secret_key(
            recaptchaenterprise.RetrieveLegacySecretKeyRequest(),
            key="key_value",
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.GetKeyRequest,
        dict,
    ],
)
def test_get_key(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key(
            name="name_value",
            display_name="display_name_value",
        )
        response = client.get_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.GetKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


def test_get_key_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.GetKeyRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.get_key(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.GetKeyRequest(
            name="name_value",
        )


def test_get_key_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.get_key in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.get_key] = mock_rpc
        request = {}
        client.get_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_get_key_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.get_key
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.get_key
        ] = mock_rpc

        request = {}
        await client.get_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.get_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_get_key_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.GetKeyRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        response = await client.get_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.GetKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


@pytest.mark.asyncio
async def test_get_key_async_from_dict():
    await test_get_key_async(request_type=dict)


def test_get_key_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.GetKeyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.get_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_get_key_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.GetKeyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        await client.get_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_get_key_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.get_key(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


def test_get_key_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_key(
            recaptchaenterprise.GetKeyRequest(),
            name="name_value",
        )


@pytest.mark.asyncio
async def test_get_key_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.get_key(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_get_key_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.get_key(
            recaptchaenterprise.GetKeyRequest(),
            name="name_value",
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.UpdateKeyRequest,
        dict,
    ],
)
def test_update_key(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key(
            name="name_value",
            display_name="display_name_value",
        )
        response = client.update_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.UpdateKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


def test_update_key_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.UpdateKeyRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.update_key(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.UpdateKeyRequest()


def test_update_key_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.update_key in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.update_key] = mock_rpc
        request = {}
        client.update_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.update_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_update_key_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.update_key
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.update_key
        ] = mock_rpc

        request = {}
        await client.update_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.update_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_update_key_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.UpdateKeyRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        response = await client.update_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.UpdateKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


@pytest.mark.asyncio
async def test_update_key_async_from_dict():
    await test_update_key_async(request_type=dict)


def test_update_key_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.UpdateKeyRequest()

    request.key.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.update_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "key.name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_update_key_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.UpdateKeyRequest()

    request.key.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        await client.update_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "key.name=name_value",
    ) in kw["metadata"]


def test_update_key_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.update_key(
            key=recaptchaenterprise.Key(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].key
        mock_val = recaptchaenterprise.Key(name="name_value")
        assert arg == mock_val
        arg = args[0].update_mask
        mock_val = field_mask_pb2.FieldMask(paths=["paths_value"])
        assert arg == mock_val


def test_update_key_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.update_key(
            recaptchaenterprise.UpdateKeyRequest(),
            key=recaptchaenterprise.Key(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )


@pytest.mark.asyncio
async def test_update_key_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.update_key(
            key=recaptchaenterprise.Key(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].key
        mock_val = recaptchaenterprise.Key(name="name_value")
        assert arg == mock_val
        arg = args[0].update_mask
        mock_val = field_mask_pb2.FieldMask(paths=["paths_value"])
        assert arg == mock_val


@pytest.mark.asyncio
async def test_update_key_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.update_key(
            recaptchaenterprise.UpdateKeyRequest(),
            key=recaptchaenterprise.Key(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.DeleteKeyRequest,
        dict,
    ],
)
def test_delete_key(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None
        response = client.delete_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.DeleteKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None


def test_delete_key_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.DeleteKeyRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.delete_key(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.DeleteKeyRequest(
            name="name_value",
        )


def test_delete_key_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.delete_key in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.delete_key] = mock_rpc
        request = {}
        client.delete_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.delete_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_delete_key_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.delete_key
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.delete_key
        ] = mock_rpc

        request = {}
        await client.delete_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.delete_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_delete_key_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.DeleteKeyRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        response = await client.delete_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.DeleteKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None


@pytest.mark.asyncio
async def test_delete_key_async_from_dict():
    await test_delete_key_async(request_type=dict)


def test_delete_key_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.DeleteKeyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        call.return_value = None
        client.delete_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_delete_key_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.DeleteKeyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        await client.delete_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_delete_key_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.delete_key(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


def test_delete_key_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.delete_key(
            recaptchaenterprise.DeleteKeyRequest(),
            name="name_value",
        )


@pytest.mark.asyncio
async def test_delete_key_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.delete_key(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_delete_key_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.delete_key(
            recaptchaenterprise.DeleteKeyRequest(),
            name="name_value",
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.MigrateKeyRequest,
        dict,
    ],
)
def test_migrate_key(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Key(
            name="name_value",
            display_name="display_name_value",
        )
        response = client.migrate_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.MigrateKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


def test_migrate_key_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.MigrateKeyRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.migrate_key(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.MigrateKeyRequest(
            name="name_value",
        )


def test_migrate_key_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.migrate_key in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.migrate_key] = mock_rpc
        request = {}
        client.migrate_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.migrate_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_migrate_key_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.migrate_key
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.migrate_key
        ] = mock_rpc

        request = {}
        await client.migrate_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.migrate_key(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_migrate_key_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.MigrateKeyRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        response = await client.migrate_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.MigrateKeyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Key)
    assert response.name == "name_value"
    assert response.display_name == "display_name_value"


@pytest.mark.asyncio
async def test_migrate_key_async_from_dict():
    await test_migrate_key_async(request_type=dict)


def test_migrate_key_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.MigrateKeyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.migrate_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_migrate_key_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.MigrateKeyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key()
        )
        await client.migrate_key(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.AddIpOverrideRequest,
        dict,
    ],
)
def test_add_ip_override(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.AddIpOverrideResponse()
        response = client.add_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.AddIpOverrideRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.AddIpOverrideResponse)


def test_add_ip_override_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.AddIpOverrideRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.add_ip_override(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.AddIpOverrideRequest(
            name="name_value",
        )


def test_add_ip_override_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.add_ip_override in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.add_ip_override] = mock_rpc
        request = {}
        client.add_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.add_ip_override(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_add_ip_override_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.add_ip_override
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.add_ip_override
        ] = mock_rpc

        request = {}
        await client.add_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.add_ip_override(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_add_ip_override_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.AddIpOverrideRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AddIpOverrideResponse()
        )
        response = await client.add_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.AddIpOverrideRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.AddIpOverrideResponse)


@pytest.mark.asyncio
async def test_add_ip_override_async_from_dict():
    await test_add_ip_override_async(request_type=dict)


def test_add_ip_override_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.AddIpOverrideRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        call.return_value = recaptchaenterprise.AddIpOverrideResponse()
        client.add_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_add_ip_override_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.AddIpOverrideRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AddIpOverrideResponse()
        )
        await client.add_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_add_ip_override_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.AddIpOverrideResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.add_ip_override(
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val
        arg = args[0].ip_override_data
        mock_val = recaptchaenterprise.IpOverrideData(ip="ip_value")
        assert arg == mock_val


def test_add_ip_override_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.add_ip_override(
            recaptchaenterprise.AddIpOverrideRequest(),
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )


@pytest.mark.asyncio
async def test_add_ip_override_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.AddIpOverrideResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AddIpOverrideResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.add_ip_override(
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val
        arg = args[0].ip_override_data
        mock_val = recaptchaenterprise.IpOverrideData(ip="ip_value")
        assert arg == mock_val


@pytest.mark.asyncio
async def test_add_ip_override_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.add_ip_override(
            recaptchaenterprise.AddIpOverrideRequest(),
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.RemoveIpOverrideRequest,
        dict,
    ],
)
def test_remove_ip_override(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.RemoveIpOverrideResponse()
        response = client.remove_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.RemoveIpOverrideRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.RemoveIpOverrideResponse)


def test_remove_ip_override_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.RemoveIpOverrideRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.remove_ip_override(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.RemoveIpOverrideRequest(
            name="name_value",
        )


def test_remove_ip_override_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.remove_ip_override in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.remove_ip_override
        ] = mock_rpc
        request = {}
        client.remove_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.remove_ip_override(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_remove_ip_override_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.remove_ip_override
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.remove_ip_override
        ] = mock_rpc

        request = {}
        await client.remove_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.remove_ip_override(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_remove_ip_override_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.RemoveIpOverrideRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RemoveIpOverrideResponse()
        )
        response = await client.remove_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.RemoveIpOverrideRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.RemoveIpOverrideResponse)


@pytest.mark.asyncio
async def test_remove_ip_override_async_from_dict():
    await test_remove_ip_override_async(request_type=dict)


def test_remove_ip_override_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.RemoveIpOverrideRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.RemoveIpOverrideResponse()
        client.remove_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_remove_ip_override_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.RemoveIpOverrideRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RemoveIpOverrideResponse()
        )
        await client.remove_ip_override(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_remove_ip_override_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.RemoveIpOverrideResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.remove_ip_override(
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val
        arg = args[0].ip_override_data
        mock_val = recaptchaenterprise.IpOverrideData(ip="ip_value")
        assert arg == mock_val


def test_remove_ip_override_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.remove_ip_override(
            recaptchaenterprise.RemoveIpOverrideRequest(),
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )


@pytest.mark.asyncio
async def test_remove_ip_override_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.RemoveIpOverrideResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RemoveIpOverrideResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.remove_ip_override(
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val
        arg = args[0].ip_override_data
        mock_val = recaptchaenterprise.IpOverrideData(ip="ip_value")
        assert arg == mock_val


@pytest.mark.asyncio
async def test_remove_ip_override_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.remove_ip_override(
            recaptchaenterprise.RemoveIpOverrideRequest(),
            name="name_value",
            ip_override_data=recaptchaenterprise.IpOverrideData(ip="ip_value"),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.ListIpOverridesRequest,
        dict,
    ],
)
def test_list_ip_overrides(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListIpOverridesResponse(
            next_page_token="next_page_token_value",
        )
        response = client.list_ip_overrides(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListIpOverridesRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListIpOverridesPager)
    assert response.next_page_token == "next_page_token_value"


def test_list_ip_overrides_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.ListIpOverridesRequest(
        parent="parent_value",
        page_token="page_token_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.list_ip_overrides(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.ListIpOverridesRequest(
            parent="parent_value",
            page_token="page_token_value",
        )


def test_list_ip_overrides_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.list_ip_overrides in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.list_ip_overrides
        ] = mock_rpc
        request = {}
        client.list_ip_overrides(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_ip_overrides(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_ip_overrides_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.list_ip_overrides
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.list_ip_overrides
        ] = mock_rpc

        request = {}
        await client.list_ip_overrides(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_ip_overrides(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_ip_overrides_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.ListIpOverridesRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListIpOverridesResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = await client.list_ip_overrides(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListIpOverridesRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListIpOverridesAsyncPager)
    assert response.next_page_token == "next_page_token_value"


@pytest.mark.asyncio
async def test_list_ip_overrides_async_from_dict():
    await test_list_ip_overrides_async(request_type=dict)


def test_list_ip_overrides_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListIpOverridesRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ListIpOverridesResponse()
        client.list_ip_overrides(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_list_ip_overrides_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListIpOverridesRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListIpOverridesResponse()
        )
        await client.list_ip_overrides(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_list_ip_overrides_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListIpOverridesResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_ip_overrides(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


def test_list_ip_overrides_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_ip_overrides(
            recaptchaenterprise.ListIpOverridesRequest(),
            parent="parent_value",
        )


@pytest.mark.asyncio
async def test_list_ip_overrides_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListIpOverridesResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListIpOverridesResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_ip_overrides(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_list_ip_overrides_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_ip_overrides(
            recaptchaenterprise.ListIpOverridesRequest(),
            parent="parent_value",
        )


def test_list_ip_overrides_pager(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((("parent", ""),)),
        )
        pager = client.list_ip_overrides(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, recaptchaenterprise.IpOverrideData) for i in results)


def test_list_ip_overrides_pages(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_ip_overrides(request={}).pages)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.asyncio
async def test_list_ip_overrides_async_pager():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_ip_overrides(
            request={},
        )
        assert async_pager.next_page_token == "abc"
        responses = []
        async for response in async_pager:  # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, recaptchaenterprise.IpOverrideData) for i in responses)


@pytest.mark.asyncio
async def test_list_ip_overrides_async_pages():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListIpOverridesResponse(
                ip_overrides=[
                    recaptchaenterprise.IpOverrideData(),
                    recaptchaenterprise.IpOverrideData(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in (  # pragma: no branch
            await client.list_ip_overrides(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.GetMetricsRequest,
        dict,
    ],
)
def test_get_metrics(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Metrics(
            name="name_value",
        )
        response = client.get_metrics(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.GetMetricsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Metrics)
    assert response.name == "name_value"


def test_get_metrics_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.GetMetricsRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.get_metrics(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.GetMetricsRequest(
            name="name_value",
        )


def test_get_metrics_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.get_metrics in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[client._transport.get_metrics] = mock_rpc
        request = {}
        client.get_metrics(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_metrics(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_get_metrics_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.get_metrics
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.get_metrics
        ] = mock_rpc

        request = {}
        await client.get_metrics(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.get_metrics(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_get_metrics_async(
    transport: str = "grpc_asyncio", request_type=recaptchaenterprise.GetMetricsRequest
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Metrics(
                name="name_value",
            )
        )
        response = await client.get_metrics(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.GetMetricsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.Metrics)
    assert response.name == "name_value"


@pytest.mark.asyncio
async def test_get_metrics_async_from_dict():
    await test_get_metrics_async(request_type=dict)


def test_get_metrics_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.GetMetricsRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        call.return_value = recaptchaenterprise.Metrics()
        client.get_metrics(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_get_metrics_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.GetMetricsRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Metrics()
        )
        await client.get_metrics(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_get_metrics_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Metrics()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.get_metrics(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


def test_get_metrics_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_metrics(
            recaptchaenterprise.GetMetricsRequest(),
            name="name_value",
        )


@pytest.mark.asyncio
async def test_get_metrics_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.Metrics()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Metrics()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.get_metrics(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_get_metrics_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.get_metrics(
            recaptchaenterprise.GetMetricsRequest(),
            name="name_value",
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.CreateFirewallPolicyRequest,
        dict,
    ],
)
def test_create_firewall_policy(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy(
            name="name_value",
            description="description_value",
            path="path_value",
            condition="condition_value",
        )
        response = client.create_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.CreateFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.FirewallPolicy)
    assert response.name == "name_value"
    assert response.description == "description_value"
    assert response.path == "path_value"
    assert response.condition == "condition_value"


def test_create_firewall_policy_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.CreateFirewallPolicyRequest(
        parent="parent_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.create_firewall_policy(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.CreateFirewallPolicyRequest(
            parent="parent_value",
        )


def test_create_firewall_policy_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.create_firewall_policy
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.create_firewall_policy
        ] = mock_rpc
        request = {}
        client.create_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.create_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_create_firewall_policy_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.create_firewall_policy
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.create_firewall_policy
        ] = mock_rpc

        request = {}
        await client.create_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.create_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_create_firewall_policy_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.CreateFirewallPolicyRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy(
                name="name_value",
                description="description_value",
                path="path_value",
                condition="condition_value",
            )
        )
        response = await client.create_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.CreateFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.FirewallPolicy)
    assert response.name == "name_value"
    assert response.description == "description_value"
    assert response.path == "path_value"
    assert response.condition == "condition_value"


@pytest.mark.asyncio
async def test_create_firewall_policy_async_from_dict():
    await test_create_firewall_policy_async(request_type=dict)


def test_create_firewall_policy_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.CreateFirewallPolicyRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.FirewallPolicy()
        client.create_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_create_firewall_policy_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.CreateFirewallPolicyRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy()
        )
        await client.create_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_create_firewall_policy_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.create_firewall_policy(
            parent="parent_value",
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].firewall_policy
        mock_val = recaptchaenterprise.FirewallPolicy(name="name_value")
        assert arg == mock_val


def test_create_firewall_policy_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_firewall_policy(
            recaptchaenterprise.CreateFirewallPolicyRequest(),
            parent="parent_value",
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
        )


@pytest.mark.asyncio
async def test_create_firewall_policy_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.create_firewall_policy(
            parent="parent_value",
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].firewall_policy
        mock_val = recaptchaenterprise.FirewallPolicy(name="name_value")
        assert arg == mock_val


@pytest.mark.asyncio
async def test_create_firewall_policy_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.create_firewall_policy(
            recaptchaenterprise.CreateFirewallPolicyRequest(),
            parent="parent_value",
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.ListFirewallPoliciesRequest,
        dict,
    ],
)
def test_list_firewall_policies(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListFirewallPoliciesResponse(
            next_page_token="next_page_token_value",
        )
        response = client.list_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListFirewallPoliciesRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListFirewallPoliciesPager)
    assert response.next_page_token == "next_page_token_value"


def test_list_firewall_policies_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.ListFirewallPoliciesRequest(
        parent="parent_value",
        page_token="page_token_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.list_firewall_policies(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.ListFirewallPoliciesRequest(
            parent="parent_value",
            page_token="page_token_value",
        )


def test_list_firewall_policies_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.list_firewall_policies
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.list_firewall_policies
        ] = mock_rpc
        request = {}
        client.list_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_firewall_policies(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_firewall_policies_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.list_firewall_policies
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.list_firewall_policies
        ] = mock_rpc

        request = {}
        await client.list_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_firewall_policies(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_firewall_policies_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.ListFirewallPoliciesRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListFirewallPoliciesResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = await client.list_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListFirewallPoliciesRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListFirewallPoliciesAsyncPager)
    assert response.next_page_token == "next_page_token_value"


@pytest.mark.asyncio
async def test_list_firewall_policies_async_from_dict():
    await test_list_firewall_policies_async(request_type=dict)


def test_list_firewall_policies_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListFirewallPoliciesRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ListFirewallPoliciesResponse()
        client.list_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_list_firewall_policies_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListFirewallPoliciesRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListFirewallPoliciesResponse()
        )
        await client.list_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_list_firewall_policies_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListFirewallPoliciesResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_firewall_policies(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


def test_list_firewall_policies_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_firewall_policies(
            recaptchaenterprise.ListFirewallPoliciesRequest(),
            parent="parent_value",
        )


@pytest.mark.asyncio
async def test_list_firewall_policies_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListFirewallPoliciesResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListFirewallPoliciesResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_firewall_policies(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_list_firewall_policies_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_firewall_policies(
            recaptchaenterprise.ListFirewallPoliciesRequest(),
            parent="parent_value",
        )


def test_list_firewall_policies_pager(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((("parent", ""),)),
        )
        pager = client.list_firewall_policies(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, recaptchaenterprise.FirewallPolicy) for i in results)


def test_list_firewall_policies_pages(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_firewall_policies(request={}).pages)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.asyncio
async def test_list_firewall_policies_async_pager():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_firewall_policies(
            request={},
        )
        assert async_pager.next_page_token == "abc"
        responses = []
        async for response in async_pager:  # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, recaptchaenterprise.FirewallPolicy) for i in responses)


@pytest.mark.asyncio
async def test_list_firewall_policies_async_pages():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListFirewallPoliciesResponse(
                firewall_policies=[
                    recaptchaenterprise.FirewallPolicy(),
                    recaptchaenterprise.FirewallPolicy(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in (  # pragma: no branch
            await client.list_firewall_policies(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.GetFirewallPolicyRequest,
        dict,
    ],
)
def test_get_firewall_policy(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy(
            name="name_value",
            description="description_value",
            path="path_value",
            condition="condition_value",
        )
        response = client.get_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.GetFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.FirewallPolicy)
    assert response.name == "name_value"
    assert response.description == "description_value"
    assert response.path == "path_value"
    assert response.condition == "condition_value"


def test_get_firewall_policy_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.GetFirewallPolicyRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.get_firewall_policy(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.GetFirewallPolicyRequest(
            name="name_value",
        )


def test_get_firewall_policy_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.get_firewall_policy in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.get_firewall_policy
        ] = mock_rpc
        request = {}
        client.get_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_get_firewall_policy_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.get_firewall_policy
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.get_firewall_policy
        ] = mock_rpc

        request = {}
        await client.get_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.get_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_get_firewall_policy_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.GetFirewallPolicyRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy(
                name="name_value",
                description="description_value",
                path="path_value",
                condition="condition_value",
            )
        )
        response = await client.get_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.GetFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.FirewallPolicy)
    assert response.name == "name_value"
    assert response.description == "description_value"
    assert response.path == "path_value"
    assert response.condition == "condition_value"


@pytest.mark.asyncio
async def test_get_firewall_policy_async_from_dict():
    await test_get_firewall_policy_async(request_type=dict)


def test_get_firewall_policy_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.GetFirewallPolicyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.FirewallPolicy()
        client.get_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_get_firewall_policy_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.GetFirewallPolicyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy()
        )
        await client.get_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_get_firewall_policy_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.get_firewall_policy(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


def test_get_firewall_policy_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_firewall_policy(
            recaptchaenterprise.GetFirewallPolicyRequest(),
            name="name_value",
        )


@pytest.mark.asyncio
async def test_get_firewall_policy_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.get_firewall_policy(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_get_firewall_policy_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.get_firewall_policy(
            recaptchaenterprise.GetFirewallPolicyRequest(),
            name="name_value",
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.UpdateFirewallPolicyRequest,
        dict,
    ],
)
def test_update_firewall_policy(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy(
            name="name_value",
            description="description_value",
            path="path_value",
            condition="condition_value",
        )
        response = client.update_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.UpdateFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.FirewallPolicy)
    assert response.name == "name_value"
    assert response.description == "description_value"
    assert response.path == "path_value"
    assert response.condition == "condition_value"


def test_update_firewall_policy_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.UpdateFirewallPolicyRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.update_firewall_policy(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.UpdateFirewallPolicyRequest()


def test_update_firewall_policy_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.update_firewall_policy
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.update_firewall_policy
        ] = mock_rpc
        request = {}
        client.update_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.update_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_update_firewall_policy_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.update_firewall_policy
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.update_firewall_policy
        ] = mock_rpc

        request = {}
        await client.update_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.update_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_update_firewall_policy_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.UpdateFirewallPolicyRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy(
                name="name_value",
                description="description_value",
                path="path_value",
                condition="condition_value",
            )
        )
        response = await client.update_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.UpdateFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.FirewallPolicy)
    assert response.name == "name_value"
    assert response.description == "description_value"
    assert response.path == "path_value"
    assert response.condition == "condition_value"


@pytest.mark.asyncio
async def test_update_firewall_policy_async_from_dict():
    await test_update_firewall_policy_async(request_type=dict)


def test_update_firewall_policy_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.UpdateFirewallPolicyRequest()

    request.firewall_policy.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.FirewallPolicy()
        client.update_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "firewall_policy.name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_update_firewall_policy_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.UpdateFirewallPolicyRequest()

    request.firewall_policy.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy()
        )
        await client.update_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "firewall_policy.name=name_value",
    ) in kw["metadata"]


def test_update_firewall_policy_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.update_firewall_policy(
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].firewall_policy
        mock_val = recaptchaenterprise.FirewallPolicy(name="name_value")
        assert arg == mock_val
        arg = args[0].update_mask
        mock_val = field_mask_pb2.FieldMask(paths=["paths_value"])
        assert arg == mock_val


def test_update_firewall_policy_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.update_firewall_policy(
            recaptchaenterprise.UpdateFirewallPolicyRequest(),
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )


@pytest.mark.asyncio
async def test_update_firewall_policy_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.FirewallPolicy()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.update_firewall_policy(
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].firewall_policy
        mock_val = recaptchaenterprise.FirewallPolicy(name="name_value")
        assert arg == mock_val
        arg = args[0].update_mask
        mock_val = field_mask_pb2.FieldMask(paths=["paths_value"])
        assert arg == mock_val


@pytest.mark.asyncio
async def test_update_firewall_policy_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.update_firewall_policy(
            recaptchaenterprise.UpdateFirewallPolicyRequest(),
            firewall_policy=recaptchaenterprise.FirewallPolicy(name="name_value"),
            update_mask=field_mask_pb2.FieldMask(paths=["paths_value"]),
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.DeleteFirewallPolicyRequest,
        dict,
    ],
)
def test_delete_firewall_policy(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = None
        response = client.delete_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.DeleteFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None


def test_delete_firewall_policy_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.DeleteFirewallPolicyRequest(
        name="name_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.delete_firewall_policy(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.DeleteFirewallPolicyRequest(
            name="name_value",
        )


def test_delete_firewall_policy_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.delete_firewall_policy
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.delete_firewall_policy
        ] = mock_rpc
        request = {}
        client.delete_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.delete_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_delete_firewall_policy_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.delete_firewall_policy
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.delete_firewall_policy
        ] = mock_rpc

        request = {}
        await client.delete_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.delete_firewall_policy(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_delete_firewall_policy_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.DeleteFirewallPolicyRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        response = await client.delete_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.DeleteFirewallPolicyRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None


@pytest.mark.asyncio
async def test_delete_firewall_policy_async_from_dict():
    await test_delete_firewall_policy_async(request_type=dict)


def test_delete_firewall_policy_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.DeleteFirewallPolicyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        call.return_value = None
        client.delete_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_delete_firewall_policy_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.DeleteFirewallPolicyRequest()

    request.name = "name_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        await client.delete_firewall_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "name=name_value",
    ) in kw["metadata"]


def test_delete_firewall_policy_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = None
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.delete_firewall_policy(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


def test_delete_firewall_policy_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.delete_firewall_policy(
            recaptchaenterprise.DeleteFirewallPolicyRequest(),
            name="name_value",
        )


@pytest.mark.asyncio
async def test_delete_firewall_policy_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = None

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.delete_firewall_policy(
            name="name_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = "name_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_delete_firewall_policy_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.delete_firewall_policy(
            recaptchaenterprise.DeleteFirewallPolicyRequest(),
            name="name_value",
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.ReorderFirewallPoliciesRequest,
        dict,
    ],
)
def test_reorder_firewall_policies(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ReorderFirewallPoliciesResponse()
        response = client.reorder_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ReorderFirewallPoliciesRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.ReorderFirewallPoliciesResponse)


def test_reorder_firewall_policies_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.ReorderFirewallPoliciesRequest(
        parent="parent_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.reorder_firewall_policies(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.ReorderFirewallPoliciesRequest(
            parent="parent_value",
        )


def test_reorder_firewall_policies_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.reorder_firewall_policies
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.reorder_firewall_policies
        ] = mock_rpc
        request = {}
        client.reorder_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.reorder_firewall_policies(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_reorder_firewall_policies_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.reorder_firewall_policies
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.reorder_firewall_policies
        ] = mock_rpc

        request = {}
        await client.reorder_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.reorder_firewall_policies(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_reorder_firewall_policies_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.ReorderFirewallPoliciesRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ReorderFirewallPoliciesResponse()
        )
        response = await client.reorder_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ReorderFirewallPoliciesRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, recaptchaenterprise.ReorderFirewallPoliciesResponse)


@pytest.mark.asyncio
async def test_reorder_firewall_policies_async_from_dict():
    await test_reorder_firewall_policies_async(request_type=dict)


def test_reorder_firewall_policies_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ReorderFirewallPoliciesRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ReorderFirewallPoliciesResponse()
        client.reorder_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_reorder_firewall_policies_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ReorderFirewallPoliciesRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ReorderFirewallPoliciesResponse()
        )
        await client.reorder_firewall_policies(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_reorder_firewall_policies_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ReorderFirewallPoliciesResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.reorder_firewall_policies(
            parent="parent_value",
            names=["names_value"],
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].names
        mock_val = ["names_value"]
        assert arg == mock_val


def test_reorder_firewall_policies_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.reorder_firewall_policies(
            recaptchaenterprise.ReorderFirewallPoliciesRequest(),
            parent="parent_value",
            names=["names_value"],
        )


@pytest.mark.asyncio
async def test_reorder_firewall_policies_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ReorderFirewallPoliciesResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ReorderFirewallPoliciesResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.reorder_firewall_policies(
            parent="parent_value",
            names=["names_value"],
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val
        arg = args[0].names
        mock_val = ["names_value"]
        assert arg == mock_val


@pytest.mark.asyncio
async def test_reorder_firewall_policies_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.reorder_firewall_policies(
            recaptchaenterprise.ReorderFirewallPoliciesRequest(),
            parent="parent_value",
            names=["names_value"],
        )


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.ListRelatedAccountGroupsRequest,
        dict,
    ],
)
def test_list_related_account_groups(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListRelatedAccountGroupsResponse(
            next_page_token="next_page_token_value",
        )
        response = client.list_related_account_groups(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListRelatedAccountGroupsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListRelatedAccountGroupsPager)
    assert response.next_page_token == "next_page_token_value"


def test_list_related_account_groups_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.ListRelatedAccountGroupsRequest(
        parent="parent_value",
        page_token="page_token_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.list_related_account_groups(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.ListRelatedAccountGroupsRequest(
            parent="parent_value",
            page_token="page_token_value",
        )


def test_list_related_account_groups_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.list_related_account_groups
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.list_related_account_groups
        ] = mock_rpc
        request = {}
        client.list_related_account_groups(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_related_account_groups(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_related_account_groups_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.list_related_account_groups
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.list_related_account_groups
        ] = mock_rpc

        request = {}
        await client.list_related_account_groups(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_related_account_groups(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_related_account_groups_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.ListRelatedAccountGroupsRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = await client.list_related_account_groups(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListRelatedAccountGroupsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListRelatedAccountGroupsAsyncPager)
    assert response.next_page_token == "next_page_token_value"


@pytest.mark.asyncio
async def test_list_related_account_groups_async_from_dict():
    await test_list_related_account_groups_async(request_type=dict)


def test_list_related_account_groups_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListRelatedAccountGroupsRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ListRelatedAccountGroupsResponse()
        client.list_related_account_groups(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_list_related_account_groups_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListRelatedAccountGroupsRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupsResponse()
        )
        await client.list_related_account_groups(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_list_related_account_groups_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListRelatedAccountGroupsResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_related_account_groups(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


def test_list_related_account_groups_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_related_account_groups(
            recaptchaenterprise.ListRelatedAccountGroupsRequest(),
            parent="parent_value",
        )


@pytest.mark.asyncio
async def test_list_related_account_groups_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = recaptchaenterprise.ListRelatedAccountGroupsResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupsResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_related_account_groups(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_list_related_account_groups_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_related_account_groups(
            recaptchaenterprise.ListRelatedAccountGroupsRequest(),
            parent="parent_value",
        )


def test_list_related_account_groups_pager(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((("parent", ""),)),
        )
        pager = client.list_related_account_groups(
            request={}, retry=retry, timeout=timeout
        )

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(
            isinstance(i, recaptchaenterprise.RelatedAccountGroup) for i in results
        )


def test_list_related_account_groups_pages(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_related_account_groups(request={}).pages)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.asyncio
async def test_list_related_account_groups_async_pager():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_related_account_groups(
            request={},
        )
        assert async_pager.next_page_token == "abc"
        responses = []
        async for response in async_pager:  # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(
            isinstance(i, recaptchaenterprise.RelatedAccountGroup) for i in responses
        )


@pytest.mark.asyncio
async def test_list_related_account_groups_async_pages():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                related_account_groups=[
                    recaptchaenterprise.RelatedAccountGroup(),
                    recaptchaenterprise.RelatedAccountGroup(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in (  # pragma: no branch
            await client.list_related_account_groups(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest,
        dict,
    ],
)
def test_list_related_account_group_memberships(request_type, transport: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = client.list_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListRelatedAccountGroupMembershipsPager)
    assert response.next_page_token == "next_page_token_value"


def test_list_related_account_group_memberships_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest(
        parent="parent_value",
        page_token="page_token_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.list_related_account_group_memberships(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest(
            parent="parent_value",
            page_token="page_token_value",
        )


def test_list_related_account_group_memberships_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.list_related_account_group_memberships
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.list_related_account_group_memberships
        ] = mock_rpc
        request = {}
        client.list_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_related_account_group_memberships(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.list_related_account_group_memberships
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.list_related_account_group_memberships
        ] = mock_rpc

        request = {}
        await client.list_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_related_account_group_memberships(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = await client.list_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListRelatedAccountGroupMembershipsAsyncPager)
    assert response.next_page_token == "next_page_token_value"


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_async_from_dict():
    await test_list_related_account_group_memberships_async(request_type=dict)


def test_list_related_account_group_memberships_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse()
        )
        client.list_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest()

    request.parent = "parent_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse()
        )
        await client.list_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "parent=parent_value",
    ) in kw["metadata"]


def test_list_related_account_group_memberships_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_related_account_group_memberships(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


def test_list_related_account_group_memberships_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_related_account_group_memberships(
            recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest(),
            parent="parent_value",
        )


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse()
        )

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_related_account_group_memberships(
            parent="parent_value",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = "parent_value"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_related_account_group_memberships(
            recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest(),
            parent="parent_value",
        )


def test_list_related_account_group_memberships_pager(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((("parent", ""),)),
        )
        pager = client.list_related_account_group_memberships(
            request={}, retry=retry, timeout=timeout
        )

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(
            isinstance(i, recaptchaenterprise.RelatedAccountGroupMembership)
            for i in results
        )


def test_list_related_account_group_memberships_pages(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_related_account_group_memberships(request={}).pages)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_async_pager():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_related_account_group_memberships(
            request={},
        )
        assert async_pager.next_page_token == "abc"
        responses = []
        async for response in async_pager:  # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(
            isinstance(i, recaptchaenterprise.RelatedAccountGroupMembership)
            for i in responses
        )


@pytest.mark.asyncio
async def test_list_related_account_group_memberships_async_pages():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in (  # pragma: no branch
            await client.list_related_account_group_memberships(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.parametrize(
    "request_type",
    [
        recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest,
        dict,
    ],
)
def test_search_related_account_group_memberships(
    request_type, transport: str = "grpc"
):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = client.search_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchRelatedAccountGroupMembershipsPager)
    assert response.next_page_token == "next_page_token_value"


def test_search_related_account_group_memberships_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest(
        project="project_value",
        account_id="account_id_value",
        page_token="page_token_value",
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client.search_related_account_group_memberships(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[
            0
        ] == recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest(
            project="project_value",
            account_id="account_id_value",
            page_token="page_token_value",
        )


def test_search_related_account_group_memberships_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._transport.search_related_account_group_memberships
            in client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = (
            "foo"  # operation_request.operation in compute client(s) expect a string.
        )
        client._transport._wrapped_methods[
            client._transport.search_related_account_group_memberships
        ] = mock_rpc
        request = {}
        client.search_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.search_related_account_group_memberships(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_async_use_cached_wrapped_rpc(
    transport: str = "grpc_asyncio",
):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = RecaptchaEnterpriseServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert (
            client._client._transport.search_related_account_group_memberships
            in client._client._transport._wrapped_methods
        )

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[
            client._client._transport.search_related_account_group_memberships
        ] = mock_rpc

        request = {}
        await client.search_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.search_related_account_group_memberships(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_async(
    transport: str = "grpc_asyncio",
    request_type=recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest,
):
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                next_page_token="next_page_token_value",
            )
        )
        response = await client.search_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchRelatedAccountGroupMembershipsAsyncPager)
    assert response.next_page_token == "next_page_token_value"


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_async_from_dict():
    await test_search_related_account_group_memberships_async(request_type=dict)


def test_search_related_account_group_memberships_field_headers():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest()

    request.project = "project_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse()
        )
        client.search_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "project=project_value",
    ) in kw["metadata"]


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_field_headers_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest()

    request.project = "project_value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse()
        )
        await client.search_related_account_group_memberships(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        "x-goog-request-params",
        "project=project_value",
    ) in kw["metadata"]


def test_search_related_account_group_memberships_flattened():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.search_related_account_group_memberships(
            project="project_value",
            hashed_account_id=b"hashed_account_id_blob",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].project
        mock_val = "project_value"
        assert arg == mock_val
        arg = args[0].hashed_account_id
        mock_val = b"hashed_account_id_blob"
        assert arg == mock_val


def test_search_related_account_group_memberships_flattened_error():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.search_related_account_group_memberships(
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest(),
            project="project_value",
            hashed_account_id=b"hashed_account_id_blob",
        )


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_flattened_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse()
        )

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse()
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.search_related_account_group_memberships(
            project="project_value",
            hashed_account_id=b"hashed_account_id_blob",
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].project
        mock_val = "project_value"
        assert arg == mock_val
        arg = args[0].hashed_account_id
        mock_val = b"hashed_account_id_blob"
        assert arg == mock_val


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_flattened_error_async():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.search_related_account_group_memberships(
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest(),
            project="project_value",
            hashed_account_id=b"hashed_account_id_blob",
        )


def test_search_related_account_group_memberships_pager(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((("project", ""),)),
        )
        pager = client.search_related_account_group_memberships(
            request={}, retry=retry, timeout=timeout
        )

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(
            isinstance(i, recaptchaenterprise.RelatedAccountGroupMembership)
            for i in results
        )


def test_search_related_account_group_memberships_pages(transport_name: str = "grpc"):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.search_related_account_group_memberships(request={}).pages)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_async_pager():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.search_related_account_group_memberships(
            request={},
        )
        assert async_pager.next_page_token == "abc"
        responses = []
        async for response in async_pager:  # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(
            isinstance(i, recaptchaenterprise.RelatedAccountGroupMembership)
            for i in responses
        )


@pytest.mark.asyncio
async def test_search_related_account_group_memberships_async_pages():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships),
        "__call__",
        new_callable=mock.AsyncMock,
    ) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="abc",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[],
                next_page_token="def",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
                next_page_token="ghi",
            ),
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                related_account_group_memberships=[
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                    recaptchaenterprise.RelatedAccountGroupMembership(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in (  # pragma: no branch
            await client.search_related_account_group_memberships(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ["abc", "def", "ghi", ""]):
            assert page_.raw_page.next_page_token == token


def test_credentials_transport_error():
    # It is an error to provide credentials and a transport instance.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    with pytest.raises(ValueError):
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport=transport,
        )

    # It is an error to provide a credentials file and a transport instance.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    with pytest.raises(ValueError):
        client = RecaptchaEnterpriseServiceClient(
            client_options={"credentials_file": "credentials.json"},
            transport=transport,
        )

    # It is an error to provide an api_key and a transport instance.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    options = client_options.ClientOptions()
    options.api_key = "api_key"
    with pytest.raises(ValueError):
        client = RecaptchaEnterpriseServiceClient(
            client_options=options,
            transport=transport,
        )

    # It is an error to provide an api_key and a credential.
    options = client_options.ClientOptions()
    options.api_key = "api_key"
    with pytest.raises(ValueError):
        client = RecaptchaEnterpriseServiceClient(
            client_options=options, credentials=ga_credentials.AnonymousCredentials()
        )

    # It is an error to provide scopes and a transport instance.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    with pytest.raises(ValueError):
        client = RecaptchaEnterpriseServiceClient(
            client_options={"scopes": ["1", "2"]},
            transport=transport,
        )


def test_transport_instance():
    # A client may be instantiated with a custom transport instance.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    client = RecaptchaEnterpriseServiceClient(transport=transport)
    assert client.transport is transport


def test_transport_get_channel():
    # A client may be instantiated with a custom transport instance.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    channel = transport.grpc_channel
    assert channel

    transport = transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    channel = transport.grpc_channel
    assert channel


@pytest.mark.parametrize(
    "transport_class",
    [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
        transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
    ],
)
def test_transport_adc(transport_class):
    # Test default credentials are used if not provided.
    with mock.patch.object(google.auth, "default") as adc:
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport_class()
        adc.assert_called_once()


def test_transport_kind_grpc():
    transport = RecaptchaEnterpriseServiceClient.get_transport_class("grpc")(
        credentials=ga_credentials.AnonymousCredentials()
    )
    assert transport.kind == "grpc"


def test_initialize_client_w_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport="grpc"
    )
    assert client is not None


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_assessment_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.Assessment()
        client.create_assessment(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.CreateAssessmentRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_annotate_assessment_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.AnnotateAssessmentResponse()
        client.annotate_assessment(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.AnnotateAssessmentRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_key_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.create_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.CreateKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_keys_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        call.return_value = recaptchaenterprise.ListKeysResponse()
        client.list_keys(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListKeysRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_retrieve_legacy_secret_key_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.RetrieveLegacySecretKeyResponse()
        client.retrieve_legacy_secret_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.RetrieveLegacySecretKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_key_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.get_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.GetKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_update_key_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.update_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.UpdateKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_delete_key_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        call.return_value = None
        client.delete_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.DeleteKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_migrate_key_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        call.return_value = recaptchaenterprise.Key()
        client.migrate_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.MigrateKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_add_ip_override_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        call.return_value = recaptchaenterprise.AddIpOverrideResponse()
        client.add_ip_override(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.AddIpOverrideRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_remove_ip_override_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.RemoveIpOverrideResponse()
        client.remove_ip_override(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.RemoveIpOverrideRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_ip_overrides_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ListIpOverridesResponse()
        client.list_ip_overrides(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListIpOverridesRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_metrics_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        call.return_value = recaptchaenterprise.Metrics()
        client.get_metrics(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.GetMetricsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_firewall_policy_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.FirewallPolicy()
        client.create_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.CreateFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_firewall_policies_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ListFirewallPoliciesResponse()
        client.list_firewall_policies(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListFirewallPoliciesRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_firewall_policy_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.FirewallPolicy()
        client.get_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.GetFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_update_firewall_policy_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.FirewallPolicy()
        client.update_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.UpdateFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_delete_firewall_policy_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        call.return_value = None
        client.delete_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.DeleteFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_reorder_firewall_policies_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ReorderFirewallPoliciesResponse()
        client.reorder_firewall_policies(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ReorderFirewallPoliciesRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_related_account_groups_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        call.return_value = recaptchaenterprise.ListRelatedAccountGroupsResponse()
        client.list_related_account_groups(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListRelatedAccountGroupsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_related_account_group_memberships_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value = (
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse()
        )
        client.list_related_account_group_memberships(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_search_related_account_group_memberships_empty_call_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        call.return_value = (
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse()
        )
        client.search_related_account_group_memberships(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest()

        assert args[0] == request_msg


def test_transport_kind_grpc_asyncio():
    transport = RecaptchaEnterpriseServiceAsyncClient.get_transport_class(
        "grpc_asyncio"
    )(credentials=async_anonymous_credentials())
    assert transport.kind == "grpc_asyncio"


def test_initialize_client_w_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport="grpc_asyncio"
    )
    assert client is not None


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_assessment_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.create_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Assessment(
                name="name_value",
            )
        )
        await client.create_assessment(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.CreateAssessmentRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_annotate_assessment_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.annotate_assessment), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AnnotateAssessmentResponse()
        )
        await client.annotate_assessment(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.AnnotateAssessmentRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_key_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.create_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        await client.create_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.CreateKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_keys_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.list_keys), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListKeysResponse(
                next_page_token="next_page_token_value",
            )
        )
        await client.list_keys(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListKeysRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_retrieve_legacy_secret_key_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.retrieve_legacy_secret_key), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RetrieveLegacySecretKeyResponse(
                legacy_secret_key="legacy_secret_key_value",
            )
        )
        await client.retrieve_legacy_secret_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.RetrieveLegacySecretKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_key_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.get_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        await client.get_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.GetKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_update_key_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.update_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        await client.update_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.UpdateKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_delete_key_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.delete_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        await client.delete_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.DeleteKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_migrate_key_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.migrate_key), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Key(
                name="name_value",
                display_name="display_name_value",
            )
        )
        await client.migrate_key(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.MigrateKeyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_add_ip_override_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.add_ip_override), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.AddIpOverrideResponse()
        )
        await client.add_ip_override(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.AddIpOverrideRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_remove_ip_override_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.remove_ip_override), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.RemoveIpOverrideResponse()
        )
        await client.remove_ip_override(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.RemoveIpOverrideRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_ip_overrides_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_ip_overrides), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListIpOverridesResponse(
                next_page_token="next_page_token_value",
            )
        )
        await client.list_ip_overrides(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListIpOverridesRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_metrics_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(type(client.transport.get_metrics), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.Metrics(
                name="name_value",
            )
        )
        await client.get_metrics(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.GetMetricsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_firewall_policy_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.create_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy(
                name="name_value",
                description="description_value",
                path="path_value",
                condition="condition_value",
            )
        )
        await client.create_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.CreateFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_firewall_policies_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListFirewallPoliciesResponse(
                next_page_token="next_page_token_value",
            )
        )
        await client.list_firewall_policies(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListFirewallPoliciesRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_firewall_policy_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.get_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy(
                name="name_value",
                description="description_value",
                path="path_value",
                condition="condition_value",
            )
        )
        await client.get_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.GetFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_update_firewall_policy_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.update_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.FirewallPolicy(
                name="name_value",
                description="description_value",
                path="path_value",
                condition="condition_value",
            )
        )
        await client.update_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.UpdateFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_delete_firewall_policy_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.delete_firewall_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(None)
        await client.delete_firewall_policy(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.DeleteFirewallPolicyRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_reorder_firewall_policies_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.reorder_firewall_policies), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ReorderFirewallPoliciesResponse()
        )
        await client.reorder_firewall_policies(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ReorderFirewallPoliciesRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_related_account_groups_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_groups), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupsResponse(
                next_page_token="next_page_token_value",
            )
        )
        await client.list_related_account_groups(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListRelatedAccountGroupsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_related_account_group_memberships_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.list_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.ListRelatedAccountGroupMembershipsResponse(
                next_page_token="next_page_token_value",
            )
        )
        await client.list_related_account_group_memberships(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.ListRelatedAccountGroupMembershipsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_search_related_account_group_memberships_empty_call_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
        type(client.transport.search_related_account_group_memberships), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            recaptchaenterprise.SearchRelatedAccountGroupMembershipsResponse(
                next_page_token="next_page_token_value",
            )
        )
        await client.search_related_account_group_memberships(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = recaptchaenterprise.SearchRelatedAccountGroupMembershipsRequest()

        assert args[0] == request_msg


def test_transport_grpc_default():
    # A client should use the gRPC transport by default.
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    assert isinstance(
        client.transport,
        transports.RecaptchaEnterpriseServiceGrpcTransport,
    )


def test_recaptcha_enterprise_service_base_transport_error():
    # Passing both a credentials object and credentials_file should raise an error
    with pytest.raises(core_exceptions.DuplicateCredentialArgs):
        transport = transports.RecaptchaEnterpriseServiceTransport(
            credentials=ga_credentials.AnonymousCredentials(),
            credentials_file="credentials.json",
        )


def test_recaptcha_enterprise_service_base_transport():
    # Instantiate the base transport.
    with mock.patch(
        "google.cloud.recaptchaenterprise_v1.services.recaptcha_enterprise_service.transports.RecaptchaEnterpriseServiceTransport.__init__"
    ) as Transport:
        Transport.return_value = None
        transport = transports.RecaptchaEnterpriseServiceTransport(
            credentials=ga_credentials.AnonymousCredentials(),
        )

    # Every method on the transport should just blindly
    # raise NotImplementedError.
    methods = (
        "create_assessment",
        "annotate_assessment",
        "create_key",
        "list_keys",
        "retrieve_legacy_secret_key",
        "get_key",
        "update_key",
        "delete_key",
        "migrate_key",
        "add_ip_override",
        "remove_ip_override",
        "list_ip_overrides",
        "get_metrics",
        "create_firewall_policy",
        "list_firewall_policies",
        "get_firewall_policy",
        "update_firewall_policy",
        "delete_firewall_policy",
        "reorder_firewall_policies",
        "list_related_account_groups",
        "list_related_account_group_memberships",
        "search_related_account_group_memberships",
    )
    for method in methods:
        with pytest.raises(NotImplementedError):
            getattr(transport, method)(request=object())

    with pytest.raises(NotImplementedError):
        transport.close()

    # Catch all for all remaining methods and properties
    remainder = [
        "kind",
    ]
    for r in remainder:
        with pytest.raises(NotImplementedError):
            getattr(transport, r)()


def test_recaptcha_enterprise_service_base_transport_with_credentials_file():
    # Instantiate the base transport with a credentials file
    with mock.patch.object(
        google.auth, "load_credentials_from_file", autospec=True
    ) as load_creds, mock.patch(
        "google.cloud.recaptchaenterprise_v1.services.recaptcha_enterprise_service.transports.RecaptchaEnterpriseServiceTransport._prep_wrapped_messages"
    ) as Transport:
        Transport.return_value = None
        load_creds.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport = transports.RecaptchaEnterpriseServiceTransport(
            credentials_file="credentials.json",
            quota_project_id="octopus",
        )
        load_creds.assert_called_once_with(
            "credentials.json",
            scopes=None,
            default_scopes=("https://www.googleapis.com/auth/cloud-platform",),
            quota_project_id="octopus",
        )


def test_recaptcha_enterprise_service_base_transport_with_adc():
    # Test the default credentials are used if credentials and credentials_file are None.
    with mock.patch.object(google.auth, "default", autospec=True) as adc, mock.patch(
        "google.cloud.recaptchaenterprise_v1.services.recaptcha_enterprise_service.transports.RecaptchaEnterpriseServiceTransport._prep_wrapped_messages"
    ) as Transport:
        Transport.return_value = None
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport = transports.RecaptchaEnterpriseServiceTransport()
        adc.assert_called_once()


def test_recaptcha_enterprise_service_auth_adc():
    # If no credentials are provided, we should use ADC credentials.
    with mock.patch.object(google.auth, "default", autospec=True) as adc:
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        RecaptchaEnterpriseServiceClient()
        adc.assert_called_once_with(
            scopes=None,
            default_scopes=("https://www.googleapis.com/auth/cloud-platform",),
            quota_project_id=None,
        )


@pytest.mark.parametrize(
    "transport_class",
    [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
        transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
    ],
)
def test_recaptcha_enterprise_service_transport_auth_adc(transport_class):
    # If credentials and host are not provided, the transport class should use
    # ADC credentials.
    with mock.patch.object(google.auth, "default", autospec=True) as adc:
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport_class(quota_project_id="octopus", scopes=["1", "2"])
        adc.assert_called_once_with(
            scopes=["1", "2"],
            default_scopes=("https://www.googleapis.com/auth/cloud-platform",),
            quota_project_id="octopus",
        )


@pytest.mark.parametrize(
    "transport_class",
    [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
        transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
    ],
)
def test_recaptcha_enterprise_service_transport_auth_gdch_credentials(transport_class):
    host = "https://language.com"
    api_audience_tests = [None, "https://language2.com"]
    api_audience_expect = [host, "https://language2.com"]
    for t, e in zip(api_audience_tests, api_audience_expect):
        with mock.patch.object(google.auth, "default", autospec=True) as adc:
            gdch_mock = mock.MagicMock()
            type(gdch_mock).with_gdch_audience = mock.PropertyMock(
                return_value=gdch_mock
            )
            adc.return_value = (gdch_mock, None)
            transport_class(host=host, api_audience=t)
            gdch_mock.with_gdch_audience.assert_called_once_with(e)


@pytest.mark.parametrize(
    "transport_class,grpc_helpers",
    [
        (transports.RecaptchaEnterpriseServiceGrpcTransport, grpc_helpers),
        (transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport, grpc_helpers_async),
    ],
)
def test_recaptcha_enterprise_service_transport_create_channel(
    transport_class, grpc_helpers
):
    # If credentials and host are not provided, the transport class should use
    # ADC credentials.
    with mock.patch.object(
        google.auth, "default", autospec=True
    ) as adc, mock.patch.object(
        grpc_helpers, "create_channel", autospec=True
    ) as create_channel:
        creds = ga_credentials.AnonymousCredentials()
        adc.return_value = (creds, None)
        transport_class(quota_project_id="octopus", scopes=["1", "2"])

        create_channel.assert_called_with(
            "recaptchaenterprise.googleapis.com:443",
            credentials=creds,
            credentials_file=None,
            quota_project_id="octopus",
            default_scopes=("https://www.googleapis.com/auth/cloud-platform",),
            scopes=["1", "2"],
            default_host="recaptchaenterprise.googleapis.com",
            ssl_credentials=None,
            options=[
                ("grpc.max_send_message_length", -1),
                ("grpc.max_receive_message_length", -1),
            ],
        )


@pytest.mark.parametrize(
    "transport_class",
    [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
        transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
    ],
)
def test_recaptcha_enterprise_service_grpc_transport_client_cert_source_for_mtls(
    transport_class,
):
    cred = ga_credentials.AnonymousCredentials()

    # Check ssl_channel_credentials is used if provided.
    with mock.patch.object(transport_class, "create_channel") as mock_create_channel:
        mock_ssl_channel_creds = mock.Mock()
        transport_class(
            host="squid.clam.whelk",
            credentials=cred,
            ssl_channel_credentials=mock_ssl_channel_creds,
        )
        mock_create_channel.assert_called_once_with(
            "squid.clam.whelk:443",
            credentials=cred,
            credentials_file=None,
            scopes=None,
            ssl_credentials=mock_ssl_channel_creds,
            quota_project_id=None,
            options=[
                ("grpc.max_send_message_length", -1),
                ("grpc.max_receive_message_length", -1),
            ],
        )

    # Check if ssl_channel_credentials is not provided, then client_cert_source_for_mtls
    # is used.
    with mock.patch.object(transport_class, "create_channel", return_value=mock.Mock()):
        with mock.patch("grpc.ssl_channel_credentials") as mock_ssl_cred:
            transport_class(
                credentials=cred,
                client_cert_source_for_mtls=client_cert_source_callback,
            )
            expected_cert, expected_key = client_cert_source_callback()
            mock_ssl_cred.assert_called_once_with(
                certificate_chain=expected_cert, private_key=expected_key
            )


@pytest.mark.parametrize(
    "transport_name",
    [
        "grpc",
        "grpc_asyncio",
    ],
)
def test_recaptcha_enterprise_service_host_no_port(transport_name):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        client_options=client_options.ClientOptions(
            api_endpoint="recaptchaenterprise.googleapis.com"
        ),
        transport=transport_name,
    )
    assert client.transport._host == ("recaptchaenterprise.googleapis.com:443")


@pytest.mark.parametrize(
    "transport_name",
    [
        "grpc",
        "grpc_asyncio",
    ],
)
def test_recaptcha_enterprise_service_host_with_port(transport_name):
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        client_options=client_options.ClientOptions(
            api_endpoint="recaptchaenterprise.googleapis.com:8000"
        ),
        transport=transport_name,
    )
    assert client.transport._host == ("recaptchaenterprise.googleapis.com:8000")


def test_recaptcha_enterprise_service_grpc_transport_channel():
    channel = grpc.secure_channel("http://localhost/", grpc.local_channel_credentials())

    # Check that channel is used if provided.
    transport = transports.RecaptchaEnterpriseServiceGrpcTransport(
        host="squid.clam.whelk",
        channel=channel,
    )
    assert transport.grpc_channel == channel
    assert transport._host == "squid.clam.whelk:443"
    assert transport._ssl_channel_credentials == None


def test_recaptcha_enterprise_service_grpc_asyncio_transport_channel():
    channel = aio.secure_channel("http://localhost/", grpc.local_channel_credentials())

    # Check that channel is used if provided.
    transport = transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport(
        host="squid.clam.whelk",
        channel=channel,
    )
    assert transport.grpc_channel == channel
    assert transport._host == "squid.clam.whelk:443"
    assert transport._ssl_channel_credentials == None


# Remove this test when deprecated arguments (api_mtls_endpoint, client_cert_source) are
# removed from grpc/grpc_asyncio transport constructor.
@pytest.mark.parametrize(
    "transport_class",
    [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
        transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
    ],
)
def test_recaptcha_enterprise_service_transport_channel_mtls_with_client_cert_source(
    transport_class,
):
    with mock.patch(
        "grpc.ssl_channel_credentials", autospec=True
    ) as grpc_ssl_channel_cred:
        with mock.patch.object(
            transport_class, "create_channel"
        ) as grpc_create_channel:
            mock_ssl_cred = mock.Mock()
            grpc_ssl_channel_cred.return_value = mock_ssl_cred

            mock_grpc_channel = mock.Mock()
            grpc_create_channel.return_value = mock_grpc_channel

            cred = ga_credentials.AnonymousCredentials()
            with pytest.warns(DeprecationWarning):
                with mock.patch.object(google.auth, "default") as adc:
                    adc.return_value = (cred, None)
                    transport = transport_class(
                        host="squid.clam.whelk",
                        api_mtls_endpoint="mtls.squid.clam.whelk",
                        client_cert_source=client_cert_source_callback,
                    )
                    adc.assert_called_once()

            grpc_ssl_channel_cred.assert_called_once_with(
                certificate_chain=b"cert bytes", private_key=b"key bytes"
            )
            grpc_create_channel.assert_called_once_with(
                "mtls.squid.clam.whelk:443",
                credentials=cred,
                credentials_file=None,
                scopes=None,
                ssl_credentials=mock_ssl_cred,
                quota_project_id=None,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )
            assert transport.grpc_channel == mock_grpc_channel
            assert transport._ssl_channel_credentials == mock_ssl_cred


# Remove this test when deprecated arguments (api_mtls_endpoint, client_cert_source) are
# removed from grpc/grpc_asyncio transport constructor.
@pytest.mark.parametrize(
    "transport_class",
    [
        transports.RecaptchaEnterpriseServiceGrpcTransport,
        transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
    ],
)
def test_recaptcha_enterprise_service_transport_channel_mtls_with_adc(transport_class):
    mock_ssl_cred = mock.Mock()
    with mock.patch.multiple(
        "google.auth.transport.grpc.SslCredentials",
        __init__=mock.Mock(return_value=None),
        ssl_credentials=mock.PropertyMock(return_value=mock_ssl_cred),
    ):
        with mock.patch.object(
            transport_class, "create_channel"
        ) as grpc_create_channel:
            mock_grpc_channel = mock.Mock()
            grpc_create_channel.return_value = mock_grpc_channel
            mock_cred = mock.Mock()

            with pytest.warns(DeprecationWarning):
                transport = transport_class(
                    host="squid.clam.whelk",
                    credentials=mock_cred,
                    api_mtls_endpoint="mtls.squid.clam.whelk",
                    client_cert_source=None,
                )

            grpc_create_channel.assert_called_once_with(
                "mtls.squid.clam.whelk:443",
                credentials=mock_cred,
                credentials_file=None,
                scopes=None,
                ssl_credentials=mock_ssl_cred,
                quota_project_id=None,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )
            assert transport.grpc_channel == mock_grpc_channel


def test_assessment_path():
    project = "squid"
    assessment = "clam"
    expected = "projects/{project}/assessments/{assessment}".format(
        project=project,
        assessment=assessment,
    )
    actual = RecaptchaEnterpriseServiceClient.assessment_path(project, assessment)
    assert expected == actual


def test_parse_assessment_path():
    expected = {
        "project": "whelk",
        "assessment": "octopus",
    }
    path = RecaptchaEnterpriseServiceClient.assessment_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_assessment_path(path)
    assert expected == actual


def test_firewall_policy_path():
    project = "oyster"
    firewallpolicy = "nudibranch"
    expected = "projects/{project}/firewallpolicies/{firewallpolicy}".format(
        project=project,
        firewallpolicy=firewallpolicy,
    )
    actual = RecaptchaEnterpriseServiceClient.firewall_policy_path(
        project, firewallpolicy
    )
    assert expected == actual


def test_parse_firewall_policy_path():
    expected = {
        "project": "cuttlefish",
        "firewallpolicy": "mussel",
    }
    path = RecaptchaEnterpriseServiceClient.firewall_policy_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_firewall_policy_path(path)
    assert expected == actual


def test_key_path():
    project = "winkle"
    key = "nautilus"
    expected = "projects/{project}/keys/{key}".format(
        project=project,
        key=key,
    )
    actual = RecaptchaEnterpriseServiceClient.key_path(project, key)
    assert expected == actual


def test_parse_key_path():
    expected = {
        "project": "scallop",
        "key": "abalone",
    }
    path = RecaptchaEnterpriseServiceClient.key_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_key_path(path)
    assert expected == actual


def test_metrics_path():
    project = "squid"
    key = "clam"
    expected = "projects/{project}/keys/{key}/metrics".format(
        project=project,
        key=key,
    )
    actual = RecaptchaEnterpriseServiceClient.metrics_path(project, key)
    assert expected == actual


def test_parse_metrics_path():
    expected = {
        "project": "whelk",
        "key": "octopus",
    }
    path = RecaptchaEnterpriseServiceClient.metrics_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_metrics_path(path)
    assert expected == actual


def test_related_account_group_path():
    project = "oyster"
    relatedaccountgroup = "nudibranch"
    expected = "projects/{project}/relatedaccountgroups/{relatedaccountgroup}".format(
        project=project,
        relatedaccountgroup=relatedaccountgroup,
    )
    actual = RecaptchaEnterpriseServiceClient.related_account_group_path(
        project, relatedaccountgroup
    )
    assert expected == actual


def test_parse_related_account_group_path():
    expected = {
        "project": "cuttlefish",
        "relatedaccountgroup": "mussel",
    }
    path = RecaptchaEnterpriseServiceClient.related_account_group_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_related_account_group_path(path)
    assert expected == actual


def test_related_account_group_membership_path():
    project = "winkle"
    relatedaccountgroup = "nautilus"
    membership = "scallop"
    expected = "projects/{project}/relatedaccountgroups/{relatedaccountgroup}/memberships/{membership}".format(
        project=project,
        relatedaccountgroup=relatedaccountgroup,
        membership=membership,
    )
    actual = RecaptchaEnterpriseServiceClient.related_account_group_membership_path(
        project, relatedaccountgroup, membership
    )
    assert expected == actual


def test_parse_related_account_group_membership_path():
    expected = {
        "project": "abalone",
        "relatedaccountgroup": "squid",
        "membership": "clam",
    }
    path = RecaptchaEnterpriseServiceClient.related_account_group_membership_path(
        **expected
    )

    # Check that the path construction is reversible.
    actual = (
        RecaptchaEnterpriseServiceClient.parse_related_account_group_membership_path(
            path
        )
    )
    assert expected == actual


def test_common_billing_account_path():
    billing_account = "whelk"
    expected = "billingAccounts/{billing_account}".format(
        billing_account=billing_account,
    )
    actual = RecaptchaEnterpriseServiceClient.common_billing_account_path(
        billing_account
    )
    assert expected == actual


def test_parse_common_billing_account_path():
    expected = {
        "billing_account": "octopus",
    }
    path = RecaptchaEnterpriseServiceClient.common_billing_account_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_common_billing_account_path(path)
    assert expected == actual


def test_common_folder_path():
    folder = "oyster"
    expected = "folders/{folder}".format(
        folder=folder,
    )
    actual = RecaptchaEnterpriseServiceClient.common_folder_path(folder)
    assert expected == actual


def test_parse_common_folder_path():
    expected = {
        "folder": "nudibranch",
    }
    path = RecaptchaEnterpriseServiceClient.common_folder_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_common_folder_path(path)
    assert expected == actual


def test_common_organization_path():
    organization = "cuttlefish"
    expected = "organizations/{organization}".format(
        organization=organization,
    )
    actual = RecaptchaEnterpriseServiceClient.common_organization_path(organization)
    assert expected == actual


def test_parse_common_organization_path():
    expected = {
        "organization": "mussel",
    }
    path = RecaptchaEnterpriseServiceClient.common_organization_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_common_organization_path(path)
    assert expected == actual


def test_common_project_path():
    project = "winkle"
    expected = "projects/{project}".format(
        project=project,
    )
    actual = RecaptchaEnterpriseServiceClient.common_project_path(project)
    assert expected == actual


def test_parse_common_project_path():
    expected = {
        "project": "nautilus",
    }
    path = RecaptchaEnterpriseServiceClient.common_project_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_common_project_path(path)
    assert expected == actual


def test_common_location_path():
    project = "scallop"
    location = "abalone"
    expected = "projects/{project}/locations/{location}".format(
        project=project,
        location=location,
    )
    actual = RecaptchaEnterpriseServiceClient.common_location_path(project, location)
    assert expected == actual


def test_parse_common_location_path():
    expected = {
        "project": "squid",
        "location": "clam",
    }
    path = RecaptchaEnterpriseServiceClient.common_location_path(**expected)

    # Check that the path construction is reversible.
    actual = RecaptchaEnterpriseServiceClient.parse_common_location_path(path)
    assert expected == actual


def test_client_with_default_client_info():
    client_info = gapic_v1.client_info.ClientInfo()

    with mock.patch.object(
        transports.RecaptchaEnterpriseServiceTransport, "_prep_wrapped_messages"
    ) as prep:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            client_info=client_info,
        )
        prep.assert_called_once_with(client_info)

    with mock.patch.object(
        transports.RecaptchaEnterpriseServiceTransport, "_prep_wrapped_messages"
    ) as prep:
        transport_class = RecaptchaEnterpriseServiceClient.get_transport_class()
        transport = transport_class(
            credentials=ga_credentials.AnonymousCredentials(),
            client_info=client_info,
        )
        prep.assert_called_once_with(client_info)


def test_transport_close_grpc():
    client = RecaptchaEnterpriseServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport="grpc"
    )
    with mock.patch.object(
        type(getattr(client.transport, "_grpc_channel")), "close"
    ) as close:
        with client:
            close.assert_not_called()
        close.assert_called_once()


@pytest.mark.asyncio
async def test_transport_close_grpc_asyncio():
    client = RecaptchaEnterpriseServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport="grpc_asyncio"
    )
    with mock.patch.object(
        type(getattr(client.transport, "_grpc_channel")), "close"
    ) as close:
        async with client:
            close.assert_not_called()
        close.assert_called_once()


def test_client_ctx():
    transports = [
        "grpc",
    ]
    for transport in transports:
        client = RecaptchaEnterpriseServiceClient(
            credentials=ga_credentials.AnonymousCredentials(), transport=transport
        )
        # Test client calls underlying transport.
        with mock.patch.object(type(client.transport), "close") as close:
            close.assert_not_called()
            with client:
                pass
            close.assert_called()


@pytest.mark.parametrize(
    "client_class,transport_class",
    [
        (
            RecaptchaEnterpriseServiceClient,
            transports.RecaptchaEnterpriseServiceGrpcTransport,
        ),
        (
            RecaptchaEnterpriseServiceAsyncClient,
            transports.RecaptchaEnterpriseServiceGrpcAsyncIOTransport,
        ),
    ],
)
def test_api_key_credentials(client_class, transport_class):
    with mock.patch.object(
        google.auth._default, "get_api_key_credentials", create=True
    ) as get_api_key_credentials:
        mock_cred = mock.Mock()
        get_api_key_credentials.return_value = mock_cred
        options = client_options.ClientOptions()
        options.api_key = "api_key"
        with mock.patch.object(transport_class, "__init__") as patched:
            patched.return_value = None
            client = client_class(client_options=options)
            patched.assert_called_once_with(
                credentials=mock_cred,
                credentials_file=None,
                host=client._DEFAULT_ENDPOINT_TEMPLATE.format(
                    UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE
                ),
                scopes=None,
                client_cert_source_for_mtls=None,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )
