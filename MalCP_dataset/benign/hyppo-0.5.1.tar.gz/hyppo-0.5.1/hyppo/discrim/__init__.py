from .discrim_one_samp import DiscrimOneSample
from .discrim_two_samp import DiscrimTwoSample

__all__ = [s for s in dir()]  # add imported tests to __all__
