============
Installation
============

At the command line::

    $ pip install oslo.concurrency

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv oslo.concurrency
    $ pip install oslo.concurrency