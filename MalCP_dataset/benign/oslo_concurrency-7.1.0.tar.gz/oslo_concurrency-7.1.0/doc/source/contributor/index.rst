=====================
 Contributor's Guide
=====================

.. toctree::
   :maxdepth: 2

   contributing
   history
