# DJANGO1.7 https://docs.djangoproject.com/en/2.0/releases/1.7/#app-loading-refactor
# DELETEME and use an app config
# Empty models.py so django picks the templates
