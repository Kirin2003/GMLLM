=============
API Reference
=============

.. module:: os_service_types
   :synopsis: OpenStack Service Types Data

.. autoclass:: os_service_types.ServiceTypes
  :members:
  :inherited-members:
