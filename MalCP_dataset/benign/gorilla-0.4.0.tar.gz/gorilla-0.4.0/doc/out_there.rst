.. _out_there:

Out There
=========

Projects using Gorilla include:

* `bana <https://github.com/christophercrouzet/bana>`_
* `mlflow <https://github.com/mlflow/mlflow>`_
