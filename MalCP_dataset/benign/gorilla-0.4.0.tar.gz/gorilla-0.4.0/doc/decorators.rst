.. currentmodule:: gorilla

.. _decorators:

Decorators
==========

.. autosummary::
   :nosignatures:

   patch
   patches
   destination
   name
   settings
   filter


----

.. autofunction:: patch

----

.. autofunction:: patches

----

.. autofunction:: destination

----

.. autofunction:: name

----

.. autofunction:: settings

----

.. autofunction:: filter
