from .core import LazySettings, settings  # noqa
