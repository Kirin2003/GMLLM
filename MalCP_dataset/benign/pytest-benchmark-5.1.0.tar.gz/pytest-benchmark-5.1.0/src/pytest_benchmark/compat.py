import sys

PY311 = sys.version_info[0] == 3 and sys.version_info[1] >= 11
