Just test that pytest-benchmark doesn't choke on DoctestItems::

    >>> 1
    1
