Hooks
=====

Hooks for customizing various parts of ``pytest-benchmark``.

-----

.. automodule:: pytest_benchmark.hookspec
    :members:
    :undoc-members:
