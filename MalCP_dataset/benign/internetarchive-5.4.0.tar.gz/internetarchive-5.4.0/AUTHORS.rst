Authors
=======
The Internet Archive Python library and command-line tool is written
and maintained by Jake Johnson and various contributors:

Development Lead
----------------

- Jake Johnson <jake@archive.org>

Contributors
------------

- Bryce Drennan <internetarchive@brycedrennan.com>
- Max Zettlmeißl <max@zettlmeissl.de>
- Ian Tait <thetaiter@gmail.com>

Patches and Suggestions
-----------------------

- VM Brasseur
