class LMFormatEnforcerException(Exception):
    """Base class for exceptions in this module."""
    pass