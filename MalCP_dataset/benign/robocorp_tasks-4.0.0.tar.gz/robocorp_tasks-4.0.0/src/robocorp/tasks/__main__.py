if __name__ == "__main__":
    from robocorp.tasks.cli import main

    main()
