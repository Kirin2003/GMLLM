:mod:`zope.sequencesort` API
============================

.. automodule:: zope.sequencesort.ssort

.. autofunction:: sort

