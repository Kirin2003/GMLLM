.. zope.sequencesort documentation master file, created by

:mod:`zope.sequencesort`
========================

Contents:

.. toctree::
   :maxdepth: 2

   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
