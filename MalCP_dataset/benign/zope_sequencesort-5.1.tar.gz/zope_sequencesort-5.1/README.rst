===================
 zope.sequencesort
===================

.. image:: https://img.shields.io/pypi/v/zope.sequencesort.svg
   :target: https://pypi.org/project/zope.sequencesort/
   :alt: Latest Version

.. image:: https://github.com/zopefoundation/zope.sequencesort/actions/workflows/tests.yml/badge.svg
   :target: https://github.com/zopefoundation/zope.sequencesort/actions/workflows/tests.yml

.. image:: https://readthedocs.org/projects/zopesequencesort/badge/?version=latest
   :target: https://zopesequencesort.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.sequencesort/badge.svg
   :target: https://coveralls.io/github/zopefoundation/zope.sequencesort



This package provides support for sorting sequences based on multiple
keys, including locale-based comparisons and per-key directions.
