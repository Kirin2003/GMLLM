{# Display description #}
{% if description %}
**Description:**{{ " " }}{{ description }}
{% endif %}