"""Loads extension into `pynini` namespace."""

from _pynini import *

# Increment after every release.

__version__ = "2.1.6.post1"
