"""Executable for fundamentals tap.

Run:

$ poetry run python samples/aapl
"""

from aapl import Fundamentals

Fundamentals.cli()
