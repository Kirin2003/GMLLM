Carl Meyer \<<https://github.com/carljm>\>  
Jess Johnson \<<https://github.com/grokcode>\>  
Irtaza Akram \<<https://github.com/irtazaakram>\>  
MichelML \<<https://github.com/michelml>\>
