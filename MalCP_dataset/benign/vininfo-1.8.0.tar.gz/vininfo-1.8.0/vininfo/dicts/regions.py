
REGIONS = {
    'ABC': 'Africa',
    'JKLMNPR': 'Asia',
    'STUVWXYZ': 'Europe',
    '123457': 'North America',
    '6': 'Oceania',
    '89': 'South America',
}
