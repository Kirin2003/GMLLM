
BODY_CABRI_2 = 'Cabriolet, 2-Door'
BODY_COUPE_2 = 'Coupe, 2-Door'
BODY_CROSS_3 = 'Crossover, 3-Door'
BODY_PICKUP_2 = 'Pickup, 2-Door'

BODY_HATCH_3 = 'Hatchback, 3-Door'
BODY_HATCH_5 = 'Hatchback, 5-Door'

BODY_MINIVAN_3 = 'Minivan, 3-Door'
BODY_MINIVAN_5 = 'Minivan, 5-Door'

BODY_SEDAN_4 = 'Sedan, 4-Door'
BODY_SEDAN_2 = 'Sedan, 2-Door'

BODY_SW_3 = 'Station Wagon, 3-Door'
BODY_SW_5 = 'Station Wagon, 5-Door'
BODY_SW_8 = 'Station Wagon, 8-Door'

BODY_MINIBUS = 'Minibus'
BODY_VAN = 'Van'
