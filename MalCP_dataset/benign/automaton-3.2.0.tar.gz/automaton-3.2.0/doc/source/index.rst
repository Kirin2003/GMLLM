=====================================
Welcome to automaton's documentation!
=====================================

Friendly state machines for python.

.. toctree::
   :maxdepth: 2

   user/index
   reference/index
   install/index
   contributor/index

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

