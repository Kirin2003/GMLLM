"""HTTP error package for Evervault SDK"""
