"""HTTP package for Evervault SDK"""
