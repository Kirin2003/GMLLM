"""Package for handling Evervault Encryption Scheme"""
