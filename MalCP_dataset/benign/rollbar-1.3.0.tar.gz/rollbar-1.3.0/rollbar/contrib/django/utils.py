class MiddlewareMixin(object):
    def __init__(self, get_response=None):
        super(MiddlewareMixin, self).__init__()
