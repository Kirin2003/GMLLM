Peppercorn
==========

A library for converting a token stream into a data structure comprised of
sequences, mappings, and scalars, developed primarily for converting HTTP form
post data into a richer data structure.  It runs on Python 2.7, 3.4, 3.5, 3.6
and 3.7.

Please see https://docs.pylonsproject.org/projects/peppercorn/en/latest/
for the documentation.

See https://github.com/Pylons/peppercorn for in-development version.
