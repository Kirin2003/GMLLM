.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   WebOb
     `WebOb <https://webob.org/>`_ is a WSGI request/response library created by Ian Bicking.
