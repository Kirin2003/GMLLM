# Sandbox

Docker Compose setup for end-to-end testing with dbt, Metabase and PostgreSQL as target database.

## Sample dbt project

Started from the official [jaffle_shop](https://github.com/dbt-labs/jaffle_shop) sample with several modifications to test specific dbt-metabase features.
