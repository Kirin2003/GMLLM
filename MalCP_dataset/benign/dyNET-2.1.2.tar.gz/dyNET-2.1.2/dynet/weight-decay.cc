#include "dynet/weight-decay.h"

namespace dynet {}
