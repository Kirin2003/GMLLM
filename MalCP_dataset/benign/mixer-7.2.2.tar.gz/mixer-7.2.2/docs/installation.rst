Installation
============

.. contents::

.. == requirements ==
.. _requirements:
.. include:: ../README.rst
    :start-after: Requirements
    :end-before: Installation


.. == installation ==
.. _installation:
.. include:: ../README.rst
    :start-after: Installation
    :end-before: Usage


.. == links ==
.. _links:
.. include:: ../README.rst
    :start-after: .. _links:
