__all__ = ['search', 'encoder', 'ensemble', 'multiclass', 'eliminate', 'tests', 'predict']
