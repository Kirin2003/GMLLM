"""Global fixtures for testing the plugin"""

pytest_plugins = ["pytester"]
