from .shared import behaves_like

__all__ = ['behaves_like']

__version__ = '2.2.0'
