===
API
===

.. toctree::
    :maxdepth: 1

    api/table
    api/tableset
    api/columns_and_rows
    api/data_types
    api/type_tester
    api/aggregations
    api/computations
    api/csv
    api/fixed
    api/misc
    api/exceptions
    api/warns
    api/testcase
    api/config
