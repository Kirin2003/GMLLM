====================
Unit testing helpers
====================

.. autoclass:: agate.AgateTestCase
    :members: assertColumnNames, assertColumnTypes, assertRows, assertRowNames
