======
Config
======

.. automodule:: agate.config
    :members:
    :inherited-members:
