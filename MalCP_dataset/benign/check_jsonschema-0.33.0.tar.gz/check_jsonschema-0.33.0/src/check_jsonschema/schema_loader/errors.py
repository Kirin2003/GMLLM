class SchemaParseError(ValueError):
    pass


class UnsupportedUrlScheme(ValueError):
    pass
