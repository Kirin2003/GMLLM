# -*- coding: utf-8 -*-

from .extended_declarative_base import ExtendedBase
