# -*- coding: utf-8 -*-

"""
ORM enhancement.
"""
