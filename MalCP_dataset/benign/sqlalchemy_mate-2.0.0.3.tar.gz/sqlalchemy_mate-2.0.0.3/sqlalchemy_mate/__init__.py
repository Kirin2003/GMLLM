# -*- coding: utf-8 -*-

from ._version import __version__

__short_description__ = "A library extend sqlalchemy module, makes CRUD easier."
__license__ = "MIT"
__author__ = "Sanhe Hu"
__author_email__ = "husanhe@gmail.com"
__github_username__ = "MacHu-GWU"
