# -*- coding: utf-8 -*-

from .inserting import smart_insert
