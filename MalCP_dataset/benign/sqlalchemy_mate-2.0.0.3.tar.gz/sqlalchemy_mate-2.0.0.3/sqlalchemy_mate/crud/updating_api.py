# -*- coding: utf-8 -*-

from .updating import update_all
from .updating import upsert_all
