# -*- coding: utf-8 -*-

from .deleting import delete_all
