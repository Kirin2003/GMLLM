
Authors
=======

The following people have contributed to Python-ASN1. Collectively they own the copyright of this software.

* Geert Jansen <geert@boskant.nl>
* Sebastien Andrivet <sebastien@andrivet.com>

