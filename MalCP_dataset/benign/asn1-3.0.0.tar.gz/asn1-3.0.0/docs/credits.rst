Credits
=======

The following projects have provided inspiration for Python-ASN1:

* `pyasn1`_ This is another ASN1 encoder/decoder for Python.
* `Samba`_ In particular **libads** for the stack based approach for
  building constructed types.

.. _pyasn1: https://pyasn1.sourceforge.net/
.. _Samba: https://www.samba.org
