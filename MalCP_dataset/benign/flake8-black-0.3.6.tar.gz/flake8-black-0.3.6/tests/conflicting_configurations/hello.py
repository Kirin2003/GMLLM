#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Print 'Hello world' to the terminal.

This is a simple test script using a hashbang line
and a PEP263 encoding line.
"""

print("Hello world")
