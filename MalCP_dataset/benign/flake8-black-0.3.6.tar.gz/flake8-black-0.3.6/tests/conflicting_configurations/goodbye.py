"""Print 'Au revoir' to the terminal.

This is a simple test script.
"""

print("Au revoir")
