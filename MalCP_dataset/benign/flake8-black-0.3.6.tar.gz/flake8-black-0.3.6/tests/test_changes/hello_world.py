#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Print 'Hello world' to the terminal.

This is a simple test script using a hashbang line and a PEP263 encoding line.

In the original format, there excess spaces in the print call, and unwanted
blank lines - which black will remove.
"""


print ( "Hello world" )

