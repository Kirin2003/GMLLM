name = 'ml_wrappers'
_major = '0'
_minor = '6'
_patch = '0'
version = '{}.{}.{}'.format(_major, _minor, _patch)
