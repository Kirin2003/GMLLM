MYVARIANT_TOP_LEVEL_JSONLD_URIS = [
    "http://schema.myvariant.info/datasource/cadd",
    "http://schema.myvariant.info/datasource/clinvar",
    "http://schema.myvariant.info/datasource/dbnsfp",
    "http://schema.myvariant.info/datasource/dbsnp",
    "http://schema.myvariant.info/datasource/docm",
    "http://schema.myvariant.info/datasource/emv",
    "http://schema.myvariant.info/datasource/evs",
    "http://schema.myvariant.info/datasource/gwassnps",
    "http://schema.myvariant.info/datasource/mutdb",
    "http://schema.myvariant.info/datasource/snpeff",
]
