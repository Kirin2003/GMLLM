click-log
=========

.. image:: https://travis-ci.org/click-contrib/click-log.svg?branch=master
    :target: https://travis-ci.org/click-contrib/click-log

Integrates logging with click.

- `Documentation <https://click-log.readthedocs.org/>`_
- `Source code <https://github.com/click-contrib/click-log>`_

License
=======

Licensed under the MIT, see ``LICENSE``.
