from .register import register_vector

__all__ = [
    'register_vector'
]
