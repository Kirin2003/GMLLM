#!/usr/bin/env python

from liccheck.command_line import main

if __name__ == '__main__':
    main()
