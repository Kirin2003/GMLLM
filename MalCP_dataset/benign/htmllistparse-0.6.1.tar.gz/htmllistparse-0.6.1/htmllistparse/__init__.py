from .htmllistparse import *

__version__ = '0.6'
