Third Party Notices
===================

The New Relic Python Telemetry SDK uses source code from third party
libraries which carry their own copyright notices and license terms.
These notices are provided below.

In the event that a required notice is missing or incorrect, please
notify us by e-mailing open-source@newrelic.com.

`urllib3 <https://pypi.org/project/urllib3>`__
----------------------------------------------

Copyright (c) 2008-2020 Andrey Petrov and contributors (see CONTRIBUTORS.txt)

Distributed under the following license(s):

- `The MIT License <https://opensource.org/licenses/MIT>`_
