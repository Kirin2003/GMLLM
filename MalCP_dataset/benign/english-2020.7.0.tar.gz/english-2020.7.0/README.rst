*******
English
*******

*English* is an English language utility library for Python.
