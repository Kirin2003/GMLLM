from django.apps import AppConfig


class JsonappConfig(AppConfig):
    name = 'django_jsonform'
