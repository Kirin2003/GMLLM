

class TestClass:

    def test_in_class(self):
        pass
