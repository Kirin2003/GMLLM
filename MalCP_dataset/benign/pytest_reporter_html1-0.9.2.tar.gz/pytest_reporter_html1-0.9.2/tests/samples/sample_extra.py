

def test_with_extras():
    """Extras are added in conftest.py."""
    pass
