class UnsupportedValueError(Exception):
    pass
