See [Mandel2009]_ and [Evensen2003]_.

.. bibliography:: refs.bib
