.. automodule:: pybtex_docutils
