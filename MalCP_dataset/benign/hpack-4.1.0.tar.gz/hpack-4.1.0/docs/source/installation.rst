Installing hpack
================

hpack is trivial to install from the Python Package Index. Simply run:

.. code-block:: console

    $ pip install hpack

Alternatively, feel free to download one of the release tarballs from
`our GitHub page`_, extract it to your favourite directory, and then run

.. code-block:: console

    $ python setup.py install

hpack has no external dependencies.
