from .detect import detect

__all__ = ["detect"]
