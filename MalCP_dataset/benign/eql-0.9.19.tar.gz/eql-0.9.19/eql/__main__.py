"""Additional entry point for `python -m eql`."""
from .main import main

main()
