Installation
============

Installing the application
--------------------------

From the command line:

.. code:: bash

    pip install scrapbook

For all optional io dependencies, you can specify individual bundles
like ``s3``, or ``azure`` -- or use ``all``

.. code:: bash

    pip install scrapbook[all]
