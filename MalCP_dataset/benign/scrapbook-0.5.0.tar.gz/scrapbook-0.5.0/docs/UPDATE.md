TODO: Figure out make options needed for non-api changes

```
sphinx-apidoc -f -o reference ../scrapbook
```
