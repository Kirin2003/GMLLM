import logging

logger = logging.getLogger("scrapbook")
