
Deprecated since v4.5.0. This is a proxy for depending on [`databind`](https://pypi.org/project/databind/). Do not
depend on this package directly anymore.
