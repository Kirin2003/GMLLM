API Reference
-------------

.. autoclass:: flask_moment.moment
   :members:
