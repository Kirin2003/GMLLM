.. include:: ../INSTALL.rst

.. include:: ../CHANGELOG.rst