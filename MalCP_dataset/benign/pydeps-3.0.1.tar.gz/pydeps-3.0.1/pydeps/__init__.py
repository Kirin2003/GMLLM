# -*- coding: utf-8 -*-
"""
Python module dependency visualization. This package installs the ``pydeps``
command, and normal usage will be to use it from the command line.
"""
__version__ = "3.0.1"
