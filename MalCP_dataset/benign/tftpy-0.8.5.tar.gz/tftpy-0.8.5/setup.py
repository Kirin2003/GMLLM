# setup.py is deprecated
# https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html
from setuptools import setup

setup()
