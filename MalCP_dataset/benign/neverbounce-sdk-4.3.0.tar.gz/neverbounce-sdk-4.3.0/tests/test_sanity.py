""" This test should never fail; if it does, something is misconfigured in
the build or dev environment"""


def test_sanity_check():
    test_sanity_check.__doc__ = __doc__
    return True
