.. urlextract documentation master file, created by
   sphinx-quickstart on Sat Jul 30 00:09:59 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to urlextract's documentation!
======================================

urlextract is package with python class and command line script used for extraction of URLs from given text.

.. toctree::
   :maxdepth: 3

   urlextract_cmd
   urlextract


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
