URLExtract class
----------------
.. autoclass:: urlextract.URLExtract
    :members:
