urlextract - test code
=========================

How to run the test code:

```
$ tox
```
