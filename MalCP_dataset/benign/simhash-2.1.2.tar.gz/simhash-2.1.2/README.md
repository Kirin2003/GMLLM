simhash
===========

This is a Python implementation of [Simhash](http://static.googleusercontent.com/media/research.google.com/en//pubs/archive/33026.pdf).

## Getting Started

<http://leons.im/posts/a-python-implementation-of-simhash-algorithm/>

## Build Status

![Build Status](https://github.com/1e0ng/simhash/actions/workflows/main.yml/badge.svg?branch=master)
