.. include:: ../src/zope/testing/loggingsupport.txt

