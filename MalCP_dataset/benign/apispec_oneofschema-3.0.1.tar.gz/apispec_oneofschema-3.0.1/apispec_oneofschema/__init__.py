from .plugin import MarshmallowPlugin
