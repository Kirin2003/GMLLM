import logging

logger = logging.getLogger("transformer_smaller_training_vocab")
logger.setLevel(level="INFO")
logger.addHandler(logging.StreamHandler())
