from __future__ import annotations

from typing import Final

BASE_ENCODING: Final = "latin-1"
DEFAULT_CHARSET: Final = "utf-8"
