from __future__ import annotations

from logging import Logger, getLogger
from typing import Final

logger: Final[Logger] = getLogger("asgi-tools")
