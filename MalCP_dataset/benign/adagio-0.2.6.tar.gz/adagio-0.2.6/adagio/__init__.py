# flake8: noqa
from adagio_version import __version__
