"""Module of visualization."""

from ._visualization import plot

__all__ = ["plot"]
