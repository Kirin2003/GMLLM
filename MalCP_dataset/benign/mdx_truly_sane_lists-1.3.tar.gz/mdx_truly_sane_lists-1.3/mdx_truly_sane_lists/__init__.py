from .mdx_truly_sane_lists import makeExtension

assert makeExtension
