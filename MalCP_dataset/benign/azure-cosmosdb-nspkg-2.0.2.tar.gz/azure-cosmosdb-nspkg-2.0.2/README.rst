Microsoft Azure CosmosDB SDK for Python
=======================================

This is the Microsoft Azure CosmosDB namespace package.

This package is not intended to be installed directly by the end user.

It provides the necessary files for other packages to extend the azure.cosmosdb namespace.

If you are looking to install the Azure CosmosDB libraries, see the
`azure <https://pypi.python.org/pypi/azure>`__ bundle package.
