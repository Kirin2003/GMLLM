#!/usr/bin/env python

from .convert_html import convert
from .convert_html_tables import convert_tables

__author__ = """Floyd Hightower"""
__version__ = '2.0.0'
