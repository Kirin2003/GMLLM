import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import lasio

# las = lasio.read('sample.las')
# las.to_csv('sample.las_units-none.csv', units_loc=None)
# las.to_csv('sample.las_units-line.csv', units_loc='line')
# las.to_csv('sample.las_units-parentheses.csv', units_loc='()')
# las.to_csv('sample.las_units-brackets.csv', units_loc='[]')
