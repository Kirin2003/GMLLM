#!/usr/bin/env python
# encoding: utf-8
"""
copyright (c) 2016-2017 Earth Advantage.
All rights reserved
..codeauthor::Paul Munday <paul@paulmunday.net>
"""

# Local Imports
from yamlconf.config import Config
from yamlconf.exceptions import ConfigError
