## 0.7.0.20240218 (2024-02-18)

defusedxml.ElementTree: use`Element` from ElementTree instead of minidom (#11305)

## 0.7.0.20240117 (2024-01-17)

`defusedxml`: Add xml.dom.minidom.Document return type annotation (#11279)

## 0.7.0.20240115 (2024-01-15)

Add types for defusedxml (#11179)

