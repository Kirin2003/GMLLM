from distutils.core import setup

setup(
    name='blob',
    version='0.16',
    packages=['blob', 'blob.pyecm'],
)
