from llama_index.tools.wikipedia.base import WikipediaToolSpec

__all__ = ["WikipediaToolSpec"]
