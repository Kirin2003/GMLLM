Welcome to office365's documentation!
=====================================

.. toctree::
   :caption: Contents:

   modules


API Reference
==================

.. automodule:: office
    :members:
    :noindex:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
