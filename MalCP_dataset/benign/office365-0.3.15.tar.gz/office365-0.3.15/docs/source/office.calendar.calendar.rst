office.calendar.calendar
========================

.. automodule:: office.calendar.calendar
   :members:
   :undoc-members:
   :show-inheritance:
