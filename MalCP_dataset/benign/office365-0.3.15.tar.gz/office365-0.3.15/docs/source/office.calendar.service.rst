office.calendar.service
=======================

.. automodule:: office.calendar.service
   :members:
   :undoc-members:
   :show-inheritance:
