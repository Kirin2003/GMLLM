office.attribute
================

.. automodule:: office.attribute
   :members:
   :undoc-members:
   :show-inheritance:
