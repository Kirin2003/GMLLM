office.people.folder
====================

.. automodule:: office.people.folder
   :members:
   :undoc-members:
   :show-inheritance:
