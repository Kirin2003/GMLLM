office.people
=============

Submodules
----------

.. toctree::

   office.people.contact
   office.people.folder
   office.people.service

Module contents
---------------

.. automodule:: office.people
   :members:
   :undoc-members:
   :show-inheritance:

