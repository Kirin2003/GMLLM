office.people.service
=====================

.. automodule:: office.people.service
   :members:
   :undoc-members:
   :show-inheritance:
