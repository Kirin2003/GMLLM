office.office
=============

.. automodule:: office.office
   :members:
   :undoc-members:
   :show-inheritance:
