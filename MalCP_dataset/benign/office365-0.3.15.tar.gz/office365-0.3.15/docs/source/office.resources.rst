office.resources
================

Submodules
----------

.. toctree::

   office.resources.blob_content_types

Module contents
---------------

.. automodule:: office.resources
   :members:
   :undoc-members:
   :show-inheritance:

