office.blob
===========

.. automodule:: office.blob
   :members:
   :undoc-members:
   :show-inheritance:
