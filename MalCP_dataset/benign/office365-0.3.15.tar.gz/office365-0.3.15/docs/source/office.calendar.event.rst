office.calendar.event
=====================

.. automodule:: office.calendar.event
   :members:
   :undoc-members:
   :show-inheritance:
