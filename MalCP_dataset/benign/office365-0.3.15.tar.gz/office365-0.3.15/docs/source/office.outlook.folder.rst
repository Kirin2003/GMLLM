office.outlook.folder
=====================

.. automodule:: office.outlook.folder
   :members:
   :undoc-members:
   :show-inheritance:
