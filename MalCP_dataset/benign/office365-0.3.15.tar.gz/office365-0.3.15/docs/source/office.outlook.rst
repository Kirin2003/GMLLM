office.outlook
==============

Submodules
----------

.. toctree::

   office.outlook.folder
   office.outlook.message
   office.outlook.service

Module contents
---------------

.. automodule:: office.outlook
   :members:
   :undoc-members:
   :show-inheritance:

