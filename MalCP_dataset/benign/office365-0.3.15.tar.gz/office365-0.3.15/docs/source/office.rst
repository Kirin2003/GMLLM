office
======

Subpackages
-----------

.. toctree::

   office.calendar
   office.outlook
   office.people
   office.resources

Submodules
----------

.. toctree::

   office.attribute
   office.blob
   office.config
   office.fluent
   office.office
   office.query

Module contents
---------------

.. automodule:: office
   :members:
   :undoc-members:
   :show-inheritance:

