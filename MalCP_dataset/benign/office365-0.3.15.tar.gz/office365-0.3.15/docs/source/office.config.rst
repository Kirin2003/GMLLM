office.config
=============

.. automodule:: office.config
   :members:
   :undoc-members:
   :show-inheritance:
