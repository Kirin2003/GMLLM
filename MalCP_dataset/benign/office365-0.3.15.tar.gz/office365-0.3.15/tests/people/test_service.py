# import pytest


class TestPeopleService:
    def test_contacts(self):  # synced
        assert True

    def test_personal(self):  # synced
        assert True

    def test_active_directory(self):  # synced
        assert True


class TestContactNameSpace:
    pass
