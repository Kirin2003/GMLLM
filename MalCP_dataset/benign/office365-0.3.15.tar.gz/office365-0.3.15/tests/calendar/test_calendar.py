# import pytest


class TestCalendar:
    def test_events(self):  # synced
        assert True

    def test_event(self):  # synced
        assert True

    def test_new_event(self):  # synced
        assert True
