# import pytest


class TestConfig:
    def test_add_office_connection(self):  # synced
        assert True

    def test_set_default_office_connection(self):  # synced
        assert True

    def test_add_blob_connection(self):  # synced
        assert True

    def test_set_default_blob_connection(self):  # synced
        assert True
