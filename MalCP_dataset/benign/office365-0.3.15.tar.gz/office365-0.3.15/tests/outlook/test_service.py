# import pytest


class TestOutlookService:
    def test___getitem__(self):  # synced
        assert True

    def test_message(self):  # synced
        assert True

    def test_signature(self):  # synced
        assert True

    def test_main(self):  # synced
        assert True

    def test_inbox(self):  # synced
        assert True

    def test_outbox(self):  # synced
        assert True

    def test_sent(self):  # synced
        assert True

    def test_drafts(self):  # synced
        assert True

    def test_junk(self):  # synced
        assert True

    def test_deleted(self):  # synced
        assert True

    def test_custom(self):  # synced
        assert True


class TestMailbox:
    pass
