# import pytest


class TestMessageFolder:
    def test_folders(self):  # synced
        assert True

    def test_messages(self):  # synced
        assert True

    def test_order_messages_by_date():  # synced
        assert True

    class TestAttributes:
        class TestChildFolderCount:
            pass

        class TestTotalItemCount:
            pass

        class TestUnreadItemCount:
            pass

        class TestName:
            pass

        class TestChildFolders:
            pass

        class TestMessages:
            pass


class TestBulkMessageFolderAction:
    def test_move(self):  # synced
        assert True

    def test_delete(self):  # synced
        assert True

    def test_copy(self):  # synced
        assert True


class TestMessageFolderQuery:
    def test___getitem__(self):  # synced
        assert True

    def test_execute(self):  # synced
        assert True

    def test_bulk(self):  # synced
        assert True
