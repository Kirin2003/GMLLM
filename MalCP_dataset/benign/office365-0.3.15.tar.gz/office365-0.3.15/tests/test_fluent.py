# import pytest


class TestFluentEntity:
    def test_subject(self):  # synced
        assert True

    def test_body(self):  # synced
        assert True

    def test_attach(self):  # synced
        assert True

    def test_sign(self):  # synced
        assert True

    def test_importance(self):  # synced
        assert True

    def test_categories(self):  # synced
        assert True

    def test__parse_contacts_to_emails(self):  # synced
        assert True
