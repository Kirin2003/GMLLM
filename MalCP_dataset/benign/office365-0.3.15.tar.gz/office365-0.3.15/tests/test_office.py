# import pytest


class TestOffice:
    def test_request_token(self):  # synced
        assert True

    def test__establish_services(self):  # synced
        assert True


class TestAccount:
    pass
