colcon-library-path
===================

An extension for `colcon-core <https://github.com/colcon/colcon-core>`_ to set an environment variable to find shared libraries at runtime.
