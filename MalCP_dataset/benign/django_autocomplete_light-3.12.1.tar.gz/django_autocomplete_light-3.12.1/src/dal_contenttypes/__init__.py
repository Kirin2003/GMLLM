"""django.contrib.contenttypes support utilities."""
