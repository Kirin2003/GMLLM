default_app_config = 'select2_one_to_one.apps.TestApp'
