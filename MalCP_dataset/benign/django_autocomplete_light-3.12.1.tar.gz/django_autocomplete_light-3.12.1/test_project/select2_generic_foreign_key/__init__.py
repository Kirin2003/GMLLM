default_app_config = 'select2_generic_foreign_key.apps.TestApp'
