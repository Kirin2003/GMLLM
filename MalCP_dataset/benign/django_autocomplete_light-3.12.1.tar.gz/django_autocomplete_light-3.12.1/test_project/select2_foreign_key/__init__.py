default_app_config = 'select2_foreign_key.apps.TestApp'
