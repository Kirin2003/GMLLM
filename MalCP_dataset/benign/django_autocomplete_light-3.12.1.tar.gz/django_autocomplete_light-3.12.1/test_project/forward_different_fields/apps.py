from django.apps import AppConfig


class ForwardDifferentFieldsConfig(AppConfig):
    name = 'forward_different_fields'
