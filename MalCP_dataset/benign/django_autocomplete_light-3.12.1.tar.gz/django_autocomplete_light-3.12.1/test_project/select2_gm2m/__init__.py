default_app_config = 'select2_gm2m.apps.TestApp'
