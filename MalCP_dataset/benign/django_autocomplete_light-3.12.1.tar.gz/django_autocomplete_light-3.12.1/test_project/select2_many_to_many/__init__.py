default_app_config = 'select2_many_to_many.apps.TestApp'
