default_app_config = 'select2_nestedadmin.apps.TestApp'
