from django.apps import AppConfig


class TestApp(AppConfig):
    name = 'select2_nestedadmin'
