default_app_config = 'custom_select2.apps.TestApp'
