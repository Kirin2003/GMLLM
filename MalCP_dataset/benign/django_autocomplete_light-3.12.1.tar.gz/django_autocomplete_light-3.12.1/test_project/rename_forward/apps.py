from django.apps import AppConfig


class TestApp(AppConfig):
    name = 'rename_forward'
