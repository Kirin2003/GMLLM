default_app_config = 'linked_data.apps.TestApp'
