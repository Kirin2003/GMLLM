==============
Vendor Support
==============

Please see
https://docs.openstack.org/openstacksdk/latest/user/config/vendor-support.html
