=============
Release Notes
=============

Release notes for `os-client-config` can be found at
https://docs.openstack.org/releasenotes/os-client-config/
