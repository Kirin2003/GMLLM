from setuptools import setup

# See pyproject.toml for projectmetadata
setup(name="country_converter")
