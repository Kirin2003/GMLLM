poetry-semver
=============

This is a carbon-copy of the original, and now archived, poetry-semver
package originally located at https://github.com/python-poetry/semver

It functionality is still needed, so a drag and drop here was done to ensure
portability.
