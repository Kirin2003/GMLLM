"""
This package contains benchmarking code.
The following content is automatically generated from `bench.gen`

.. include:: ../bench.md
"""
