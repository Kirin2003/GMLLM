#ifndef _RYML_STD_HPP_
#define _RYML_STD_HPP_

#include "./c4/yml/std/std.hpp"

#endif /* _RYML_STD_HPP_ */
