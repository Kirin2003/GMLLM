#include "c4/test.hpp"

namespace c4 {

size_t TestErrorOccurs::num_errors = 0;

} // namespace c4
