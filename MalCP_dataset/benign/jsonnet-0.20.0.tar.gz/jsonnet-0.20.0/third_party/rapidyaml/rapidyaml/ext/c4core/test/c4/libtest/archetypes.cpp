#include "c4/libtest/archetypes.hpp"

namespace c4 {
namespace archetypes {

int IdOwner::s_current = 0;

} // namespace archetypes
} // namespace c4
