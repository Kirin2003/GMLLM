# kubernetes-stubs

[![PyPI](https://img.shields.io/pypi/v/kubernetes-stubs)](https://pypi.org/project/kubernetes-stubs/)

Python type stubs for the [Kubernetes API client](https://github.com/kubernetes-client/python).
The version numbers of this package track upstream's. PRs to fix bugs are
welcomed.

## Usage

```
pip install kubernetes-stubs
```
