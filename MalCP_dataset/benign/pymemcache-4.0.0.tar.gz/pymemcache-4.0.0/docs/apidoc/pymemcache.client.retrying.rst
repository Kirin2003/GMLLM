pymemcache.client.retrying module
=================================

.. automodule:: pymemcache.client.retrying
   :members:
   :undoc-members:
   :show-inheritance:
