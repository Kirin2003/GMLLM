pymemcache.test.test\_client\_retry module
==========================================

.. automodule:: pymemcache.test.test_client_retry
   :members:
   :undoc-members:
   :show-inheritance:
