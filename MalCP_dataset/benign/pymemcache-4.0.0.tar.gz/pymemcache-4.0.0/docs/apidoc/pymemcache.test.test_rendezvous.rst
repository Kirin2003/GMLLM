pymemcache.test.test\_rendezvous module
=======================================

.. automodule:: pymemcache.test.test_rendezvous
   :members:
   :undoc-members:
   :show-inheritance:
