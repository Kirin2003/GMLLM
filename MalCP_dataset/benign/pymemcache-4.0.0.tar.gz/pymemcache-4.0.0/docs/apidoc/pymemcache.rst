pymemcache package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pymemcache.client

Submodules
----------

.. toctree::
   :maxdepth: 4

   pymemcache.exceptions
   pymemcache.fallback
   pymemcache.pool
   pymemcache.serde

Module contents
---------------

.. automodule:: pymemcache
   :members:
   :undoc-members:
   :show-inheritance:
