pymemcache.fallback module
==========================

.. automodule:: pymemcache.fallback
   :members:
   :undoc-members:
   :show-inheritance:
