pymemcache.test.test\_client module
===================================

.. automodule:: pymemcache.test.test_client
   :members:
   :undoc-members:
   :show-inheritance:
