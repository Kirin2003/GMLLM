pymemcache.serde module
=======================

.. automodule:: pymemcache.serde
   :members:
   :undoc-members:
   :show-inheritance:
