.. pymemcache documentation master file, created by
   sphinx-quickstart on Wed Aug  3 11:15:43 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pymemcache's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 1

    Getting Started </getting_started>
    Source Code </apidoc/modules>
    ChangeLog </changelog>



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

