"""Reader writer locks."""

__all__ = ["rwlock"]
