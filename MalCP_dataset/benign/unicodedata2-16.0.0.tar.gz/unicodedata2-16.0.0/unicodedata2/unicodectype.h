#ifndef __UNICODECTYPE_H__
#define __UNICODECTYPE_H__

int _PyUnicode2_ToDecimalDigit(Py_UCS4 ch);
int _PyUnicode2_ToDigit(Py_UCS4 ch);
double _PyUnicode2_ToNumeric(Py_UCS4 ch);

#endif
