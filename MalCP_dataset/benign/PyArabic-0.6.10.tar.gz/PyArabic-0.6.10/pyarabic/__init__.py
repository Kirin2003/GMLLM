# PyArabic -- Regression testing
#
# Copyright (C) 2010 Taha Zerrouki
# Author: Taha Zerrouki <taha zerrouki at gawab dot com>
# URL: <http://pyarabic.sf.net>
#
# $Id: __init__.py :

"""
Main.
"""
__docformat__ = 'epytext en'

