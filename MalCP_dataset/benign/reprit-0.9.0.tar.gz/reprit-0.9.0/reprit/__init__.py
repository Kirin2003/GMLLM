"""Auto __repr__ method generation."""

__version__ = '0.9.0'
