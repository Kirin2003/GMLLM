# xdg

`xdg` has been renamed to `xdg-base-dirs` due to an import collision with
[`PyXDG`](https://pypi.org/project/pyxdg/). Therefore the
[`xdg`](https://pypi.org/project/xdg/) package is deprecated. Install
[`xdg-base-dirs`](https://pypi.org/project/xdg-base-dirs/) instead.
