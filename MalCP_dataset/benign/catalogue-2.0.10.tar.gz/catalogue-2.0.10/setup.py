#!/usr/bin/env python

if __name__ == "__main__":
    from setuptools import setup, find_packages

    setup(name="catalogue", packages=find_packages())
