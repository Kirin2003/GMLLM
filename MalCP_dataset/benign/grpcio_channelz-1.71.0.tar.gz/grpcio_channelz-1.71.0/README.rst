gRPC Python Channelz package
==============================

Channelz is a live debug tool in gRPC Python.


Dependencies
------------

Depends on the `grpcio` package, available from PyPI via `pip install grpcio`.
