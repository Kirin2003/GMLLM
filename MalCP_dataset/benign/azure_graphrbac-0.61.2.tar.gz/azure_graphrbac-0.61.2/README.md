# Microsoft Azure SDK for Python

This package has been deprecated and will no longer be maintained after 10-31-2024. This package will only receive security fixes until 10-31-2024. Refer to the samples in the [MS Graph SDK for Python repo](https://github.com/microsoftgraph/msgraph-sdk-python) instead.

For additional support, open a new issue in the [Issues](https://github.com/microsoftgraph/msgraph-sdk-python/issues) section of the MS Graph SDK for Python repo.
