# -*- coding: utf_8 -*-
"""Exceptions njsscan."""


# define Python user-defined exceptions
class YamlParseError(Exception):
    """Base class for other exceptions."""

    pass
