def help():
    print("Coming soon to pypi.  Visit 'https://acroname.com/software/brainstem-development-kit' to obtain a complete .whl")