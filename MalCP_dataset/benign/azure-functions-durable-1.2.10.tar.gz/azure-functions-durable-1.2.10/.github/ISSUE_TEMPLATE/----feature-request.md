---
name: "\U0001F4A1  Feature request"
about: Suggest an idea for this project!
title: ''
labels: ''
assignees: ''

---

💡 **Feature description**
> What would you like to see, and why?
> What kinds of usage do you expect to see in this feature?

💭 **Describe alternatives you've considered**
> What are other ways to achieve this? Have you thought of alternative designs or solutions?
> Any existing workarounds? Why are they not sufficient? We'd like to know!

**Additional context**
> Add any other context or screenshots about the feature request here.
