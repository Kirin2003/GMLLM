..
  SPDX-FileCopyrightText: 2017 Free Software Foundation Europe e.V. <https://fsfe.org>
  SPDX-FileCopyrightText: 2017 Sebastian Schuberth <schuberth@fsfe.org>

  SPDX-License-Identifier: CC-BY-SA-4.0

=======
Credits
=======

Development Lead
----------------

- Carmen Bianca Bakker <carmenbianca@fsfe.org>

Contributors
------------

- Linus Sehn <linus@fsfe.org>
- Max Mehl <max.mehl@fsfe.org>
- Nico Rikken <nico.rikken@fsfe.org>
- Florian Snow <florian@familysnow.net>
- Sebastian Schuberth <schuberth@fsfe.org>
- Samuel Gaist <samuel.gaist@idiap.ch>
- Diego Elio Pettenò <flameeyes@flameeyes.com>
- Matija Šuklje <matija@suklje.name>
- gallegonovato <fran-carro@hotmail.es>
- Ihor Hordiichuk <igor_ck@outlook.com>
- Liam Beguin <liambeguin@gmail.com>
- J. Lavoie <j.lavoie@net-c.ca>
- Anthony Loiseau <anthony.loiseau@allcircuits.com>
- André Ockers <ao@fsfe.org>
- OliBug <act-zebug@riseup.net>
- Vincent Lequertier <vincent@fsfe.org>
- pd <euklade@gmail.com>
- Thomas Doczkal <doczkal@fsfe.org>
- Tirifto <tirifto@posteo.cz>
- Luca Bonissi <lucabon@fsfe.org>
- José Vieira <jvieira33@sapo.pt>
- flow <adolflow@sindominio.net>
- Roberto Bauglir <bauglir@fsfe.org>
- John Mulligan <jmulligan@redhat.com>
- Kevin Broch <kbroch@rivosinc.com>
- Benoit Rolandeau <benoit.rolandeau@allcircuits.com>
- David Alfonso <developer@davidalfonso.es>
- Pietro Albini <pietro.albini@ferrous-systems.com>
- Shun Sakai <sorairolake@protonmail.ch>
- Jiří Podhorecký <j.podhorecky@volny.cz>
- Korrat <korrat@protonmail.com>
- Paul Spooren <mail@aparcar.org>
- Tuomas Siipola <tuomas@zpl.fi>
- Wesley Schwengle <wesleys@opperschaap.net>
- Chris Wesseling <chris.wesseling@cwi.nl>
- Ethan Kerrick <kerrickethan@gmail.com>
- Friedrich von Never <friedrich@fornever.me>
- Gri-ffin <gameshunter359@gmail.com>
- Matthias Riße <m.risse@fz-juelich.de>
- Michael Weimann <mail@michael-weimann.eu>
- Roberto Redradix <roberto@redradix.com>
- Robin Vobruba <hoijui.quaero@gmail.com>
- Stefan Hynek <stefan.hynek@uni-goettingen.de>
- sudorook <daemon@nullcodon.com>
- Adam Spiers <reuse-tool@adamspiers.org>
- Ajinkya Patil <ajinkyarangnathpatil@gmail.com>
- FeRD (Frank Dana) <ferdnyc@gmail.com>
- Greg Kroah-Hartman <gregkh@linuxfoundation.org>
- Hugo Osvaldo Barrera <hugo@whynothugo.nl>
- Jakelyst <86010593+Jakelyst@users.noreply.github.com>
- Jiri Vlasak <jiri.hubacek@gmail.com>
- Johannes Zarl-Zierl <johannes@zarl-zierl.at>
- Keith Maxwell <keith.maxwell@gmail.com>
- Kirill Elagin <kirelagin@gmail.com>
- Kristoffer Grundström <swedishsailfishosuser@tutanota.com>
- Manlio Perillo <manlio.perillo@gmail.com>
- Mauro Aranda <maurooaranda@gmail.com>
- Maxim Cournoyer <maxim.cournoyer@gmail.com>
- Mikko Piuhola <mikkopiu@users.noreply.github.com>
- Raniere Silva <Raniere.CostadaSilva@gesis.org>
- Robert Cohn <rscohn2@gmail.com>
- Simon Schliesky <p-github@schliesky.com>
- Stefan Bakker <s.bakker777@gmail.com>
- T. E. Kalayci <tekrei@member.fsf.org>
- Thomas Bach <thomas.bach@email.de>
- Walter Paulo <polo@tictips.net>
- Wolfgang Traylor <wolfgang.traylor@senckenberg.de>
- Xinglu Chen <public@yoctocell.xyz>
- ethulhu <ethel@ethulhu.co.uk>
- gfbdrgng <hnaofegnp@hldrive.com>
- mdolling <mdolling@gfz-potsdam.de>
- psykose <alice@ayaya.dev>
- Adrián Chaves <adrian@chaves.io>
- Alvar Penning <post@0x21.biz>
- Aminda Suomalainen <suomalainen+git@mikaela.info>
- Andrey Bienkowski <hexagon-recursion@posteo.net>
- Arnout Engelen <arnout@bzzt.net>
- Basil Peace <grv87@yandex.ru>
- Benedikt Fein <fein@fim.uni-passau.de>
- BigBlueHat <byoung@bigbluehat.com>
- David Kleuker <davidak@users.noreply.github.com>
- David Marzal <2069735+Marzal@users.noreply.github.com>
- Dimitris Apostolou <dimitris.apostolou@icloud.com>
- Dirk Brömmel <dbroemmel@users.noreply.github.com>
- Dmitry Bogatov <KAction@disroot.org>
- FestplattenSchnitzel <festplatte.schnitzel@posteo.de>
- George Rawlinson <george@rawlinson.net.nz>
- Gert van Dijk <github@gertvandijk.nl>
- Gerwin Klein <gerwin.klein@data61.csiro.au>
- Hanspeter Portner <dev@open-music-kontrollers.ch>
- Hotripak <hotr1pak@gmail.com>
- Jan Staněk <jstanek@redhat.com>
- Jason Yundt <swagfortress@gmail.com>
- Johannes Keyser <joke@fsfe.org>
- Jon Burdo <jon@jonburdo.com>
- Josef Andersson <josef.andersson@gmail.com>
- Kerry McAdams <github@klmcadams>
- Kevin Meagher <11620178+kjmeagher@users.noreply.github.com>
- Lars Francke <lars.francke@stackable.de>
- Libor Pechacek <lpechacek@gmx.com>
- Léo de Souza <dev@leodesouza.net>
- Marius Brehler <marius.brehler@iml.fraunhofer.de>
- Mark A. Tsuchida <marktsuchida@gmail.com>
- Markus Vieth <vieth@uni-mainz.de>
- Mathias Dannesbo <45558062+md-magenta@users.noreply.github.com>
- Miro Hrončok <miro@hroncok.cz>
- Monaco <monaco@usp.br>
- Nicolás Alvarez <nicolas.alvarez@gmail.com>
- Nir Soffer <nsoffer@redhat.com>
- Olaf Meeuwissen <paddy-hack@member.fsf.org>
- Pep <socialkuma@hotmail.com>
- Philipp Zabel <philipp.zabel@gmail.com>
- Romain Tartière <romain@blogreen.org>
- Ryan Schmidt <git@ryandesign.com>
- Sebastian Crane <seabass@fsfe.org>
- Sebastien Morais <github@SMoraisAnsys>
- Vishesh Handa <me@vhanda.in>
- Vlad-Stefan Harbuz <vlad@vladh.net>
- Yaman Qalieh <ybq987@gmail.com>
- criadoperez <alejandro@criadoperez.com>
- nautilusx <translate@disroot.org>
- pukkamustard <pukkamustard@users.noreply.github.com>
- rajivsunar07 <56905029+rajivsunar07@users.noreply.github.com>
- Сергій <sergiy.goncharuk.1@gmail.com>
- Mersho <code.rezaei@gmail.com>
- Skyler Grey <sky@a.starrysky.fyi>
- Emil Velikov <emil.l.velikov@gmail.com>
- Linnea Gräf <nea@nea.moe>
