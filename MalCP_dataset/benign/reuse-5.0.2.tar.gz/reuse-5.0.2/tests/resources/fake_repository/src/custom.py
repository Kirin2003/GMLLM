# SPDX-FileCopyrightText: 2017 Jane Doe
#
# SPDX-License-Identifier: LicenseRef-custom
