azure.schemaregistry.encoder.avroencoder package
================================================

.. automodule:: azure.schemaregistry.encoder.avroencoder
   :members:
   :undoc-members:
   :inherited-members:
   :special-members: __message_content__

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   azure.schemaregistry.encoder.avroencoder.aio
