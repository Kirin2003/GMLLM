azure.schemaregistry.encoder.avroencoder.aio package
====================================================

.. automodule:: azure.schemaregistry.encoder.avroencoder.aio
   :members:
   :undoc-members:
   :inherited-members:
