azure package
=============

.. automodule:: azure
   :members:
   :undoc-members:
   :inherited-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   azure.schemaregistry
