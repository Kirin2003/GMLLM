azure.schemaregistry.encoder package
====================================

.. automodule:: azure.schemaregistry.encoder
   :members:
   :undoc-members:
   :inherited-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   azure.schemaregistry.encoder.avroencoder
