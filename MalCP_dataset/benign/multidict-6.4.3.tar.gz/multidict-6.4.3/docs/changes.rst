.. _multidict_changes:

=========
Changelog
=========

.. only:: not is_release

   To be included in v\ |release| (if present)
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

   .. towncrier-draft-entries:: |release| [UNRELEASED DRAFT]

   Released versions
   ^^^^^^^^^^^^^^^^^

.. include:: ../CHANGES.rst
   :start-after: .. towncrier release notes start

.. include:: ../HISTORY.rst
