from .instrumentation import PrometheusFastApiInstrumentator

__version__ = "7.1.0"

Instrumentator = PrometheusFastApiInstrumentator
