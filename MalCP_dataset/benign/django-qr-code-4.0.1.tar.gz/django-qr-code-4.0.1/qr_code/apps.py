from django.apps import AppConfig


class QrCodeConfig(AppConfig):
    name = "qr_code"
    verbose_name = "Django QR Code"
