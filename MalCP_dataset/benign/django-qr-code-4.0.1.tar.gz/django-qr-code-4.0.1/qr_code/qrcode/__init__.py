from pydantic import ConfigDict

PYDANTIC_CONFIG = ConfigDict(arbitrary_types_allowed=True)
