import sys

from .cli import main

sys.exit(main(prog_name=__package__))
