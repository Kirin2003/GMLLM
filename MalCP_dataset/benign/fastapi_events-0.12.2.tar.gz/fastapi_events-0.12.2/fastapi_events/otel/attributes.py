class SpanAttributes:
    HANDLER = "fastapi_events.handler"
