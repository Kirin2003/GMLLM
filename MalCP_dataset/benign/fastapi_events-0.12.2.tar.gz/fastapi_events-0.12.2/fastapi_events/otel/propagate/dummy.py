def extract(*args, **kwargs):
    """
    A dummy version of `opentelemetry.propagate.extract`
    """
    pass


def inject(*args, **kwargs):
    """
    A dummy version of `opentelemetry.propagate.inject`
    """
    pass
