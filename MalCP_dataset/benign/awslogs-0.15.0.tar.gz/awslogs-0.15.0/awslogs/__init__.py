from ._version import __version__  # noqa
from .core import AWSLogs  # noqa
