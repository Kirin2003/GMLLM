from pathlib import Path

STARTER_PROJECT_PATH = Path(__file__).joinpath("..").resolve()
