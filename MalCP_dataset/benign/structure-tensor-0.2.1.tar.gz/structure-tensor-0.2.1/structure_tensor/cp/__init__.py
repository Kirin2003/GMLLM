from .st3dcp import eig_special_3d, structure_tensor_3d
