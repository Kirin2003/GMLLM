========
Usage
========

To use the macaroon bakery Python library for handling macaroon higher level function::

    import macaroonbakery
