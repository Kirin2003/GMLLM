from distutils.core import setup

setup(
    name="dummyproject",
    version="1.0",
    py_modules=["dummyproject"],
)
