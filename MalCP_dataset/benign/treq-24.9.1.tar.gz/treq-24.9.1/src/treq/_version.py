"""
Provides treq version information.
"""

# This file is auto-generated! Do not edit!
# Use `incremental` to change this file.

from incremental import Version

__version__ = Version("treq", 24, 9, 1)
__all__ = ["__version__"]
