# Security Policy

treq is covered by the [Twisted project security policy](https://github.com/twisted/twisted/security/policy).

You can [privately report via GitHub](https://github.com/twisted/treq/security/advisories/new), or via email as described in the policy linked above.
