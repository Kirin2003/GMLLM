matrix
======

.. testsetup::

    from matrix import *

.. automodule:: matrix
    :members:
