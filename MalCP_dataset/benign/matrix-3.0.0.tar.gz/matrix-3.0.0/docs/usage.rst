=====
Usage
=====

To use matrix in a project::

	import matrix
