"""A set of dependencies' exceptions."""
from _dependencies.exceptions import DependencyError


__all__ = ("DependencyError",)
