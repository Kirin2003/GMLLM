Do not use this package. Use https://github.com/hynek/svcs package instead.
