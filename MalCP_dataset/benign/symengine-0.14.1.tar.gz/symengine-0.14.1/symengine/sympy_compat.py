import warnings
warnings.warn("sympy_compat module is deprecated. Use `import symengine` instead", DeprecationWarning,
              stacklevel=2)
from symengine import *
