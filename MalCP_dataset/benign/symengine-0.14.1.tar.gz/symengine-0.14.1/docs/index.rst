.. symengine documentation master file, created by
   sphinx-quickstart on Tue Jan 26 09:42:30 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Symengine Python API Documentation
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   source/modules

.. mdinclude:: ../README.md

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
