def test_view(request, template=None):
    return template
