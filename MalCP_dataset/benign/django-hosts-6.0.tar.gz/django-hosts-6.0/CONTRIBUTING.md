[![Jazzband](https://jazzband.co/static/img/jazzband.png)](https://jazzband.co/)

This is a [Jazzband](https://jazzband.co/) project. By contributing you agree to abide by the [Contributor Code of Conduct](https://jazzband.co/docs/conduct) and follow the [guidelines](https://jazzband.co/docs/guidelines).

## Building the documentation

To build the docs please run the following command in the root directory of
your repository clone:

```
make docs
```

To clean the documentation build dir and the temporary virtualenv that is
created in `/tmp` run:

```
make clean
```
