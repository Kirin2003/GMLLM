=================
 Using oslo.i18n
=================

.. toctree::
   :maxdepth: 2

   usage
   guidelines
   history

