.. include:: ../../NEWS.rst
