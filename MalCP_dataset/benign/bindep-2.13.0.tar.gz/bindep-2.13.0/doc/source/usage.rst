=====
Usage
=====

Calling ``bindep --help`` outputs command-line usage information for
the utility:

.. program-output:: bindep --help
   :nostderr:
