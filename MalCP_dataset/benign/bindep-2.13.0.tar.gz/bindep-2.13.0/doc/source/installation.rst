============
Installation
============

At the command line::

    $ pip install bindep

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv bindep
    $ pip install bindep
