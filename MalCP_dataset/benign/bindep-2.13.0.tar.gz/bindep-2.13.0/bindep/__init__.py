import pbr.version

_version = pbr.version.VersionInfo('bindep')
version = _version.release_string()
