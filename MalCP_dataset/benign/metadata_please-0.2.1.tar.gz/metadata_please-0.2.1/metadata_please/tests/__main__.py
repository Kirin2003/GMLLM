import unittest

if __name__ == "__main__":
    unittest.main(module="metadata_please.tests", verbosity=2)
