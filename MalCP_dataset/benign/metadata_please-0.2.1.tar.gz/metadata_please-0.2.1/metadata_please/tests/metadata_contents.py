METADATA_CONTENTS = b"""\
Requires-Dist: foo
Version: 1.2.58
Summary: Some Summary
Home-page: http://example.com
Author: Chicken
Author-email: duck@example.com
Keywords: farm,animals
Requires-Python: >=3.6
Description-Content-Type: text/markdown

# Foo

A very important package.
"""
