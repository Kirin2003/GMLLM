# langchain-huggingface

This package contains the LangChain integrations for huggingface related classes.

## Installation and Setup

- Install the LangChain partner package
```bash
pip install langchain-huggingface
```
