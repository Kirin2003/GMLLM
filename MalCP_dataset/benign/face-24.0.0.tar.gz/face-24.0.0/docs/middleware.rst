Middleware
==========

*Coming soon!*

* Dependency injection (like pytest!)
* autodoc
  * inventory of all production-grade middlewares
