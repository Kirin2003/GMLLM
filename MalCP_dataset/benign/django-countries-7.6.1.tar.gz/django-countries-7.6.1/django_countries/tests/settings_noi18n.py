from .settings import *  # noqa

USE_I18N = False
