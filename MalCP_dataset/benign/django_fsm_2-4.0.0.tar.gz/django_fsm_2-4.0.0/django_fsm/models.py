"""
Empty file to mark package as valid django application.
"""
