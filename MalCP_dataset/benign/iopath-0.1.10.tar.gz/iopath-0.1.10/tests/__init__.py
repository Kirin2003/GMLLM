# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.

import logging


# Disable stdout logger messages when running unit tests.
logging.disable(logging.CRITICAL)
