API documentation
=================

The following API documentation was automatically generated from the source
code of `property-manager` |release|:

.. contents::
   :local:

:mod:`property_manager`
-----------------------

.. automodule:: property_manager
   :members:


:mod:`property_manager.sphinx`
------------------------------

.. automodule:: property_manager.sphinx
   :members:
