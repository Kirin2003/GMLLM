=======
History
=======

1.0 (2020-01-06)
------------------

* First release on PyPI.


2.1 (2021-10-16)
------------------

* Second release on PyPI.
