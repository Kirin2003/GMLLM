#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author: rjayapalan
Created: March 11, 2022
"""

class DirectoryNotEmptyError(Exception):
    pass

class ZeroFillOutOfRange(Exception):
    pass
