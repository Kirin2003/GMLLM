""" "Sphinx extension to show data in an interactive list view."""

from sphinx_data_viewer.sphinx_data_viewer import setup  # NOQA

__version__ = "0.1.5"
