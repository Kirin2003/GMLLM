from .vokativ import vokativ, sex

__version__ = '1.2.1'
