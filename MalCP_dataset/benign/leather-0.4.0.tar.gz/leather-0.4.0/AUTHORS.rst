The following individuals have contributed code, documentation, or expertise to leather:

* `Christopher Groskopf <https://github.com/onyxfish/>`_
* `Peter M. Landwehr <https://github.com/pmlandwehr>`_
* `Ghislain Vaillant <https://github.com/ghisvail>`_
* `Todd <https://github.com/toddrme2178>`_
* `Loïc Corbasson <https://github.com/lcorbasson>`_
* `Brian <https://github.com/brian-from-quantrocket>`_
* `James McKinney <https://github.com/jpmckinney>`_
* `Tim Gates <https://github.com/timgates42>`_
* `Mathias <https://github.com/Math-ias>`_
