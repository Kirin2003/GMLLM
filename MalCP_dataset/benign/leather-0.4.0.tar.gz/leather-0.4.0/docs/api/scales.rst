======
Scales
======

.. automodule:: leather.scales
    :no-members:

.. autoclass:: leather.Scale

.. autoclass:: leather.Linear

.. autoclass:: leather.Ordinal

.. autoclass:: leather.Temporal
