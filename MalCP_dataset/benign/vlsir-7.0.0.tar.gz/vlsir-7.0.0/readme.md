
# Vlsir 

Bindings to the [Vlsir](https://github.com/Vlsir/Vlsir) data-schemas for chip design. 
