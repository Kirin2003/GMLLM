from llama_index.readers.file.flat.base import FlatReader

__all__ = ["FlatReader"]
