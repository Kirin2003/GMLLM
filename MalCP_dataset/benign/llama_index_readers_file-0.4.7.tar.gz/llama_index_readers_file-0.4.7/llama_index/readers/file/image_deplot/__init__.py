from llama_index.readers.file.image_deplot.base import (
    ImageTabularChartReader,
)

__all__ = ["ImageTabularChartReader"]
