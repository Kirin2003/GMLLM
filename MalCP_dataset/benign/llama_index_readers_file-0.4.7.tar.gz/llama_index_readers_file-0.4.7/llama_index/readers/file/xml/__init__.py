"""Init file."""

from llama_index.readers.file.xml.base import (
    XMLReader,
)

__all__ = ["XMLReader"]
