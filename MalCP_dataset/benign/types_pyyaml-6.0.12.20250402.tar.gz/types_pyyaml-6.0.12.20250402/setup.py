
from setuptools import setup

setup(package_data={'yaml-stubs': ['METADATA.toml']})
