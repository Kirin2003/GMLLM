Django-JSONEditor
===================

Django-JSONEditor is an online structured JSON input widget for Django appropriate for various JSONField's provided for Django.

Code of the javascript JSONEditor online editor has been got from the http://jsoneditoronline.org/.

See the latest versions of the javascript online JSON Editor here: https://github.com/josdejong/jsoneditor

Sample views:

.. image:: https://raw.github.com/josdejong/jsoneditor/master/misc/jsoneditor.png

Installation
------------
Latest version from the GIT repository::

    pip install "git+git://github.com/nnseva/django-jsoneditor.git"

Stable version from the PyPi repository::

    pip install django-jsoneditor

See all details on https://github.com/nnseva/django-jsoneditor
