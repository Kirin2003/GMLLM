django_jsoneditor_init = {
    mode: 'tree',
//    modes: ['code', 'form', 'text', 'tree', 'view'], // all modes
    modes: ['code', 'tree'], // allowed modes
}