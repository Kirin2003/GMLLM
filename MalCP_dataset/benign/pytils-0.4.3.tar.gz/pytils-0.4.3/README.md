Pytils
------

Pytils is a Russian-specific string utils
(transliteration, numeral is words, russian dates, etc)

-----

Pytils это инструменты для работы 
с русскими строками (транслитерация, числительные словами, русские даты и т.д.)
