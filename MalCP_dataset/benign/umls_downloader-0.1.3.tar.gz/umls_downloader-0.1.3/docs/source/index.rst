UMLS Downloader |release| Documentation
=======================================
Reference
---------
.. automodapi:: umls_downloader

Command Line Interface
----------------------
The UMLS Downloader automatically installs the command :code:`umls_downloader`. See
:code:`umls_downloader --help` for usage details.

.. click:: umls_downloader.cli:main
   :prog: umls_downloader
   :show-nested:

Indices and Tables
------------------
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
