===============
 Other Objects
===============

.. autoclass:: zope.tales.tales.Iterator
