"""Pure Python implementation of s2-geometry library."""
# flake8: noqa  (don't lint this file)

from __future__ import absolute_import
from .sphere import *

__version__ = '0.2.5'
