"""Core Matcher."""
