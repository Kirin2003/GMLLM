"""An mdformat plugin for parsing / ignoring frontmatter."""

__version__ = "2.0.8"

from .plugin import RENDERERS, update_mdit  # noqa: F401
