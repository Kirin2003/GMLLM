"""
Authentication provider for Kiota using Azure Identity
"""
from ._version import VERSION

__version__ = VERSION
