# see setup.cfg
from setuptools import setup

setup()
