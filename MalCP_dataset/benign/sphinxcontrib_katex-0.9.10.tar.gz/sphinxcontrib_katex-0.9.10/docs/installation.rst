.. include:: ../README.rst
    :start-line: 34
    :end-line: 51
