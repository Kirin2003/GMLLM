.. include:: ../README.rst
    :start-line: 51
    :end-line: 73
