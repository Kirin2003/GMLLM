__version__ = "1.3.4"

from mergedeep.mergedeep import merge, Strategy

__all__ = ["merge", "Strategy"]
