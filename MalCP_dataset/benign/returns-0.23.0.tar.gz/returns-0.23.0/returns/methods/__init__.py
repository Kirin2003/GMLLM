from returns.methods.cond import cond as cond
from returns.methods.unwrap_or_failure import (
    unwrap_or_failure as unwrap_or_failure,
)
