# stub to support existing import paths
from .generated.ec2manager import *  # NOQA
