Top level
=========

.. module:: gspread

.. autofunction:: oauth
.. autofunction:: service_account
.. autofunction:: authorize
