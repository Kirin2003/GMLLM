Exceptions
==========


.. autoexception:: gspread.exceptions.APIError
.. autoexception:: gspread.exceptions.GSpreadException
.. autoexception:: gspread.exceptions.IncorrectCellLabel
.. autoexception:: gspread.exceptions.InvalidInputValue
.. autoexception:: gspread.exceptions.NoValidUrlKeyFound
.. autoexception:: gspread.exceptions.SpreadsheetNotFound
.. autoexception:: gspread.exceptions.UnSupportedExportFormat
.. autoexception:: gspread.exceptions.WorksheetNotFound
