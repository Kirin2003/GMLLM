HTTP Client
===========

.. note::

   This class is not intended to be used directly.
   It is used by all gspread models to interact with the Google API

.. autoclass:: gspread.HTTPClient
   :members:

.. autoclass:: gspread.BackOffHTTPClient
   :members:
