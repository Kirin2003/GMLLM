Client
======

.. autoclass:: gspread.Client
   :members:
