---
name: Feature or enhancement
about: Propose how to improve library (not the project)
title: ''
labels: 'enhancement'
assignees: ''

---

Please, make sure all the relevant points are discussed:
- what problem does it solve
- describe the API you'd want and possibly the alternative
  you've considered.
