"""Unit test package for cloup."""
