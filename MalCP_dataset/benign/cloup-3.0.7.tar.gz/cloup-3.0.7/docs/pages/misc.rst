Miscellaneous
=============

Shortcuts for creating ``click.Path``
-------------------------------------

.. versionadded:: 0.13.0

.. autosummary::

    cloup.path
    cloup.dir_path
    cloup.file_path
