=======
Credits
=======

Author
------
* Gianluca Gippetto <gianluca.gippetto@gmail.com>

Contributors
------------
See https://github.com/janluke/cloup/graphs/contributors.

Credits
-------

- This library stands on the shoulders of `Click <https://click.palletsprojects.com>`_.

- The following `comment <https://github.com/pallets/click/issues/373#issuecomment-515293746>`_
  by `@chrisjsewell <https://github.com/chrisjsewell>`_ helped me getting started
  with the implementation of this library when I knew nothing about Click internals.
