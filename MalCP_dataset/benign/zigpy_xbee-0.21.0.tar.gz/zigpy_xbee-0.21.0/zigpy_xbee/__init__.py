"""Init file for zigpy_xbee."""

MAJOR_VERSION = 0
MINOR_VERSION = 18
PATCH_VERSION = "3"
__short_version__ = f"{MAJOR_VERSION}.{MINOR_VERSION}"
__version__ = f"{__short_version__}.{PATCH_VERSION}"
