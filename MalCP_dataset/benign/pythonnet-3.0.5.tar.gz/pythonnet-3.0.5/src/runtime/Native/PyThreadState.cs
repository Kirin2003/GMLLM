namespace Python.Runtime.Native;

struct PyThreadState
{
}
